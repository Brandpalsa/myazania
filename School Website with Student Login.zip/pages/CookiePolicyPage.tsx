import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { BottomNavigation } from '../components/common/BottomNavigation';
import { Cookie, Settings, Shield, Eye } from 'lucide-react';

export function CookiePolicyPage() {
  const lastUpdated = "January 15, 2025";

  const cookieTypes = [
    {
      icon: Shield,
      title: "Essential Cookies",
      description: "Required for the website to function properly",
      examples: ["Authentication", "Security", "Form submissions"]
    },
    {
      icon: Eye,
      title: "Analytics Cookies",
      description: "Help us understand how visitors use our website",
      examples: ["Google Analytics", "Usage patterns", "Performance metrics"]
    },
    {
      icon: Settings,
      title: "Preference Cookies",
      description: "Remember your choices and preferences",
      examples: ["Theme selection", "Language settings", "Layout preferences"]
    }
  ];

  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container max-w-4xl">
        {/* Page Header */}
        <header className="page-header text-center mb-12">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center">
              <Cookie className="w-6 h-6 text-gold" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-montserrat font-semibold text-foreground">
              Cookie Policy
            </h1>
          </div>
          <div className="page-description">
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto font-montserrat font-light leading-relaxed">
              Learn about how we use cookies and similar technologies on our website.
            </p>
            <p className="text-sm text-muted-foreground mt-4 font-montserrat font-normal">
              Last updated: {lastUpdated}
            </p>
          </div>
        </header>

        {/* What are Cookies */}
        <section className="what-are-cookies mb-12">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-montserrat font-medium text-card-foreground">
                What are Cookies?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-muted-foreground font-montserrat font-normal leading-relaxed space-y-4">
                <p>
                  Cookies are small text files that are placed on your computer or mobile device when 
                  you visit our website. They are widely used to make websites work more efficiently 
                  and provide information to website owners.
                </p>
                <p>
                  We use cookies to enhance your experience, analyze website traffic, and personalize 
                  content. This policy explains what cookies we use and how you can control them.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Types of Cookies */}
        <section className="cookie-types mb-12">
          <h2 className="text-2xl font-montserrat font-medium text-foreground text-center mb-8">
            Types of Cookies We Use
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {cookieTypes.map((type, index) => {
              const IconComponent = type.icon;
              return (
                <Card key={index} className="bg-card border-border">
                  <CardHeader>
                    <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center mb-4">
                      <IconComponent className="w-6 h-6 text-gold" />
                    </div>
                    <CardTitle className="font-montserrat font-medium text-card-foreground">
                      {type.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground font-montserrat font-normal mb-4">
                      {type.description}
                    </p>
                    <div className="space-y-1">
                      {type.examples.map((example, exampleIndex) => (
                        <div key={exampleIndex} className="flex items-center space-x-2 text-sm">
                          <div className="w-1 h-1 bg-gold rounded-full"></div>
                          <span className="text-muted-foreground font-montserrat font-normal">
                            {example}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Managing Cookies */}
        <section className="managing-cookies mb-12">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-montserrat font-medium text-card-foreground">
                Managing Your Cookie Preferences
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-muted-foreground font-montserrat font-normal leading-relaxed space-y-4">
                <p>
                  You can control and manage cookies in various ways. Please note that removing or 
                  blocking cookies may impact your user experience and some functionality may not work as expected.
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-montserrat font-medium text-card-foreground mb-2">
                      Browser Settings
                    </h3>
                    <ul className="space-y-1 text-sm">
                      <li>• Most browsers allow you to view, manage, and delete cookies</li>
                      <li>• You can set your browser to refuse cookies</li>
                      <li>• Clear existing cookies from your browser</li>
                      <li>• Set alerts when cookies are being sent</li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-montserrat font-medium text-card-foreground mb-2">
                      Third-Party Cookies
                    </h3>
                    <ul className="space-y-1 text-sm">
                      <li>• Opt out of Google Analytics tracking</li>
                      <li>• Manage social media cookie preferences</li>
                      <li>• Control advertising cookie settings</li>
                      <li>• Use privacy-focused browser extensions</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Contact */}
        <section className="contact-info">
          <Card className="bg-primary text-primary-foreground">
            <CardContent className="p-8">
              <h2 className="text-xl font-montserrat font-medium mb-4">Questions About Cookies?</h2>
              <div className="text-primary-foreground/80 font-montserrat font-light leading-relaxed">
                <p className="mb-4">
                  If you have any questions about our use of cookies, please contact us:
                </p>
                <p>Email: privacy@myazania.co.za | Phone: 065 324 8692</p>
              </div>
            </CardContent>
          </Card>
        </section>

        <BottomNavigation currentPage="legal" />
      </div>
    </div>
  );
}