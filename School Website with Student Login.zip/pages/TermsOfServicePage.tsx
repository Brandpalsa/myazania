import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { BottomNavigation } from '../components/common/BottomNavigation';
import { FileText } from 'lucide-react';
import { termsSections, policies, lastUpdated } from '../data/termsData';

export function TermsOfServicePage() {
  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container max-w-4xl">
        {/* Page Header */}
        <header className="page-header text-center mb-12">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-gold" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-montserrat font-semibold text-foreground">
              Terms of Service
            </h1>
          </div>
          <div className="page-description">
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto font-montserrat font-light leading-relaxed">
              These terms and conditions govern your use of MyAzania Academy's services and programs.
            </p>
            <p className="text-sm text-muted-foreground mt-4 font-montserrat font-normal">
              Last updated: {lastUpdated}
            </p>
          </div>
        </header>

        {/* Introduction */}
        <section className="introduction mb-12">
          <Card className="bg-card border-border">
            <CardContent className="p-8">
              <h2 className="text-xl font-montserrat font-medium text-card-foreground mb-4">Introduction</h2>
              <div className="space-y-4 text-muted-foreground font-montserrat font-normal leading-relaxed">
                <p>
                  Welcome to MyAzania Academy. These Terms of Service ("Terms") govern your use of our 
                  educational services, programs, and website. By enrolling in our programs or using our 
                  services, you agree to comply with these terms.
                </p>
                <p>
                  These terms constitute a legally binding agreement between you and MyAzania Academy. 
                  Please read them carefully before using our services.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Main Sections */}
        <div className="space-y-8 mb-12">
          {termsSections.map((section, index) => {
            const IconComponent = section.icon;
            return (
              <section key={index} className="terms-section">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 font-montserrat font-medium text-card-foreground">
                      <div className="w-8 h-8 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center">
                        <IconComponent className="w-4 h-4 text-gold" />
                      </div>
                      <span>{section.title}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {section.content.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-muted-foreground font-montserrat font-normal">
                            {item}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </section>
            );
          })}
        </div>

        {/* Detailed Policies */}
        <section className="detailed-policies mb-12">
          <h2 className="text-2xl font-montserrat font-medium text-foreground text-center mb-8">
            Detailed Policies
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {policies.map((policy, index) => (
              <Card key={index} className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="font-montserrat font-medium text-card-foreground">
                    {policy.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {policy.details.map((detail, detailIndex) => (
                      <li key={detailIndex} className="flex items-start space-x-2 text-sm">
                        <div className="w-1 h-1 bg-gold rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-muted-foreground font-montserrat font-normal">
                          {detail}
                        </span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Contact Information */}
        <section className="contact-info">
          <Card className="bg-primary text-primary-foreground">
            <CardContent className="p-8">
              <h2 className="text-xl font-montserrat font-medium mb-4">Questions About These Terms?</h2>
              <div className="text-primary-foreground/80 font-montserrat font-light leading-relaxed">
                <p className="mb-4">
                  If you have any questions about these Terms of Service, please contact us:
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <p>Email: legal@myazania.co.za</p>
                    <p>Phone: 065 324 8692</p>
                  </div>
                  <div>
                    <p>Address: Wilma Court Building office number 12 1floor</p>
                    <p>Springs, Gauteng 1559</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <BottomNavigation currentPage="legal" />
      </div>
    </div>
  );
}