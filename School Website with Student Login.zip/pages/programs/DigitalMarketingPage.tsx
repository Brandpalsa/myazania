import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Link } from '../../utils/router';
import { BottomNavigation } from '../../components/common/BottomNavigation';
import { 
  ArrowLeft, 
  Clock, 
  Users, 
  Calendar, 
  CheckCircle, 
  TrendingUp, 
  Search, 
  Share2,
  Target,
  Award,
  BookOpen
} from 'lucide-react';

export function DigitalMarketingPage() {
  const courseDetails = {
    title: "Digital Marketing",
    description: "Learn modern marketing strategies including social media, SEO, content creation, and paid advertising campaigns. Master digital tools and analytics to drive business growth and brand awareness in the digital age.",
    duration: "5 months",
    level: "Intermediate",
    price: "R 7,800",
    installmentPrice: "R 1,560/month",
    category: "Marketing",
    nextStartDate: "29 March 2025",
    classSize: "10-16 students",
    schedule: "Mon, Wed, Sat (10:00 AM - 1:00 PM)",
    certification: "Google Digital Marketing Certificate"
  };

  const curriculum = [
    {
      module: "Module 1: Digital Marketing Fundamentals",
      duration: "3 weeks",
      topics: [
        "Digital Marketing Landscape Overview",
        "Customer Journey and Buyer Personas",
        "Marketing Funnel Strategy",
        "Digital Marketing Goals and KPIs",
        "Brand Development in Digital Space"
      ]
    },
    {
      module: "Module 2: Content Marketing & Strategy",
      duration: "3 weeks",
      topics: [
        "Content Strategy Development",
        "Blog Writing and SEO Copywriting",
        "Visual Content Creation",
        "Video Marketing Fundamentals",
        "Content Calendar Planning"
      ]
    },
    {
      module: "Module 3: Search Engine Optimization (SEO)",
      duration: "4 weeks",
      topics: [
        "Keyword Research and Analysis",
        "On-Page SEO Optimization",
        "Technical SEO Basics",
        "Link Building Strategies",
        "Local SEO for Businesses"
      ]
    },
    {
      module: "Module 4: Social Media Marketing",
      duration: "4 weeks",
      topics: [
        "Platform-Specific Strategies",
        "Community Management",
        "Social Media Advertising",
        "Influencer Marketing",
        "Social Media Analytics"
      ]
    },
    {
      module: "Module 5: Google Ads & PPC",
      duration: "3 weeks",
      topics: [
        "Google Ads Campaign Setup",
        "Keyword Bidding Strategies",
        "Ad Copy and Landing Pages",
        "Campaign Optimization",
        "Display and Video Advertising"
      ]
    },
    {
      module: "Module 6: Email Marketing",
      duration: "2 weeks",
      topics: [
        "Email List Building",
        "Email Design and Templates",
        "Automation and Drip Campaigns",
        "A/B Testing for Emails",
        "Email Analytics and Deliverability"
      ]
    },
    {
      module: "Module 7: Analytics & Reporting",
      duration: "3 weeks",
      topics: [
        "Google Analytics Setup and Use",
        "Social Media Analytics Tools",
        "ROI Measurement and Attribution",
        "Data Visualization and Reporting",
        "Performance Optimization"
      ]
    }
  ];

  const learningOutcomes = [
    "Develop comprehensive digital marketing strategies for businesses",
    "Create and optimize Google Ads and social media campaigns",
    "Implement SEO techniques to improve website visibility",
    "Design engaging content for various digital platforms",
    "Analyze marketing data and measure campaign performance",
    "Manage social media accounts and build online communities",
    "Set up email marketing automation and lead nurturing",
    "Use industry-standard tools and analytics platforms"
  ];

  const prerequisites = [
    "Grade 12 certificate or equivalent",
    "Strong computer and internet skills",
    "Good written communication skills",
    "Creative thinking and analytical mindset",
    "Basic understanding of business concepts",
    "Social media familiarity preferred"
  ];

  const careerOpportunities = [
    { title: "Digital Marketing Specialist", salary: "R 10,000 - R 18,000/month" },
    { title: "Social Media Manager", salary: "R 8,000 - R 15,000/month" },
    { title: "SEO Specialist", salary: "R 9,000 - R 16,000/month" },
    { title: "Content Marketing Manager", salary: "R 12,000 - R 22,000/month" },
    { title: "PPC Campaign Manager", salary: "R 11,000 - R 20,000/month" },
    { title: "Digital Marketing Consultant", salary: "R 200 - R 500/hour" }
  ];

  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container">
        {/* Breadcrumb Navigation */}
        <nav className="breadcrumb mb-8">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Link to="/programs" className="hover:text-gold transition-colors font-montserrat font-normal">
              Programs
            </Link>
            <span>/</span>
            <span className="text-foreground font-montserrat font-normal">{courseDetails.title}</span>
          </div>
        </nav>

        {/* Back Button */}
        <Link to="/programs" className="inline-flex items-center space-x-2 text-gold hover:text-gold-600 transition-colors mb-6">
          <ArrowLeft className="w-4 h-4" />
          <span className="font-montserrat font-normal">Back to Programs</span>
        </Link>

        {/* Course Header */}
        <div className="course-header grid lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-20 h-20 bg-gold rounded-xl flex items-center justify-center">
                <TrendingUp className="w-12 h-12 text-black" />
              </div>
              <div>
                <h1 className="text-3xl font-montserrat font-semibold text-foreground mb-2">{courseDetails.title}</h1>
                <div className="flex items-center space-x-4">
                  <Badge variant="secondary" className="bg-secondary text-secondary-foreground font-montserrat font-normal">
                    {courseDetails.category}
                  </Badge>
                  <Badge variant="outline" className="border-border text-muted-foreground font-montserrat font-normal">
                    {courseDetails.level}
                  </Badge>
                </div>
              </div>
            </div>
            <p className="text-lg text-muted-foreground leading-relaxed font-montserrat font-light">
              {courseDetails.description}
            </p>
          </div>

          {/* Course Details Card */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-montserrat font-medium text-card-foreground">Course Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Duration</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground">{courseDetails.duration}</span>
              </div>
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Class Size</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground">{courseDetails.classSize}</span>
              </div>
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Next Start</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground">{courseDetails.nextStartDate}</span>
              </div>
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Award className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Certification</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground text-right text-xs">Google</span>
              </div>
              
              <div className="pricing border-t border-border pt-4">
                <div className="text-center">
                  <div className="text-2xl font-montserrat font-semibold text-foreground">{courseDetails.price}</div>
                  <div className="text-sm text-muted-foreground font-montserrat font-normal">or {courseDetails.installmentPrice} for 5 months</div>
                </div>
              </div>

              <div className="cta-buttons space-y-3">
                <Button className="w-full bg-primary text-primary-foreground hover:bg-gold hover:text-black transition-colors font-montserrat font-medium">
                  Enroll Now
                </Button>
                <Button variant="outline" className="w-full border-border text-foreground hover:bg-gold hover:text-black hover:border-gold transition-colors font-montserrat font-normal">
                  Request Info
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Learning Outcomes */}
        <section className="learning-outcomes mb-12">
          <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">What You'll Learn</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {learningOutcomes.map((outcome, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-gold mt-0.5" />
                <span className="text-foreground font-montserrat font-normal">{outcome}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Curriculum */}
        <section className="curriculum mb-12">
          <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">Curriculum</h2>
          <div className="space-y-6">
            {curriculum.map((module, index) => (
              <Card key={index} className="bg-card border-border">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="font-montserrat font-medium text-card-foreground">{module.module}</CardTitle>
                    <Badge variant="outline" className="border-border text-muted-foreground font-montserrat font-normal">
                      {module.duration}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {module.topics.map((topic, topicIndex) => (
                      <li key={topicIndex} className="flex items-start space-x-2">
                        <Search className="w-4 h-4 text-gold mt-0.5 flex-shrink-0" />
                        <span className="text-muted-foreground font-montserrat font-normal">{topic}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Prerequisites and Career Opportunities */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Prerequisites */}
          <section className="prerequisites">
            <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">Prerequisites</h2>
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  {prerequisites.map((prereq, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-gold mt-0.5" />
                      <span className="text-foreground font-montserrat font-normal">{prereq}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* Career Opportunities */}
          <section className="career-opportunities">
            <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">Career Opportunities</h2>
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {careerOpportunities.map((career, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="font-montserrat font-normal text-foreground">{career.title}</span>
                      <span className="text-sm text-muted-foreground font-montserrat font-normal">{career.salary}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>
        </div>

        {/* Call to Action */}
        <section className="cta bg-primary rounded-2xl p-8 text-center text-primary-foreground">
          <h2 className="text-2xl font-montserrat font-medium mb-4">Master Digital Marketing</h2>
          <p className="text-primary-foreground/80 mb-6 max-w-2xl mx-auto font-montserrat font-light">
            Digital marketing skills are in high demand across all industries. Learn from industry experts 
            and gain hands-on experience with real campaigns and projects.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gold text-black hover:bg-yellow-600 font-montserrat font-medium">
              Enroll Now - {courseDetails.price}
            </Button>
            <Button size="lg" variant="outline" className="text-gold border-gold bg-transparent hover:bg-gold hover:text-black font-montserrat font-normal">
              Download Brochure
            </Button>
          </div>
        </section>

        <BottomNavigation currentPage="program-detail" />
      </div>
    </div>
  );
}