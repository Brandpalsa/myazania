import { Button } from '../../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { Link } from '../../utils/router';
import { BottomNavigation } from '../../components/common/BottomNavigation';
import { 
  ArrowLeft, 
  Clock, 
  Users, 
  Calendar, 
  CheckCircle, 
  Headphones, 
  MessageSquare, 
  Phone,
  Smile,
  Award,
  BookOpen
} from 'lucide-react';

export function CustomerServicePage() {
  const courseDetails = {
    title: "Customer Service Excellence",
    description: "Develop excellent communication and problem-solving skills for customer-facing roles in any industry. Learn to handle difficult situations, build customer loyalty, and represent your organization professionally.",
    duration: "3 months",
    level: "Beginner",
    price: "R 4,500",
    installmentPrice: "R 1,500/month",
    category: "Business",
    nextStartDate: "8 March 2025",
    classSize: "12-20 students",
    schedule: "Tue, Thu (6:00 PM - 8:30 PM)",
    certification: "Customer Service Professional Certificate"
  };

  const curriculum = [
    {
      module: "Module 1: Customer Service Fundamentals",
      duration: "2 weeks",
      topics: [
        "Understanding Customer Expectations",
        "Service Excellence Principles",
        "Customer Journey Mapping",
        "First Impressions and Professional Image",
        "Service Recovery Strategies"
      ]
    },
    {
      module: "Module 2: Communication Skills",
      duration: "3 weeks",
      topics: [
        "Verbal and Non-Verbal Communication",
        "Active Listening Techniques",
        "Empathy and Emotional Intelligence",
        "Clear and Professional Language",
        "Cultural Sensitivity and Diversity"
      ]
    },
    {
      module: "Module 3: Phone and Digital Communication",
      duration: "2 weeks",
      topics: [
        "Telephone Etiquette and Best Practices",
        "Email Communication Standards",
        "Live Chat and Social Media Support",
        "Video Call Professionalism",
        "Digital Customer Experience"
      ]
    },
    {
      module: "Module 4: Conflict Resolution",
      duration: "3 weeks",
      topics: [
        "Handling Difficult Customers",
        "De-escalation Techniques",
        "Problem-Solving Methodologies",
        "Complaint Management Process",
        "Turning Complaints into Opportunities"
      ]
    },
    {
      module: "Module 5: Customer Relationship Management",
      duration: "2 weeks",
      topics: [
        "Building Customer Loyalty",
        "CRM Systems and Data Management",
        "Follow-up and Feedback Processes",
        "Customer Retention Strategies",
        "Upselling and Cross-selling Ethics"
      ]
    },
    {
      module: "Module 6: Industry Applications",
      duration: "2 weeks",
      topics: [
        "Retail Customer Service",
        "Call Center Operations",
        "Hospitality and Tourism Service",
        "Banking and Financial Services",
        "Healthcare Customer Relations"
      ]
    }
  ];

  const learningOutcomes = [
    "Communicate effectively with customers in person, by phone, and online",
    "Handle customer complaints and difficult situations professionally",
    "Build rapport and establish trust with diverse customer base",
    "Use customer service software and CRM systems efficiently",
    "Apply conflict resolution and de-escalation techniques",
    "Maintain professional standards under pressure",
    "Contribute to customer retention and business growth",
    "Adapt service approach to different industry contexts"
  ];

  const prerequisites = [
    "Grade 10 certificate or equivalent",
    "Good communication skills in English",
    "Patience and people-oriented personality",
    "Willingness to help others",
    "Basic computer literacy",
    "No prior experience required"
  ];

  const careerOpportunities = [
    { title: "Customer Service Representative", salary: "R 6,000 - R 10,000/month" },
    { title: "Call Center Agent", salary: "R 5,500 - R 9,000/month" },
    { title: "Reception Desk Clerk", salary: "R 6,500 - R 11,000/month" },
    { title: "Client Relations Officer", salary: "R 8,000 - R 14,000/month" },
    { title: "Customer Success Manager", salary: "R 12,000 - R 20,000/month" },
    { title: "Service Quality Supervisor", salary: "R 10,000 - R 18,000/month" }
  ];

  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container">
        {/* Breadcrumb Navigation */}
        <nav className="breadcrumb mb-8">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Link to="/programs" className="hover:text-gold transition-colors font-montserrat font-normal">
              Programs
            </Link>
            <span>/</span>
            <span className="text-foreground font-montserrat font-normal">{courseDetails.title}</span>
          </div>
        </nav>

        {/* Back Button */}
        <Link to="/programs" className="inline-flex items-center space-x-2 text-gold hover:text-gold-600 transition-colors mb-6">
          <ArrowLeft className="w-4 h-4" />
          <span className="font-montserrat font-normal">Back to Programs</span>
        </Link>

        {/* Course Header */}
        <div className="course-header grid lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-20 h-20 bg-gold rounded-xl flex items-center justify-center">
                <Headphones className="w-12 h-12 text-black" />
              </div>
              <div>
                <h1 className="text-3xl font-montserrat font-semibold text-foreground mb-2">{courseDetails.title}</h1>
                <div className="flex items-center space-x-4">
                  <Badge variant="secondary" className="bg-secondary text-secondary-foreground font-montserrat font-normal">
                    {courseDetails.category}
                  </Badge>
                  <Badge variant="outline" className="border-border text-muted-foreground font-montserrat font-normal">
                    {courseDetails.level}
                  </Badge>
                </div>
              </div>
            </div>
            <p className="text-lg text-muted-foreground leading-relaxed font-montserrat font-light">
              {courseDetails.description}
            </p>
          </div>

          {/* Course Details Card */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-montserrat font-medium text-card-foreground">Course Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Duration</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground">{courseDetails.duration}</span>
              </div>
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Class Size</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground">{courseDetails.classSize}</span>
              </div>
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Next Start</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground">{courseDetails.nextStartDate}</span>
              </div>
              <div className="course-detail flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Award className="w-4 h-4 text-gold" />
                  <span className="text-sm font-montserrat font-normal text-card-foreground">Level</span>
                </div>
                <span className="font-montserrat font-medium text-card-foreground">{courseDetails.level}</span>
              </div>
              
              <div className="pricing border-t border-border pt-4">
                <div className="text-center">
                  <div className="text-2xl font-montserrat font-semibold text-foreground">{courseDetails.price}</div>
                  <div className="text-sm text-muted-foreground font-montserrat font-normal">or {courseDetails.installmentPrice} for 3 months</div>
                </div>
              </div>

              <div className="cta-buttons space-y-3">
                <Button className="w-full bg-primary text-primary-foreground hover:bg-gold hover:text-black transition-colors font-montserrat font-medium">
                  Enroll Now
                </Button>
                <Button variant="outline" className="w-full border-border text-foreground hover:bg-gold hover:text-black hover:border-gold transition-colors font-montserrat font-normal">
                  Request Info
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Learning Outcomes */}
        <section className="learning-outcomes mb-12">
          <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">What You'll Learn</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {learningOutcomes.map((outcome, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-gold mt-0.5" />
                <span className="text-foreground font-montserrat font-normal">{outcome}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Curriculum */}
        <section className="curriculum mb-12">
          <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">Curriculum</h2>
          <div className="space-y-6">
            {curriculum.map((module, index) => (
              <Card key={index} className="bg-card border-border">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="font-montserrat font-medium text-card-foreground">{module.module}</CardTitle>
                    <Badge variant="outline" className="border-border text-muted-foreground font-montserrat font-normal">
                      {module.duration}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {module.topics.map((topic, topicIndex) => (
                      <li key={topicIndex} className="flex items-start space-x-2">
                        <MessageSquare className="w-4 h-4 text-gold mt-0.5 flex-shrink-0" />
                        <span className="text-muted-foreground font-montserrat font-normal">{topic}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Prerequisites and Career Opportunities */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Prerequisites */}
          <section className="prerequisites">
            <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">Prerequisites</h2>
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <ul className="space-y-3">
                  {prerequisites.map((prereq, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-gold mt-0.5" />
                      <span className="text-foreground font-montserrat font-normal">{prereq}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </section>

          {/* Career Opportunities */}
          <section className="career-opportunities">
            <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">Career Opportunities</h2>
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {careerOpportunities.map((career, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="font-montserrat font-normal text-foreground">{career.title}</span>
                      <span className="text-sm text-muted-foreground font-montserrat font-normal">{career.salary}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </section>
        </div>

        {/* Call to Action */}
        <section className="cta bg-primary rounded-2xl p-8 text-center text-primary-foreground">
          <h2 className="text-2xl font-montserrat font-medium mb-4">Excel in Customer Relations</h2>
          <p className="text-primary-foreground/80 mb-6 max-w-2xl mx-auto font-montserrat font-light">
            Customer service skills are essential in every industry. Build a strong foundation for career growth 
            and become the professional that customers and employers value.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gold text-black hover:bg-yellow-600 font-montserrat font-medium">
              Enroll Now - {courseDetails.price}
            </Button>
            <Button size="lg" variant="outline" className="text-gold border-gold bg-transparent hover:bg-gold hover:text-black font-montserrat font-normal">
              Download Brochure
            </Button>
          </div>
        </section>

        <BottomNavigation currentPage="program-detail" />
      </div>
    </div>
  );
}