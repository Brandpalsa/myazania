import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Link } from '../utils/router';
import { BottomNavigation } from '../components/common/BottomNavigation';
import { 
  Code, 
  Scissors, 
  Calculator, 
  Headphones, 
  TrendingUp, 
  Users, 
  Heart, 
  Shield,
  Clock,
  User,
  Calendar,
  ArrowRight
} from 'lucide-react';

interface Program {
  id: number;
  title: string;
  description: string;
  icon: any;
  duration: string;
  level: string;
  category: string;
  price: string;
  installmentPrice: string;
  features: string[];
  color: string;
  slug: string;
  nextStartDate: string;
  spotsLeft: number;
}

export function ProgramsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All Programs');

  const programs: Program[] = [
    {
      id: 1,
      title: "Basic Coding",
      description: "Learn fundamental programming concepts and start your journey in software development with HTML, CSS, JavaScript, and React.",
      icon: Code,
      duration: "6 months",
      level: "Beginner",
      category: "Technology",
      price: "R 8,500",
      installmentPrice: "R 1,417/month",
      features: ["HTML/CSS", "JavaScript", "React.js", "Node.js", "Portfolio Projects"],
      color: "bg-primary",
      slug: "basic-coding",
      nextStartDate: "15 March 2025",
      spotsLeft: 8
    },
    {
      id: 2,
      title: "Beauty Therapy & More",
      description: "Comprehensive beauty and wellness training covering modern techniques, business skills, and industry certification.",
      icon: Scissors,
      duration: "8 months",
      level: "All Levels",
      category: "Beauty & Wellness",
      price: "R 12,500",
      installmentPrice: "R 1,563/month",
      features: ["Facial Treatments", "Nail Art", "Hair Styling", "Business Management", "CIDESCO Prep"],
      color: "bg-gold",
      slug: "beauty-therapy",
      nextStartDate: "1 April 2025",
      spotsLeft: 5
    },
    {
      id: 3,
      title: "Bookkeeping & Payroll",
      description: "Master financial record keeping and payroll management for small to medium businesses with industry-standard software.",
      icon: Calculator,
      duration: "4 months",
      level: "Intermediate",
      category: "Finance",
      price: "R 6,500",
      installmentPrice: "R 1,625/month",
      features: ["QuickBooks", "Pastel", "Tax Preparation", "Payroll Systems", "Financial Reports"],
      color: "bg-primary",
      slug: "bookkeeping-payroll",
      nextStartDate: "22 March 2025",
      spotsLeft: 12
    },
    {
      id: 4,
      title: "Customer Service Excellence",
      description: "Develop excellent communication and problem-solving skills for customer-facing roles in any industry.",
      icon: Headphones,
      duration: "3 months",
      level: "Beginner",
      category: "Business",
      price: "R 4,500",
      installmentPrice: "R 1,500/month",
      features: ["Communication Skills", "Conflict Resolution", "CRM Systems", "Phone Etiquette", "Professional Ethics"],
      color: "bg-gold",
      slug: "customer-service",
      nextStartDate: "8 March 2025",
      spotsLeft: 15
    },
    {
      id: 5,
      title: "Digital Marketing",
      description: "Learn modern marketing strategies including social media, SEO, content creation, and paid advertising campaigns.",
      icon: TrendingUp,
      duration: "5 months",
      level: "Intermediate",
      category: "Marketing",
      price: "R 7,800",
      installmentPrice: "R 1,560/month",
      features: ["Social Media Marketing", "Google Ads", "SEO Optimization", "Analytics", "Content Strategy"],
      color: "bg-primary",
      slug: "digital-marketing",
      nextStartDate: "29 March 2025",
      spotsLeft: 6
    },
    {
      id: 6,
      title: "Entrepreneurship Development",
      description: "Build the skills and mindset needed to start and grow your own successful business venture.",
      icon: Users,
      duration: "6 months",
      level: "All Levels",
      category: "Business",
      price: "R 9,200",
      installmentPrice: "R 1,533/month",
      features: ["Business Planning", "Financial Management", "Marketing Strategy", "Leadership", "Pitch Development"],
      color: "bg-gold",
      slug: "entrepreneurship",
      nextStartDate: "5 April 2025",
      spotsLeft: 10
    },
    {
      id: 7,
      title: "Health & Safety Management",
      description: "Comprehensive workplace safety training and health management certification for various industries.",
      icon: Shield,
      duration: "2 months",
      level: "Beginner",
      category: "Safety",
      price: "R 3,800",
      installmentPrice: "R 1,900/month",
      features: ["Risk Assessment", "Safety Protocols", "Emergency Procedures", "Legal Compliance", "Incident Investigation"],
      color: "bg-primary",
      slug: "health-safety",
      nextStartDate: "15 March 2025",
      spotsLeft: 20
    },
    {
      id: 8,
      title: "Life Skills Development",
      description: "Essential personal and professional development skills for career success and personal growth.",
      icon: Heart,
      duration: "3 months",
      level: "All Levels",
      category: "Personal Development",
      price: "R 4,200",
      installmentPrice: "R 1,400/month",
      features: ["Time Management", "Communication", "Goal Setting", "Emotional Intelligence", "Career Planning"],
      color: "bg-gold",
      slug: "life-skills",
      nextStartDate: "12 March 2025",
      spotsLeft: 18
    }
  ];

  const categories = [...new Set(programs.map(p => p.category))];

  // Filter programs based on selected category
  const filteredPrograms = selectedCategory === 'All Programs' 
    ? programs 
    : programs.filter(program => program.category === selectedCategory);

  const handleCategoryClick = (category: string) => {
    setSelectedCategory(category);
  };

  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container">
        {/* Page Header */}
        <header className="page-header text-center mb-16">
          <h1 className="text-3xl lg:text-4xl font-montserrat font-semibold text-foreground mb-4">
            Our Program Offerings
          </h1>
          <div className="page-description">
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto font-montserrat font-light leading-relaxed">
              Choose from our comprehensive range of skills-focused programs designed to prepare you 
              for success in today's competitive job market. All programs include practical training, 
              industry certification, and job placement assistance.
            </p>
          </div>
        </header>

        {/* Category Filter */}
        <div className="category-filter mb-12">
          <h2 className="text-xl font-montserrat font-medium text-foreground mb-4">Browse by Category</h2>
          <div className="flex flex-wrap button-spacing">
            <Badge 
              variant={selectedCategory === 'All Programs' ? 'default' : 'secondary'}
              className={`cursor-pointer transition-colors font-montserrat font-normal ${
                selectedCategory === 'All Programs' 
                  ? 'bg-gold text-black hover:bg-gold-600' 
                  : 'hover:bg-gold hover:text-black'
              }`}
              onClick={() => handleCategoryClick('All Programs')}
            >
              All Programs
            </Badge>
            {categories.map((category) => (
              <Badge 
                key={category} 
                variant={selectedCategory === category ? 'default' : 'outline'}
                className={`cursor-pointer transition-colors font-montserrat font-normal ${
                  selectedCategory === category 
                    ? 'bg-gold text-black hover:bg-gold-600' 
                    : 'hover:bg-gold hover:text-black hover:border-gold'
                }`}
                onClick={() => handleCategoryClick(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>

        {/* Programs Grid */}
        <div className="programs-grid grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-16">
          {filteredPrograms.map((program) => {
            const IconComponent = program.icon;
            const isGold = program.color === 'bg-gold';
            return (
              <article 
                key={program.id} 
                className="program-card h-full"
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 bg-card border-border theme-transition hover:shadow-gold/10 flex flex-col">
                  <CardHeader className="pb-4">
                    {/* Header Row: Icon and Category Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <div className={`program-icon w-12 h-12 ${program.color} rounded-lg flex items-center justify-center flex-shrink-0`}>
                        <IconComponent className={`w-6 h-6 ${isGold ? 'text-black' : 'text-primary-foreground'}`} />
                      </div>
                      <Badge variant="outline" className="program-category font-montserrat font-normal text-xs border-border text-muted-foreground">
                        {program.category}
                      </Badge>
                    </div>
                    
                    {/* Title */}
                    <CardTitle className="program-title text-lg text-card-foreground font-montserrat font-medium mb-2 leading-tight">
                      {program.title}
                    </CardTitle>
                    
                    {/* Description */}
                    <CardDescription className="program-description text-sm text-muted-foreground font-montserrat font-normal line-clamp-3 leading-relaxed mb-4">
                      {program.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent className="flex flex-col flex-grow space-y-4">
                    {/* Duration and Level - Inline */}
                    <div className="program-meta flex items-center justify-between text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="font-montserrat font-normal">{program.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <User className="w-4 h-4 text-muted-foreground" />
                        <span className="font-montserrat font-normal">{program.level}</span>
                      </div>
                    </div>

                    {/* Key Areas */}
                    <div className="program-features flex-grow">
                      <h4 className="features-title font-montserrat font-normal text-sm text-card-foreground mb-2">
                        Key Areas:
                      </h4>
                      <div className="features-list flex flex-wrap gap-1">
                        {program.features.slice(0, 3).map((feature, index) => (
                          <Badge 
                            key={index} 
                            variant="outline" 
                            className="feature-tag text-xs border-border text-muted-foreground font-montserrat font-normal"
                          >
                            {feature}
                          </Badge>
                        ))}
                        {program.features.length > 3 && (
                          <Badge 
                            variant="outline" 
                            className="feature-more text-xs border-border text-muted-foreground font-montserrat font-normal"
                          >
                            +{program.features.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Learn More Button */}
                    <div className="mt-auto pt-4">
                      <Link to={`/programs/${program.slug}`} className="block">
                        <Button 
                          className="w-full bg-primary text-primary-foreground hover:bg-gold hover:text-black transition-colors font-montserrat font-normal btn-consistent"
                        >
                          Learn More
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </article>
            );
          })}
        </div>

        {/* Call to Action Section */}
        <section className="programs-cta text-center">
          <div className="cta-container bg-primary rounded-2xl p-8 text-primary-foreground theme-transition">
            <h2 className="cta-title text-2xl font-montserrat font-medium mb-4">Can't Find What You're Looking For?</h2>
            <div className="cta-description">
              <p className="text-primary-foreground/80 mb-6 max-w-2xl mx-auto font-montserrat font-light">
                We offer customized training solutions for businesses and specialized skill development programs. 
                Contact us to discuss your specific training needs.
              </p>
            </div>
            <div className="cta-buttons flex flex-col sm:flex-row button-spacing justify-center">
              <Link to="/contact">
                <Button size="lg" className="cta-consultation bg-gold text-black hover:bg-gold-600 font-montserrat font-medium btn-consistent">
                  <Calendar className="w-4 h-4 mr-2 text-black" />
                  Schedule a Consultation
                </Button>
              </Link>
              <Button 
                size="lg" 
                variant="outline" 
                className="cta-brochure text-gold border-gold bg-transparent hover:bg-gold hover:text-black font-montserrat font-normal btn-consistent"
              >
                Download Full Brochure
              </Button>
            </div>
          </div>
        </section>

        <BottomNavigation currentPage="programs" />
      </div>
    </div>
  );
}