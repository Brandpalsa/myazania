import { Card, CardContent } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Link } from '../utils/router';
import { BottomNavigation } from '../components/common/BottomNavigation';
import { 
  CheckCircle, 
  Target, 
  Users, 
  BookOpen, 
  Award, 
  Globe,
  MapPin,
  Phone,
  Mail,
  Calendar,
  TrendingUp,
  Heart,
  Lightbulb
} from 'lucide-react';

export function AboutPage() {
  const academyStats = [
    { icon: Users, value: '1000+', label: 'Students Trained', description: 'Successful graduates since 2020' },
    { icon: Award, value: '15+', label: 'Programs Offered', description: 'Comprehensive skills training' },
    { icon: TrendingUp, value: '95%', label: 'Job Placement', description: 'Graduate employment rate' },
    { icon: Globe, value: '50+', label: 'Industry Partners', description: 'Employer network connections' }
  ];

  const features = [
    "Hands-on, practical training approach",
    "Industry-experienced instructors",
    "Small class sizes for personalized attention",
    "Job placement assistance program",
    "Flexible scheduling options",
    "Modern facilities and equipment",
    "Industry-recognized certifications",
    "Career counseling and support",
    "Alumni network and mentorship",
    "Continuous curriculum updates"
  ];

  const values = [
    {
      icon: Target,
      title: "Excellence",
      description: "We strive for the highest standards in education and training delivery, ensuring our students receive world-class instruction and support."
    },
    {
      icon: Users,
      title: "Community",
      description: "Building a supportive learning environment where everyone can thrive, grow, and achieve their career aspirations together."
    },
    {
      icon: BookOpen,
      title: "Innovation",
      description: "Continuously updating our curriculum and teaching methods to meet evolving industry demands and technological advances."
    },
    {
      icon: Heart,
      title: "Empowerment",
      description: "Empowering individuals to take control of their careers and futures through practical skills and knowledge acquisition."
    }
  ];

  const team = [
    {
      name: "Dr. Sarah Mthembu",
      position: "Principal & Founder",
      experience: "15+ years",
      specialization: "Educational Leadership & Curriculum Development",
      qualifications: "PhD Education Management, MBA"
    },
    {
      name: "Michael Johnson",
      position: "Head of Technology Programs",
      experience: "12+ years",
      specialization: "Software Development & Digital Innovation",
      qualifications: "MSc Computer Science, Industry Certifications"
    },
    {
      name: "Nomsa Dlamini",
      position: "Director of Student Services",
      experience: "10+ years",
      specialization: "Student Support & Career Development",
      qualifications: "MA Psychology, Career Counseling Certification"
    },
    {
      name: "James Wilson",
      position: "Business Programs Coordinator",
      experience: "8+ years",
      specialization: "Business Development & Entrepreneurship",
      qualifications: "MBA, Certified Business Consultant"
    }
  ];

  const milestones = [
    {
      year: "2020",
      title: "Academy Founded",
      description: "MyAzania Academy established with a vision to provide practical skills training."
    },
    {
      year: "2021",
      title: "First 100 Graduates",
      description: "Achieved milestone of 100 successful program completions with 92% job placement rate."
    },
    {
      year: "2022",
      title: "Industry Partnerships",
      description: "Formed strategic partnerships with leading companies for internships and job placements."
    },
    {
      year: "2023",
      title: "Expanded Campus",
      description: "Opened new state-of-the-art facilities to accommodate growing student enrollment."
    },
    {
      year: "2024",
      title: "Digital Innovation",
      description: "Launched hybrid learning programs and online course delivery systems."
    },
    {
      year: "2025",
      title: "1000+ Students",
      description: "Reached milestone of over 1000 students trained across all programs."
    }
  ];

  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container">
        {/* Page Header */}
        <header className="page-header text-center mb-16">
          <h1 className="text-3xl lg:text-4xl font-montserrat font-semibold text-foreground mb-4">
            About MyAzania Academy
          </h1>
          <div className="page-description">
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto font-montserrat font-light leading-relaxed">
              Empowering individuals with practical skills and knowledge to succeed in the modern workplace 
              and contribute meaningfully to their communities since 2020.
            </p>
          </div>
        </header>

        {/* Mission and Vision */}
        <section className="mission-vision mb-16">
          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="bg-card border-border">
              <CardContent className="p-8">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center">
                    <Target className="w-6 h-6 text-gold" />
                  </div>
                  <h2 className="text-xl font-montserrat font-medium text-card-foreground">Our Mission</h2>
                </div>
                <p className="text-muted-foreground font-montserrat font-light leading-relaxed">
                  To bridge the gap between traditional education and industry requirements by providing 
                  hands-on, practical training that empowers individuals to thrive in the real world. 
                  We are committed to delivering quality education that transforms lives and builds careers.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-8">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center">
                    <Lightbulb className="w-6 h-6 text-gold" />
                  </div>
                  <h2 className="text-xl font-montserrat font-medium text-card-foreground">Our Vision</h2>
                </div>
                <p className="text-muted-foreground font-montserrat font-light leading-relaxed">
                  To become South Africa's leading skills development institution, recognized for excellence 
                  in practical education and innovative training solutions. We envision a future where every 
                  individual has access to quality skills training that leads to meaningful employment.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Academy Statistics */}
        <section className="academy-stats mb-16">
          <h2 className="text-2xl font-montserrat font-medium text-foreground text-center mb-8">Our Impact</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {academyStats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <Card key={index} className="text-center p-6 bg-card border-border">
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-center mb-4">
                      <div className="w-16 h-16 bg-gold-100 dark:bg-gold-900/30 rounded-full flex items-center justify-center">
                        <IconComponent className="w-8 h-8 text-gold" />
                      </div>
                    </div>
                    <div className="text-3xl font-montserrat font-semibold text-foreground mb-2">{stat.value}</div>
                    <h3 className="font-montserrat font-medium text-card-foreground mb-1">{stat.label}</h3>
                    <p className="text-sm text-muted-foreground font-montserrat font-normal">{stat.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="why-choose-us mb-16">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-2xl font-montserrat font-medium text-foreground mb-6">Why Choose MyAzania Academy?</h2>
              <p className="text-muted-foreground font-montserrat font-light leading-relaxed mb-6">
                Our comprehensive approach to skills development sets us apart. We don't just teach theory – 
                we provide practical, hands-on experience that prepares you for real-world challenges and opportunities.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-gold flex-shrink-0" />
                    <span className="text-foreground font-montserrat font-normal">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-gold-100 to-gold-200 dark:from-gold-900/20 dark:to-gold-800/20 rounded-2xl p-8">
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                      <Award className="w-10 h-10 text-gold" />
                    </div>
                    <h3 className="text-xl font-montserrat font-medium text-card-foreground mb-2">Industry Recognition</h3>
                    <p className="text-muted-foreground font-montserrat font-light leading-relaxed">
                      Our programs are designed in collaboration with industry experts and recognized by leading 
                      employers across various sectors, ensuring our graduates meet market demands.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Core Values */}
        <section className="core-values mb-16">
          <h2 className="text-2xl font-montserrat font-medium text-foreground text-center mb-8">Our Core Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <Card key={index} className="text-center p-6 hover:shadow-lg transition-all duration-300 h-full bg-card border-border hover:shadow-gold/10">
                  <CardContent className="pt-6">
                    <div className="value-icon w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="w-6 h-6 text-gold" />
                    </div>
                    <h3 className="value-title font-montserrat font-medium text-card-foreground mb-2">{value.title}</h3>
                    <div className="value-description">
                      <p className="text-sm text-muted-foreground font-montserrat font-normal leading-relaxed">{value.description}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Leadership Team */}
        <section className="leadership-team mb-16">
          <h2 className="text-2xl font-montserrat font-medium text-foreground text-center mb-8">Our Leadership Team</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, index) => (
              <Card key={index} className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-gold-100 dark:bg-gold-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Users className="w-10 h-10 text-gold" />
                    </div>
                    <h3 className="font-montserrat font-medium text-card-foreground mb-1">{member.name}</h3>
                    <p className="text-sm text-gold font-montserrat font-normal mb-2">{member.position}</p>
                    <p className="text-xs text-muted-foreground font-montserrat font-normal mb-2">{member.experience} experience</p>
                    <p className="text-xs text-muted-foreground font-montserrat font-normal mb-2">{member.specialization}</p>
                    <p className="text-xs text-muted-foreground font-montserrat font-light">{member.qualifications}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Academy Timeline */}
        <section className="academy-timeline mb-16">
          <h2 className="text-2xl font-montserrat font-medium text-foreground text-center mb-8">Our Journey</h2>
          <div className="space-y-6">
            {milestones.map((milestone, index) => (
              <Card key={index} className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-gold rounded-lg flex items-center justify-center flex-shrink-0">
                      <span className="font-montserrat font-semibold text-black">{milestone.year}</span>
                    </div>
                    <div>
                      <h3 className="font-montserrat font-medium text-card-foreground mb-2">{milestone.title}</h3>
                      <p className="text-muted-foreground font-montserrat font-normal">{milestone.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section className="about-cta bg-primary rounded-2xl p-8 text-center text-primary-foreground">
          <h2 className="text-2xl font-montserrat font-medium mb-4">Ready to Transform Your Career?</h2>
          <p className="text-primary-foreground/80 mb-6 max-w-2xl mx-auto font-montserrat font-light">
            Join thousands of successful graduates who have transformed their careers through our practical, 
            industry-focused training programs. Your future starts here.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/programs">
              <Button size="lg" className="bg-gold text-black hover:bg-gold-600 font-montserrat font-medium">
                Explore Programs
              </Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="outline" className="text-gold border-gold bg-transparent hover:bg-gold hover:text-black font-montserrat font-normal">
                Contact Us
              </Button>
            </Link>
          </div>
        </section>

        <BottomNavigation currentPage="about" />
      </div>
    </div>
  );
}