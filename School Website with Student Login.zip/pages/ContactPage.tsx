import { useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { BottomNavigation } from '../components/common/BottomNavigation';
import { Map } from '../components/common/Map';
import { generateBrochurePDF } from '../utils/pdfBrochure';
import { toast } from "sonner@2.0.3";
import { Toaster } from '../components/ui/sonner';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send,
  MessageSquare,
  Calendar,
  Users,
  BookOpen,
  Globe
} from 'lucide-react';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    inquiryType: '',
    program: '',
    message: ''
  });

  const contactInfo = {
    address: {
      street: "Wilma Court Building office number 12 1floor",
      suburb: "Springs",
      city: "Springs",
      province: "Gauteng",
      postalCode: "1559",
      country: "South Africa"
    },
    phone: {
      main: "065 324 8692",
      alternative: "065 248 8692",
      whatsapp: "065 324 8692"
    },
    email: {
      general: "academy@myazania.co.za",
      admissions: "admissions@myazania.co.za",
      support: "support@myazania.co.za"
    },
    hours: {
      weekdays: "Monday - Friday: 8:00 AM - 6:00 PM",
      saturday: "Saturday: 9:00 AM - 2:00 PM",
      sunday: "Sunday: Closed"
    }
  };

  const inquiryTypes = [
    "General Information",
    "Program Enrollment",
    "Course Schedule",
    "Pricing and Payment",
    "Career Services",
    "Technical Support",
    "Partnership Opportunities",
    "Other"
  ];

  const programs = [
    "Basic Coding",
    "Beauty Therapy & More",
    "Bookkeeping & Payroll",
    "Customer Service",
    "Digital Marketing",
    "Entrepreneurship",
    "Health & Safety",
    "Life Skills Development"
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
    // You would typically send this to a backend service
  };

  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownloadBrochure = async () => {
    setIsDownloading(true);
    toast.loading('Generating comprehensive brochure...', { 
      id: 'brochure-download',
      duration: 2000 
    });
    
    try {
      generateBrochurePDF();
      
      // Show success message
      setTimeout(() => {
        toast.success('Brochure download started! Check your downloads folder.', {
          id: 'brochure-download',
          duration: 4000
        });
        setIsDownloading(false);
      }, 1000);
      
    } catch (error) {
      console.error('Error generating brochure:', error);
      toast.error('Failed to generate brochure. Please try again.', {
        id: 'brochure-download',
        duration: 4000
      });
      setIsDownloading(false);
    }
  };

  const officeLocations = [
    {
      name: "Main Campus",
      address: "Wilma Court Building office number 12 1floor, Springs, Gauteng 1559",
      phone: "065 324 8692",
      email: "academy@myazania.co.za",
      programs: ["All Programs", "Student Services", "Administration", "Career Support"]
    }
  ];

  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container">
        {/* Page Header */}
        <header className="page-header text-center mb-16">
          <h1 className="text-3xl lg:text-4xl font-montserrat font-semibold text-foreground mb-4">
            Contact Us
          </h1>
          <div className="page-description">
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto font-montserrat font-light leading-relaxed">
              We're here to help you start your journey towards a successful career. Get in touch with us 
              for program information, enrollment assistance, or any questions you might have.
            </p>
          </div>
        </header>

        {/* Contact Methods */}
        <section className="contact-methods mb-16">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6 bg-card border-border">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Phone className="w-6 h-6 text-foreground" />
                </div>
                <h3 className="font-montserrat font-medium text-card-foreground mb-2">Call Us</h3>
                <p className="text-sm text-muted-foreground font-montserrat font-normal mb-1">{contactInfo.phone.main}</p>
                <p className="text-sm text-muted-foreground font-montserrat font-normal">{contactInfo.phone.alternative}</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 bg-card border-border">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-6 h-6 text-foreground" />
                </div>
                <h3 className="font-montserrat font-medium text-card-foreground mb-2">Email Us</h3>
                <p className="text-sm text-muted-foreground font-montserrat font-normal mb-1">{contactInfo.email.general}</p>
                <p className="text-sm text-muted-foreground font-montserrat font-normal">{contactInfo.email.admissions}</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 bg-card border-border">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-6 h-6 text-foreground" />
                </div>
                <h3 className="font-montserrat font-medium text-card-foreground mb-2">Visit Us</h3>
                <p className="text-sm text-muted-foreground font-montserrat font-normal mb-1">{contactInfo.address.street}</p>
                <p className="text-sm text-muted-foreground font-montserrat font-normal">{contactInfo.address.city}, {contactInfo.address.postalCode}</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 bg-card border-border">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Clock className="w-6 h-6 text-foreground" />
                </div>
                <h3 className="font-montserrat font-medium text-card-foreground mb-2">Office Hours</h3>
                <p className="text-sm text-muted-foreground font-montserrat font-normal mb-1">Mon-Fri: 8AM-6PM</p>
                <p className="text-sm text-muted-foreground font-montserrat font-normal">Sat: 9AM-2PM</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Contact Form and Info */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Contact Form */}
          <section className="contact-form">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 font-montserrat font-medium text-card-foreground">
                  <MessageSquare className="w-5 h-5 text-foreground" />
                  <span>Send us a Message</span>
                </CardTitle>
                <CardDescription className="font-montserrat font-normal text-muted-foreground">
                  Fill out the form below and we'll get back to you within 24 hours.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="font-montserrat font-normal text-card-foreground">Full Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        placeholder="Your full name"
                        required
                        className="bg-input-background border-border text-foreground font-montserrat font-normal"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="font-montserrat font-normal text-card-foreground">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        placeholder="your.email@example.com"
                        required
                        className="bg-input-background border-border text-foreground font-montserrat font-normal"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="font-montserrat font-normal text-card-foreground">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="Your phone number"
                      className="bg-input-background border-border text-foreground font-montserrat font-normal"
                    />
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="font-montserrat font-normal text-card-foreground">Inquiry Type *</Label>
                      <Select value={formData.inquiryType} onValueChange={(value) => handleInputChange('inquiryType', value)}>
                        <SelectTrigger className="bg-input-background border-border text-foreground font-montserrat font-normal">
                          <SelectValue placeholder="Select inquiry type" />
                        </SelectTrigger>
                        <SelectContent>
                          {inquiryTypes.map((type) => (
                            <SelectItem key={type} value={type} className="font-montserrat font-normal">
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="font-montserrat font-normal text-card-foreground">Program of Interest</Label>
                      <Select value={formData.program} onValueChange={(value) => handleInputChange('program', value)}>
                        <SelectTrigger className="bg-input-background border-border text-foreground font-montserrat font-normal">
                          <SelectValue placeholder="Select program" />
                        </SelectTrigger>
                        <SelectContent>
                          {programs.map((program) => (
                            <SelectItem key={program} value={program} className="font-montserrat font-normal">
                              {program}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message" className="font-montserrat font-normal text-card-foreground">Message *</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      placeholder="Tell us more about your inquiry..."
                      rows={5}
                      required
                      className="bg-input-background border-border text-foreground font-montserrat font-normal"
                    />
                  </div>

                  <Button type="submit" className="w-full bg-primary text-primary-foreground hover:bg-gold hover:text-black transition-colors font-montserrat font-medium">
                    <Send className="w-4 h-4 mr-2 text-primary-foreground" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </section>

          {/* Contact Information */}
          <section className="contact-info space-y-6">
            {/* Office Locations */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 font-montserrat font-medium text-card-foreground">
                  <MapPin className="w-5 h-5 text-black" />
                  <span>Office Locations</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {officeLocations.map((location, index) => (
                  <div key={index} className="border-b border-border last:border-b-0 pb-4 last:pb-0">
                    <h3 className="font-montserrat font-medium text-card-foreground mb-2">{location.name}</h3>
                    <div className="space-y-1 text-sm text-muted-foreground">
                      <p className="flex items-start space-x-2">
                        <MapPin className="w-4 h-4 text-black mt-0.5 flex-shrink-0" />
                        <span className="font-montserrat font-normal">{location.address}</span>
                      </p>
                      <p className="flex items-center space-x-2">
                        <Phone className="w-4 h-4 text-black" />
                        <span className="font-montserrat font-normal">{location.phone}</span>
                      </p>
                      <p className="flex items-center space-x-2">
                        <Mail className="w-4 h-4 text-black" />
                        <span className="font-montserrat font-normal">{location.email}</span>
                      </p>
                      <p className="flex items-start space-x-2">
                        <BookOpen className="w-4 h-4 text-black mt-0.5 flex-shrink-0" />
                        <span className="font-montserrat font-normal">{location.programs.join(', ')}</span>
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="font-montserrat font-medium text-card-foreground">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start border-border text-foreground hover:bg-gold hover:text-black hover:border-gold transition-colors font-montserrat font-normal">
                  <Calendar className="w-4 h-4 mr-2 text-black" />
                  Schedule a Campus Tour
                </Button>
                <Button variant="outline" className="w-full justify-start border-border text-foreground hover:bg-gold hover:text-black hover:border-gold transition-colors font-montserrat font-normal">
                  <Users className="w-4 h-4 mr-2 text-black" />
                  Book a Consultation
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start border-border text-foreground hover:bg-gold hover:text-black hover:border-gold transition-colors font-montserrat font-normal disabled:opacity-50"
                  onClick={handleDownloadBrochure}
                  disabled={isDownloading}
                >
                  <BookOpen className={`w-4 h-4 mr-2 text-black ${isDownloading ? 'animate-pulse' : ''}`} />
                  {isDownloading ? 'Generating Brochure...' : 'Download Full Brochure'}
                </Button>
                <Button variant="outline" className="w-full justify-start border-border text-foreground hover:bg-gold hover:text-black hover:border-gold transition-colors font-montserrat font-normal">
                  <Globe className="w-4 h-4 mr-2 text-black" />
                  Virtual Campus Tour
                </Button>
              </CardContent>
            </Card>

            {/* Operating Hours */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 font-montserrat font-medium text-card-foreground">
                  <Clock className="w-5 h-5 text-black" />
                  <span>Operating Hours</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="font-montserrat font-normal text-card-foreground">Monday - Friday</span>
                    <span className="font-montserrat font-normal text-muted-foreground">8:00 AM - 6:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-montserrat font-normal text-card-foreground">Saturday</span>
                    <span className="font-montserrat font-normal text-muted-foreground">9:00 AM - 2:00 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-montserrat font-normal text-card-foreground">Sunday</span>
                    <span className="font-montserrat font-normal text-muted-foreground">Closed</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>
        </div>

        {/* Interactive Map with Location and Directions */}
        <section className="map-section mb-16">
          <div className="text-center mb-8">
            <h2 className="text-2xl lg:text-3xl font-montserrat font-medium text-foreground mb-4">
              Find Our Campus
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto font-montserrat font-normal">
              Located in the heart of Springs, Gauteng - easily accessible by road and public transport with ample parking available.
            </p>
          </div>
          
          <Map 
            address="Wilma Court Building office number 12 1floor, Springs, Gauteng 1559, South Africa"
            className="max-w-4xl mx-auto"
          />
        </section>

        <BottomNavigation currentPage="contact" />
      </div>
      <Toaster />
    </div>
  );
}