import { HeroSection } from '../components/sections/HeroSection';
import { ProgramsSection } from '../components/sections/ProgramsSection';
import { AboutSection } from '../components/sections/AboutSection';
import { BottomNavigation } from '../components/common/BottomNavigation';

export function HomePage() {
  return (
    <div className="home-page">
      <HeroSection />
      <ProgramsSection />
      <AboutSection />
      <BottomNavigation currentPage="home" />
    </div>
  );
}