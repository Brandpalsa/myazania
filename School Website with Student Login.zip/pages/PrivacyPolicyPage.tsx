import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { BottomNavigation } from '../components/common/BottomNavigation';
import { Shield, Eye, Lock, UserCheck, Database, Bell } from 'lucide-react';

export function PrivacyPolicyPage() {
  const lastUpdated = "January 15, 2025";

  const sections = [
    {
      icon: Eye,
      title: "Information We Collect",
      content: [
        {
          subtitle: "Personal Information",
          details: [
            "Full name, email address, and phone number",
            "Physical address and postal code",
            "Date of birth and identification documents",
            "Educational background and qualifications",
            "Employment history and references",
            "Emergency contact information"
          ]
        },
        {
          subtitle: "Academic Information",
          details: [
            "Course enrollment and attendance records",
            "Academic performance and assessment results",
            "Certification and qualification achievements",
            "Learning progress and feedback",
            "Portfolio submissions and projects"
          ]
        },
        {
          subtitle: "Technical Information",
          details: [
            "IP address and browser information",
            "Device information and operating system",
            "Usage patterns and website interactions",
            "Login times and session duration",
            "Preferred language and accessibility settings"
          ]
        }
      ]
    },
    {
      icon: Database,
      title: "How We Use Your Information",
      content: [
        {
          subtitle: "Educational Services",
          details: [
            "Process course applications and enrollments",
            "Deliver educational content and instruction",
            "Track academic progress and provide feedback",
            "Issue certificates and qualifications",
            "Provide student support and counseling services"
          ]
        },
        {
          subtitle: "Communication",
          details: [
            "Send important course updates and announcements",
            "Provide customer support and respond to inquiries",
            "Share information about new programs and services",
            "Send newsletter and educational content",
            "Conduct surveys and gather feedback"
          ]
        },
        {
          subtitle: "Legal and Compliance",
          details: [
            "Comply with educational regulations and standards",
            "Meet reporting requirements to education authorities",
            "Maintain accurate records as required by law",
            "Prevent fraud and ensure system security",
            "Resolve disputes and legal matters"
          ]
        }
      ]
    },
    {
      icon: Lock,
      title: "Information Security",
      content: [
        {
          subtitle: "Security Measures",
          details: [
            "Encrypted data transmission using SSL/TLS protocols",
            "Secure cloud storage with access controls",
            "Regular security audits and vulnerability assessments",
            "Multi-factor authentication for staff access",
            "Automated backup and disaster recovery systems"
          ]
        },
        {
          subtitle: "Access Controls",
          details: [
            "Role-based access to student information",
            "Regular review and update of user permissions",
            "Secure password requirements and policies",
            "Session timeout and automatic logout features",
            "Audit trails for all data access and modifications"
          ]
        }
      ]
    },
    {
      icon: UserCheck,
      title: "Information Sharing",
      content: [
        {
          subtitle: "Authorized Sharing",
          details: [
            "Educational institutions for credit transfer purposes",
            "Employers for job placement and verification services",
            "Professional bodies for certification and licensing",
            "Government agencies as required by law",
            "Service providers who assist in delivering our services"
          ]
        },
        {
          subtitle: "Third-Party Services",
          details: [
            "Learning management system providers",
            "Payment processing companies",
            "Email and communication service providers",
            "Cloud storage and hosting services",
            "Analytics and website optimization tools"
          ]
        }
      ]
    },
    {
      icon: Bell,
      title: "Your Rights",
      content: [
        {
          subtitle: "Access and Control",
          details: [
            "Request access to your personal information",
            "Update or correct inaccurate information",
            "Request deletion of your data where legally permissible",
            "Object to certain uses of your information",
            "Request data portability to another institution"
          ]
        },
        {
          subtitle: "Communication Preferences",
          details: [
            "Opt out of marketing communications",
            "Choose preferred communication channels",
            "Set frequency preferences for notifications",
            "Update contact information and preferences",
            "Withdraw consent for non-essential communications"
          ]
        }
      ]
    }
  ];

  return (
    <div className="page-transition min-h-screen bg-background text-foreground py-8">
      <div className="content-container max-w-4xl">
        {/* Page Header */}
        <header className="page-header text-center mb-12">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-gold" />
            </div>
            <h1 className="text-3xl lg:text-4xl font-montserrat font-semibold text-foreground">
              Privacy Policy
            </h1>
          </div>
          <div className="page-description">
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto font-montserrat font-light leading-relaxed">
              Your privacy is important to us. This policy explains how MyAzania Academy collects, 
              uses, and protects your personal information.
            </p>
            <p className="text-sm text-muted-foreground mt-4 font-montserrat font-normal">
              Last updated: {lastUpdated}
            </p>
          </div>
        </header>

        {/* Introduction */}
        <section className="introduction mb-12">
          <Card className="bg-card border-border">
            <CardContent className="p-8">
              <h2 className="text-xl font-montserrat font-medium text-card-foreground mb-4">Introduction</h2>
              <div className="space-y-4 text-muted-foreground font-montserrat font-normal leading-relaxed">
                <p>
                  MyAzania Academy ("we," "our," or "us") is committed to protecting and respecting your privacy. 
                  This Privacy Policy explains how we collect, use, disclose, and safeguard your information when 
                  you visit our website, enroll in our programs, or use our services.
                </p>
                <p>
                  By using our services, you consent to the collection and use of information in accordance with 
                  this policy. If you do not agree with our policies and practices, please do not use our services.
                </p>
                <p>
                  This policy complies with the Protection of Personal Information Act (POPIA) of South Africa 
                  and other applicable privacy laws and regulations.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Main Sections */}
        <div className="space-y-8 mb-12">
          {sections.map((section, index) => {
            const IconComponent = section.icon;
            return (
              <section key={index} className="policy-section">
                <Card className="bg-card border-border">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3 font-montserrat font-medium text-card-foreground">
                      <div className="w-8 h-8 bg-gold-100 dark:bg-gold-900/30 rounded-lg flex items-center justify-center">
                        <IconComponent className="w-4 h-4 text-gold" />
                      </div>
                      <span>{section.title}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {section.content.map((subsection, subIndex) => (
                      <div key={subIndex} className="subsection">
                        <h3 className="font-montserrat font-medium text-card-foreground mb-3">
                          {subsection.subtitle}
                        </h3>
                        <ul className="space-y-2">
                          {subsection.details.map((detail, detailIndex) => (
                            <li key={detailIndex} className="flex items-start space-x-2">
                              <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 flex-shrink-0"></div>
                              <span className="text-muted-foreground font-montserrat font-normal">
                                {detail}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </section>
            );
          })}
        </div>

        {/* Additional Information */}
        <section className="additional-info mb-12">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-montserrat font-medium text-card-foreground">
                Cookies and Tracking Technologies
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-muted-foreground font-montserrat font-normal leading-relaxed">
                <p className="mb-4">
                  We use cookies and similar tracking technologies to enhance your experience on our website. 
                  These technologies help us:
                </p>
                <ul className="space-y-2 mb-4">
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 flex-shrink-0"></div>
                    <span>Remember your preferences and settings</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 flex-shrink-0"></div>
                    <span>Understand how you use our website</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 flex-shrink-0"></div>
                    <span>Improve our services and user experience</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 flex-shrink-0"></div>
                    <span>Provide personalized content and recommendations</span>
                  </li>
                </ul>
                <p>
                  You can control cookie settings through your browser preferences. However, disabling cookies 
                  may affect the functionality of our website.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Data Retention */}
        <section className="data-retention mb-12">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="font-montserrat font-medium text-card-foreground">
                Data Retention
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-muted-foreground font-montserrat font-normal leading-relaxed space-y-4">
                <p>
                  We retain your personal information for as long as necessary to fulfill the purposes for which 
                  it was collected, including:
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-montserrat font-medium text-card-foreground mb-2">Student Records</h4>
                    <ul className="space-y-1 text-sm">
                      <li>• Academic records: 7 years after graduation</li>
                      <li>• Financial records: 5 years after completion</li>
                      <li>• Certification records: Permanently</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-montserrat font-medium text-card-foreground mb-2">Marketing Data</h4>
                    <ul className="space-y-1 text-sm">
                      <li>• Newsletter subscriptions: Until unsubscribed</li>
                      <li>• Website analytics: 26 months</li>
                      <li>• Communication logs: 3 years</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Contact Information */}
        <section className="contact-info">
          <Card className="bg-primary text-primary-foreground">
            <CardContent className="p-8">
              <h2 className="text-xl font-montserrat font-medium mb-4">Contact Us About Your Privacy</h2>
              <div className="text-primary-foreground/80 font-montserrat font-light leading-relaxed space-y-4">
                <p>
                  If you have any questions about this Privacy Policy, your personal information, or wish to 
                  exercise your rights, please contact us:
                </p>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-montserrat font-medium text-primary-foreground mb-2">General Inquiries</h3>
                    <p>Email: privacy@myazania.co.za</p>
                    <p>Phone: 065 324 8692</p>
                  </div>
                  <div>
                    <h3 className="font-montserrat font-medium text-primary-foreground mb-2">Data Protection Officer</h3>
                    <p>Email: dpo@myazania.co.za</p>
                    <p>Phone: 065 248 8692</p>
                  </div>
                </div>
                <p className="text-sm">
                  We will respond to your inquiry within 30 days as required by applicable privacy laws.
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        <BottomNavigation currentPage="legal" />
      </div>
    </div>
  );
}