import { 
  Code, TrendingUp, Scissors, Calculator, Headphones, Lightbulb, Shield, Heart,
  Wrench, Camera, Palette, Users, Stethoscope, Globe, Server, Briefcase 
} from 'lucide-react';

export interface ProgramModule {
  module: string;
  duration: string;
  topics: string[];
  description?: string;
}

export interface CareerPath {
  title: string;
  salaryRange: string;
  description: string;
}

export interface Certification {
  name: string;
  provider: string;
  description: string;
}

export interface IndustryPartnership {
  company: string;
  type: string;
  description: string;
}

export interface Program {
  id: string;
  title: string;
  description: string;
  fullDescription: string;
  duration: string;
  students: string;
  price: string;
  slug: string;
  features: string[];
  icon: any;
  gradient: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Professional';
  rating: number;
  curriculum: ProgramModule[];
  careerPaths: CareerPath[];
  certifications: Certification[];
  industryPartnerships: IndustryPartnership[];
  prerequisites: string[];
  outcomes: string[];
  tools: string[];
  jobPlacementRate: number;
  averageSalary: string;
  startDates: string[];
  schedule: string;
  assessmentMethods: string[];
  supportServices: string[];
  comingSoon?: boolean;
}

export const ALL_PROGRAMS: Program[] = [
  {
    id: 'basic-coding',
    title: 'Basic Coding',
    description: 'Learn fundamental programming skills with HTML, CSS, and JavaScript.',
    fullDescription: 'Our comprehensive Basic Coding program is designed for complete beginners who want to enter the exciting world of web development. Starting with the fundamental building blocks of the web - HTML and CSS - you\'ll progressively build your skills through JavaScript programming and modern frameworks like React.js. This hands-on program emphasizes practical project-based learning, ensuring you graduate with a portfolio of real-world applications.',
    duration: '6 months',
    students: '250+',
    price: 'R 8,500',
    slug: '/programs/basic-coding',
    features: ['HTML/CSS', 'JavaScript', 'React.js', 'Portfolio Projects'],
    icon: Code,
    gradient: 'from-blue-500/10 to-purple-500/10',
    level: 'Beginner',
    rating: 4.8,
    curriculum: [
      { 
        module: 'HTML Fundamentals', 
        duration: '2 weeks', 
        topics: ['Document Structure', 'Semantic Elements', 'Forms & Input Types', 'Accessibility Standards'],
        description: 'Master the foundational markup language of the web'
      },
      { 
        module: 'CSS Styling & Layout', 
        duration: '3 weeks', 
        topics: ['Selectors & Properties', 'Flexbox & Grid', 'Responsive Design', 'CSS Animations'],
        description: 'Create beautiful, responsive layouts and animations'
      },
      { 
        module: 'JavaScript Programming', 
        duration: '4 weeks', 
        topics: ['Variables & Functions', 'DOM Manipulation', 'Event Handling', 'ES6+ Features'],
        description: 'Add interactivity and dynamic functionality to web pages'
      },
      { 
        module: 'React.js Framework', 
        duration: '6 weeks', 
        topics: ['Components & JSX', 'State Management', 'Props & Events', 'Hooks & Context'],
        description: 'Build modern single-page applications with React'
      },
      { 
        module: 'Portfolio Development', 
        duration: '3 weeks', 
        topics: ['Project Planning', 'Code Organization', 'Deployment', 'Version Control'],
        description: 'Create professional projects for your portfolio'
      }
    ],
    careerPaths: [
      { title: 'Frontend Developer', salaryRange: 'R 25,000 - R 45,000', description: 'Build user interfaces and web applications' },
      { title: 'Web Developer', salaryRange: 'R 22,000 - R 40,000', description: 'Create and maintain websites for businesses' },
      { title: 'Junior Software Developer', salaryRange: 'R 20,000 - R 35,000', description: 'Join development teams in various industries' },
      { title: 'UI Developer', salaryRange: 'R 28,000 - R 50,000', description: 'Specialize in user interface design and implementation' },
      { title: 'Freelance Developer', salaryRange: 'R 300 - R 800/hour', description: 'Work independently on client projects' }
    ],
    certifications: [
      { name: 'Web Development Certificate', provider: 'Azania Academy', description: 'Industry-recognized certification of completion' },
      { name: 'React Developer Certificate', provider: 'Meta', description: 'Preparation for Meta React certification' }
    ],
    industryPartnerships: [
      { company: 'WebFlow Studios', type: 'Internship Partner', description: 'Guaranteed internship opportunities for top graduates' },
      { company: 'CodeSpace', type: 'Training Partner', description: 'Joint curriculum development and mentorship' }
    ],
    prerequisites: ['Basic computer literacy', 'High school mathematics'],
    outcomes: ['Build responsive websites', 'Create interactive web applications', 'Use modern development tools', 'Work with version control systems'],
    tools: ['VS Code', 'Git/GitHub', 'Chrome DevTools', 'Figma', 'Netlify'],
    jobPlacementRate: 85,
    averageSalary: 'R 28,000',
    startDates: ['February 2025', 'May 2025', 'August 2025', 'November 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 3:00 PM',
    assessmentMethods: ['Project-based assessments', 'Code reviews', 'Practical exams', 'Portfolio presentation'],
    supportServices: ['Career counseling', 'Interview preparation', 'Resume building', 'Job placement assistance']
  },
  {
    id: 'digital-marketing',
    title: 'Digital Marketing',
    description: 'Master social media, SEO, and online advertising strategies.',
    fullDescription: 'In today\'s digital-first world, businesses need skilled digital marketers who understand the complexities of online customer engagement. Our Digital Marketing program covers everything from social media strategy and content creation to search engine optimization and paid advertising campaigns. You\'ll learn to use industry-standard tools and platforms while developing campaigns that drive real business results.',
    duration: '5 months',
    students: '180+',
    price: 'R 7,800',
    slug: '/programs/digital-marketing',
    features: ['Social Media Marketing', 'SEO/SEM', 'Google Ads', 'Analytics & Reporting'],
    icon: TrendingUp,
    gradient: 'from-green-500/10 to-teal-500/10',
    level: 'Intermediate',
    rating: 4.7,
    curriculum: [
      { 
        module: 'Digital Marketing Fundamentals', 
        duration: '2 weeks', 
        topics: ['Marketing Strategy', 'Customer Personas', 'Digital Channels', 'Campaign Planning'],
        description: 'Build a strong foundation in digital marketing principles'
      },
      { 
        module: 'Social Media Marketing', 
        duration: '3 weeks', 
        topics: ['Platform Strategies', 'Content Creation', 'Community Management', 'Influencer Marketing'],
        description: 'Master social media platforms and engagement strategies'
      },
      { 
        module: 'Search Engine Optimization', 
        duration: '3 weeks', 
        topics: ['Keyword Research', 'On-page SEO', 'Link Building', 'Technical SEO'],
        description: 'Improve website visibility in search results'
      },
      { 
        module: 'Paid Advertising', 
        duration: '4 weeks', 
        topics: ['Google Ads', 'Facebook Ads', 'Display Advertising', 'Campaign Optimization'],
        description: 'Create and manage profitable advertising campaigns'
      },
      { 
        module: 'Analytics & Reporting', 
        duration: '3 weeks', 
        topics: ['Google Analytics', 'Data Interpretation', 'ROI Measurement', 'Performance Reports'],
        description: 'Track, analyze, and optimize marketing performance'
      }
    ],
    careerPaths: [
      { title: 'Digital Marketing Specialist', salaryRange: 'R 20,000 - R 35,000', description: 'Execute comprehensive digital marketing campaigns' },
      { title: 'Social Media Manager', salaryRange: 'R 18,000 - R 32,000', description: 'Manage brand presence across social platforms' },
      { title: 'SEO Specialist', salaryRange: 'R 22,000 - R 38,000', description: 'Optimize websites for search engine visibility' },
      { title: 'PPC Campaign Manager', salaryRange: 'R 25,000 - R 40,000', description: 'Manage paid advertising campaigns' },
      { title: 'Digital Marketing Consultant', salaryRange: 'R 400 - R 1,000/hour', description: 'Provide strategic marketing advice to businesses' }
    ],
    certifications: [
      { name: 'Google Ads Certification', provider: 'Google', description: 'Industry-standard certification for paid advertising' },
      { name: 'Facebook Blueprint Certification', provider: 'Meta', description: 'Official social media advertising certification' },
      { name: 'Digital Marketing Certificate', provider: 'Azania Academy', description: 'Comprehensive program completion certificate' }
    ],
    industryPartnerships: [
      { company: 'Digital Boost', type: 'Agency Partner', description: 'Internship and job placement opportunities' },
      { company: 'Social Spark', type: 'Training Partner', description: 'Real client project opportunities' }
    ],
    prerequisites: ['Basic computer skills', 'Social media familiarity'],
    outcomes: ['Create effective marketing campaigns', 'Analyze marketing data', 'Manage social media accounts', 'Optimize websites for search engines'],
    tools: ['Google Ads', 'Facebook Ads Manager', 'Google Analytics', 'Hootsuite', 'SEMrush'],
    jobPlacementRate: 78,
    averageSalary: 'R 26,000',
    startDates: ['January 2025', 'April 2025', 'July 2025', 'October 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 2:00 PM',
    assessmentMethods: ['Campaign projects', 'Analytics reports', 'Certification exams', 'Client presentations'],
    supportServices: ['Portfolio development', 'Networking events', 'Industry mentorship', 'Job placement support']
  },
  {
    id: 'beauty-therapy',
    title: 'Beauty Therapy & More',
    description: 'Comprehensive beauty and wellness training with industry certification.',
    fullDescription: 'Our Beauty Therapy & More program is a comprehensive training course that prepares you for a successful career in the beauty and wellness industry. This hands-on program covers everything from basic skincare and nail technology to advanced treatments and salon management. You\'ll gain practical experience in our fully equipped training salon while preparing for internationally recognized certifications.',
    duration: '8 months',
    students: '120+',
    price: 'R 12,500',
    slug: '/programs/beauty-therapy',
    features: ['Facial Treatments', 'Nail Technology', 'Hair Styling', 'CIDESCO Preparation'],
    icon: Scissors,
    gradient: 'from-pink-500/10 to-rose-500/10',
    level: 'Professional',
    rating: 4.9,
    curriculum: [
      { 
        module: 'Anatomy & Physiology', 
        duration: '2 weeks', 
        topics: ['Skin Structure', 'Nail Anatomy', 'Hair Growth Cycles', 'Health & Safety'],
        description: 'Understand the science behind beauty treatments'
      },
      { 
        module: 'Facial Treatments', 
        duration: '6 weeks', 
        topics: ['Skin Analysis', 'Cleansing Techniques', 'Facial Massage', 'Anti-aging Treatments'],
        description: 'Master professional facial therapy techniques'
      },
      { 
        module: 'Nail Technology', 
        duration: '4 weeks', 
        topics: ['Manicure & Pedicure', 'Nail Art', 'Gel Applications', 'Nail Health'],
        description: 'Complete nail care and artistic applications'
      },
      { 
        module: 'Hair Care & Styling', 
        duration: '5 weeks', 
        topics: ['Hair Analysis', 'Cutting Techniques', 'Styling Methods', 'Chemical Treatments'],
        description: 'Professional hair care and styling skills'
      },
      { 
        module: 'Salon Management', 
        duration: '3 weeks', 
        topics: ['Client Relations', 'Business Operations', 'Product Knowledge', 'Marketing'],
        description: 'Run a successful beauty business'
      }
    ],
    careerPaths: [
      { title: 'Beauty Therapist', salaryRange: 'R 15,000 - R 25,000', description: 'Provide comprehensive beauty treatments' },
      { title: 'Nail Technician', salaryRange: 'R 12,000 - R 22,000', description: 'Specialize in nail care and art' },
      { title: 'Salon Owner', salaryRange: 'R 30,000 - R 80,000', description: 'Own and operate a beauty salon' },
      { title: 'Freelance Beauty Specialist', salaryRange: 'R 200 - R 500/hour', description: 'Mobile beauty services' },
      { title: 'Spa Therapist', salaryRange: 'R 18,000 - R 30,000', description: 'Work in luxury spa environments' }
    ],
    certifications: [
      { name: 'CIDESCO Diploma', provider: 'CIDESCO International', description: 'World\'s most prestigious beauty therapy qualification' },
      { name: 'SAAHSP Certificate', provider: 'South African Association of Health & Skincare Professionals', description: 'National professional registration' },
      { name: 'Beauty Therapy Certificate', provider: 'Azania Academy', description: 'Comprehensive program completion certificate' }
    ],
    industryPartnerships: [
      { company: 'Sorbet', type: 'Employment Partner', description: 'Direct employment opportunities' },
      { company: 'Skin Renewal', type: 'Training Partner', description: 'Advanced treatment training' }
    ],
    prerequisites: ['Grade 12 or equivalent', 'Basic health certification'],
    outcomes: ['Perform professional beauty treatments', 'Manage client consultations', 'Operate salon equipment', 'Build a loyal client base'],
    tools: ['Professional beauty equipment', 'Treatment products', 'Sterilization systems', 'POS systems'],
    jobPlacementRate: 92,
    averageSalary: 'R 20,000',
    startDates: ['February 2025', 'June 2025', 'September 2025'],
    schedule: 'Monday to Friday, 8:00 AM - 4:00 PM',
    assessmentMethods: ['Practical assessments', 'Client treatments', 'Theory exams', 'Portfolio reviews'],
    supportServices: ['Equipment training', 'Product supplier contacts', 'Business setup guidance', 'Continuing education']
  },
  {
    id: 'bookkeeping-payroll',
    title: 'Bookkeeping & Payroll',
    description: 'Master financial record keeping and payroll management systems.',
    fullDescription: 'Our Bookkeeping & Payroll program provides comprehensive training in financial record keeping, payroll processing, and business accounting principles. You\'ll learn to use industry-standard software like QuickBooks and Pastel while understanding South African tax laws and compliance requirements. This program prepares you for immediate employment in accounting firms, businesses, or as an independent bookkeeping consultant.',
    duration: '4 months',
    students: '160+',
    price: 'R 6,500',
    slug: '/programs/bookkeeping-payroll',
    features: ['QuickBooks', 'Pastel Accounting', 'VAT Returns', 'Financial Reporting'],
    icon: Calculator,
    gradient: 'from-emerald-500/10 to-teal-500/10',
    level: 'Intermediate',
    rating: 4.6,
    curriculum: [
      { 
        module: 'Accounting Fundamentals', 
        duration: '2 weeks', 
        topics: ['Double Entry', 'Chart of Accounts', 'Financial Statements', 'Business Documents'],
        description: 'Build a solid foundation in accounting principles'
      },
      { 
        module: 'QuickBooks Training', 
        duration: '3 weeks', 
        topics: ['Setup & Configuration', 'Transaction Recording', 'Reporting', 'Bank Reconciliation'],
        description: 'Master the leading small business accounting software'
      },
      { 
        module: 'Pastel Accounting', 
        duration: '3 weeks', 
        topics: ['System Setup', 'Ledger Management', 'VAT Processing', 'Month-end Procedures'],
        description: 'Learn South Africa\'s popular accounting software'
      },
      { 
        module: 'Payroll Management', 
        duration: '3 weeks', 
        topics: ['Payroll Setup', 'Tax Calculations', 'UIF & PAYE', 'Payslip Generation'],
        description: 'Process payroll accurately and efficiently'
      },
      { 
        module: 'Tax Compliance', 
        duration: '3 weeks', 
        topics: ['VAT Returns', 'PAYE Submissions', 'Year-end Procedures', 'SARS Requirements'],
        description: 'Ensure full compliance with South African tax law'
      }
    ],
    careerPaths: [
      { title: 'Bookkeeper', salaryRange: 'R 15,000 - R 28,000', description: 'Maintain financial records for businesses' },
      { title: 'Payroll Clerk', salaryRange: 'R 12,000 - R 22,000', description: 'Process employee payroll and benefits' },
      { title: 'Accounting Assistant', salaryRange: 'R 18,000 - R 30,000', description: 'Support qualified accountants' },
      { title: 'Financial Administrator', salaryRange: 'R 20,000 - R 35,000', description: 'Manage financial operations' },
      { title: 'Independent Bookkeeper', salaryRange: 'R 200 - R 400/hour', description: 'Provide bookkeeping services to multiple clients' }
    ],
    certifications: [
      { name: 'QuickBooks Certification', provider: 'Intuit', description: 'Official QuickBooks proficiency certification' },
      { name: 'Pastel Partner Certification', provider: 'Sage', description: 'Certified Pastel software specialist' },
      { name: 'Bookkeeping Certificate', provider: 'Azania Academy', description: 'Comprehensive program completion certificate' }
    ],
    industryPartnerships: [
      { company: 'PKF Cape Town', type: 'Training Partner', description: 'Practical training opportunities' },
      { company: 'BDO South Africa', type: 'Employment Partner', description: 'Graduate placement program' }
    ],
    prerequisites: ['Grade 12 mathematics', 'Basic computer literacy'],
    outcomes: ['Maintain accurate financial records', 'Process payroll efficiently', 'Prepare VAT returns', 'Use accounting software proficiently'],
    tools: ['QuickBooks', 'Pastel Accounting', 'Excel', 'SARS eFiling', 'Banking software'],
    jobPlacementRate: 88,
    averageSalary: 'R 22,000',
    startDates: ['January 2025', 'March 2025', 'July 2025', 'September 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 2:00 PM',
    assessmentMethods: ['Software proficiency tests', 'Practical assignments', 'Case studies', 'Tax return preparation'],
    supportServices: ['Job placement assistance', 'Software licensing', 'Continuing education', 'Professional networking']
  },
  {
    id: 'customer-service',
    title: 'Customer Service Excellence',
    description: 'Develop exceptional customer service and communication skills.',
    fullDescription: 'In any industry, exceptional customer service is what sets businesses apart. Our Customer Service Excellence program develops the communication, problem-solving, and relationship management skills that employers value most. You\'ll learn to handle difficult situations with confidence, use customer relationship management systems effectively, and create positive experiences that build customer loyalty.',
    duration: '3 months',
    students: '200+',
    price: 'R 4,500',
    slug: '/programs/customer-service',
    features: ['Communication Skills', 'Conflict Resolution', 'CRM Systems', 'Quality Assurance'],
    icon: Headphones,
    gradient: 'from-purple-500/10 to-indigo-500/10',
    level: 'Beginner',
    rating: 4.5,
    curriculum: [
      { 
        module: 'Communication Fundamentals', 
        duration: '2 weeks', 
        topics: ['Active Listening', 'Verbal Communication', 'Written Communication', 'Body Language'],
        description: 'Master the basics of effective communication'
      },
      { 
        module: 'Customer Psychology', 
        duration: '2 weeks', 
        topics: ['Customer Behavior', 'Emotional Intelligence', 'Cultural Sensitivity', 'Service Recovery'],
        description: 'Understand what motivates customer behavior'
      },
      { 
        module: 'Conflict Resolution', 
        duration: '3 weeks', 
        topics: ['De-escalation Techniques', 'Problem Solving', 'Negotiation Skills', 'Complaint Handling'],
        description: 'Turn challenging situations into positive outcomes'
      },
      { 
        module: 'CRM Systems & Technology', 
        duration: '2 weeks', 
        topics: ['CRM Software', 'Help Desk Systems', 'Live Chat Support', 'Social Media Response'],
        description: 'Use technology to enhance customer service'
      },
      { 
        module: 'Quality & Performance Management', 
        duration: '3 weeks', 
        topics: ['Service Standards', 'Performance Metrics', 'Continuous Improvement', 'Team Leadership'],
        description: 'Maintain and improve service quality standards'
      }
    ],
    careerPaths: [
      { title: 'Customer Service Representative', salaryRange: 'R 10,000 - R 18,000', description: 'Handle customer inquiries and support' },
      { title: 'Call Center Agent', salaryRange: 'R 8,000 - R 15,000', description: 'Provide telephone customer support' },
      { title: 'Customer Success Manager', salaryRange: 'R 25,000 - R 40,000', description: 'Ensure customer satisfaction and retention' },
      { title: 'Team Leader', salaryRange: 'R 20,000 - R 30,000', description: 'Lead customer service teams' },
      { title: 'Customer Experience Specialist', salaryRange: 'R 18,000 - R 28,000', description: 'Design and improve customer experiences' }
    ],
    certifications: [
      { name: 'Customer Service Excellence Certificate', provider: 'Azania Academy', description: 'Comprehensive customer service certification' },
      { name: 'CCSP Certification', provider: 'Customer Care Institute', description: 'Certified Customer Service Professional' }
    ],
    industryPartnerships: [
      { company: 'Capitec Bank', type: 'Employment Partner', description: 'Call center employment opportunities' },
      { company: 'Discovery', type: 'Training Partner', description: 'Real-world customer service experience' }
    ],
    prerequisites: ['Grade 12 or equivalent', 'Good communication skills'],
    outcomes: ['Handle customer inquiries professionally', 'Resolve conflicts effectively', 'Use CRM systems efficiently', 'Lead customer service teams'],
    tools: ['CRM software', 'Help desk systems', 'Communication platforms', 'Performance dashboards'],
    jobPlacementRate: 95,
    averageSalary: 'R 16,000',
    startDates: ['Every month'],
    schedule: 'Monday to Friday, 9:00 AM - 1:00 PM',
    assessmentMethods: ['Role-playing exercises', 'Customer interaction simulations', 'Written assessments', 'Practical evaluations'],
    supportServices: ['Interview coaching', 'Communication skills development', 'Job placement assistance', 'Career progression guidance']
  },
  {
    id: 'entrepreneurship',
    title: 'Entrepreneurship Development',
    description: 'Build business skills and create your own successful venture.',
    fullDescription: 'Turn your business ideas into reality with our comprehensive Entrepreneurship Development program. This intensive course covers everything from business planning and financial management to marketing and leadership skills. You\'ll develop a complete business plan, learn to access funding opportunities, and gain the confidence to launch and grow your own successful business venture.',
    duration: '6 months',
    students: '150+',
    price: 'R 9,200',
    slug: '/programs/entrepreneurship',
    features: ['Business Planning', 'Financial Management', 'Marketing Strategy', 'Leadership Development'],
    icon: Lightbulb,
    gradient: 'from-orange-500/10 to-red-500/10',
    level: 'Advanced',
    rating: 4.8,
    curriculum: [
      { 
        module: 'Business Fundamentals', 
        duration: '3 weeks', 
        topics: ['Business Models', 'Market Research', 'Competitive Analysis', 'Value Propositions'],
        description: 'Understand the foundations of successful businesses'
      },
      { 
        module: 'Business Planning', 
        duration: '4 weeks', 
        topics: ['Business Plan Development', 'Financial Projections', 'Risk Assessment', 'Implementation Strategy'],
        description: 'Create a comprehensive business plan'
      },
      { 
        module: 'Financial Management', 
        duration: '4 weeks', 
        topics: ['Cash Flow Management', 'Funding Options', 'Investment Strategies', 'Financial Controls'],
        description: 'Manage business finances effectively'
      },
      { 
        module: 'Marketing & Sales', 
        duration: '4 weeks', 
        topics: ['Marketing Strategy', 'Brand Development', 'Sales Techniques', 'Customer Acquisition'],
        description: 'Build and market your brand successfully'
      },
      { 
        module: 'Leadership & Operations', 
        duration: '3 weeks', 
        topics: ['Team Building', 'Operations Management', 'Legal Requirements', 'Growth Strategies'],
        description: 'Lead teams and scale your business'
      }
    ],
    careerPaths: [
      { title: 'Business Owner', salaryRange: 'R 20,000 - R 100,000+', description: 'Start and run your own business' },
      { title: 'Business Consultant', salaryRange: 'R 30,000 - R 60,000', description: 'Advise other entrepreneurs and businesses' },
      { title: 'Franchise Owner', salaryRange: 'R 25,000 - R 80,000', description: 'Own and operate franchise businesses' },
      { title: 'Business Development Manager', salaryRange: 'R 35,000 - R 55,000', description: 'Drive growth for established companies' },
      { title: 'Social Entrepreneur', salaryRange: 'Varies', description: 'Create businesses that solve social problems' }
    ],
    certifications: [
      { name: 'Entrepreneurship Certificate', provider: 'Azania Academy', description: 'Comprehensive entrepreneurship program completion' },
      { name: 'Small Business Development Certificate', provider: 'SEDA', description: 'Government-recognized business development certification' }
    ],
    industryPartnerships: [
      { company: 'SEDA', type: 'Development Partner', description: 'Business development support and funding access' },
      { company: 'Business Partners', type: 'Funding Partner', description: 'Access to business funding opportunities' }
    ],
    prerequisites: ['Business idea or interest', 'Basic numeracy skills'],
    outcomes: ['Develop complete business plans', 'Access funding opportunities', 'Launch successful businesses', 'Manage business operations effectively'],
    tools: ['Business planning software', 'Financial modeling tools', 'Marketing platforms', 'Project management systems'],
    jobPlacementRate: 70,
    averageSalary: 'R 45,000',
    startDates: ['February 2025', 'May 2025', 'August 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 3:00 PM',
    assessmentMethods: ['Business plan presentations', 'Financial modeling exercises', 'Market research projects', 'Pitch competitions'],
    supportServices: ['Mentorship program', 'Funding guidance', 'Legal advice', 'Networking events']
  },
  {
    id: 'health-safety',
    title: 'Health & Safety Management',
    description: 'Comprehensive workplace safety training and certification.',
    fullDescription: 'Workplace safety is a critical concern for all industries, and qualified health and safety professionals are in high demand. Our Health & Safety Management program provides comprehensive training in risk assessment, safety management systems, and regulatory compliance. You\'ll prepare for internationally recognized certifications while gaining practical experience in creating safer work environments.',
    duration: '2 months',
    students: '140+',
    price: 'R 3,800',
    slug: '/programs/health-safety',
    features: ['Risk Assessment', 'SAMTRAC Certification', 'Emergency Response', 'Compliance Management'],
    icon: Shield,
    gradient: 'from-cyan-500/10 to-blue-500/10',
    level: 'Professional',
    rating: 4.7,
    curriculum: [
      { 
        module: 'Safety Legislation', 
        duration: '1 week', 
        topics: ['OHS Act', 'Regulations', 'Legal Requirements', 'Compliance Auditing'],
        description: 'Understand South African safety legislation'
      },
      { 
        module: 'Risk Assessment', 
        duration: '2 weeks', 
        topics: ['Hazard Identification', 'Risk Analysis', 'Control Measures', 'HIRA Methodology'],
        description: 'Conduct comprehensive workplace risk assessments'
      },
      { 
        module: 'Safety Management Systems', 
        duration: '2 weeks', 
        topics: ['SMS Development', 'Policy Creation', 'Procedure Writing', 'Implementation Strategies'],
        description: 'Design and implement safety management systems'
      },
      { 
        module: 'Emergency Response', 
        duration: '1 week', 
        topics: ['Emergency Planning', 'Evacuation Procedures', 'First Aid', 'Crisis Management'],
        description: 'Prepare for and respond to workplace emergencies'
      },
      { 
        module: 'SAMTRAC Preparation', 
        duration: '2 weeks', 
        topics: ['SAMTRAC Syllabus', 'Exam Preparation', 'Case Studies', 'Practical Applications'],
        description: 'Prepare for SAMTRAC certification exam'
      }
    ],
    careerPaths: [
      { title: 'Safety Officer', salaryRange: 'R 20,000 - R 35,000', description: 'Ensure workplace safety compliance' },
      { title: 'Health & Safety Manager', salaryRange: 'R 35,000 - R 55,000', description: 'Manage organizational safety programs' },
      { title: 'Safety Consultant', salaryRange: 'R 400 - R 800/hour', description: 'Provide safety consulting services' },
      { title: 'Compliance Officer', salaryRange: 'R 25,000 - R 40,000', description: 'Ensure regulatory compliance' },
      { title: 'Risk Manager', salaryRange: 'R 40,000 - R 70,000', description: 'Manage organizational risk programs' }
    ],
    certifications: [
      { name: 'SAMTRAC Certificate', provider: 'NOSA', description: 'South African Mine and Tunnel Risk Assessment Certificate' },
      { name: 'Health & Safety Certificate', provider: 'Azania Academy', description: 'Comprehensive safety program completion' },
      { name: 'NEBOSH IGC', provider: 'NEBOSH', description: 'International General Certificate preparation' }
    ],
    industryPartnerships: [
      { company: 'NOSA', type: 'Certification Partner', description: 'Official SAMTRAC training provider' },
      { company: 'Anglo American', type: 'Industry Partner', description: 'Mining industry safety training' }
    ],
    prerequisites: ['Grade 12 or equivalent', 'Basic understanding of workplace environments'],
    outcomes: ['Conduct risk assessments', 'Develop safety policies', 'Manage safety programs', 'Ensure legal compliance'],
    tools: ['Risk assessment software', 'Safety management systems', 'Compliance databases', 'Emergency response tools'],
    jobPlacementRate: 90,
    averageSalary: 'R 32,000',
    startDates: ['January 2025', 'March 2025', 'May 2025', 'July 2025', 'September 2025', 'November 2025'],
    schedule: 'Monday to Friday, 8:00 AM - 4:00 PM',
    assessmentMethods: ['Written examinations', 'Practical assessments', 'Case study analysis', 'SAMTRAC exam preparation'],
    supportServices: ['Certification support', 'Industry connections', 'Continuing education', 'Professional development']
  },
  {
    id: 'life-skills',
    title: 'Life Skills Development',
    description: 'Essential personal and professional development skills for success.',
    fullDescription: 'Success in any career requires more than technical skills - it requires strong personal and professional capabilities. Our Life Skills Development program focuses on building the soft skills that employers value most: communication, emotional intelligence, time management, and leadership. These transferable skills will benefit you in any career path and help you advance professionally.',
    duration: '3 months',
    students: '170+',
    price: 'R 4,200',
    slug: '/programs/life-skills',
    features: ['Communication Skills', 'Time Management', 'Leadership Development', 'Emotional Intelligence'],
    icon: Heart,
    gradient: 'from-violet-500/10 to-purple-500/10',
    level: 'Beginner',
    rating: 4.6,
    curriculum: [
      { 
        module: 'Communication Excellence', 
        duration: '3 weeks', 
        topics: ['Verbal Communication', 'Written Communication', 'Presentation Skills', 'Cross-cultural Communication'],
        description: 'Master all forms of professional communication'
      },
      { 
        module: 'Emotional Intelligence', 
        duration: '3 weeks', 
        topics: ['Self-awareness', 'Empathy', 'Relationship Management', 'Stress Management'],
        description: 'Develop emotional intelligence for better relationships'
      },
      { 
        module: 'Time & Personal Management', 
        duration: '2 weeks', 
        topics: ['Time Management', 'Goal Setting', 'Productivity Techniques', 'Work-life Balance'],
        description: 'Manage time and personal resources effectively'
      },
      { 
        module: 'Leadership & Teamwork', 
        duration: '2 weeks', 
        topics: ['Leadership Styles', 'Team Dynamics', 'Conflict Resolution', 'Motivation Techniques'],
        description: 'Lead teams and work collaboratively'
      },
      { 
        module: 'Career Development', 
        duration: '2 weeks', 
        topics: ['Career Planning', 'Professional Networking', 'Interview Skills', 'Personal Branding'],
        description: 'Plan and advance your career strategically'
      }
    ],
    careerPaths: [
      { title: 'Team Leader', salaryRange: 'R 18,000 - R 30,000', description: 'Lead teams in various industries' },
      { title: 'Administrative Manager', salaryRange: 'R 20,000 - R 35,000', description: 'Manage administrative operations' },
      { title: 'Human Resources Assistant', salaryRange: 'R 15,000 - R 25,000', description: 'Support HR functions and employee development' },
      { title: 'Training Coordinator', salaryRange: 'R 22,000 - R 35,000', description: 'Coordinate employee training programs' },
      { title: 'Customer Relations Manager', salaryRange: 'R 25,000 - R 40,000', description: 'Manage customer relationships and satisfaction' }
    ],
    certifications: [
      { name: 'Life Skills Certificate', provider: 'Azania Academy', description: 'Comprehensive personal development certification' },
      { name: 'Professional Development Certificate', provider: 'Institute of People Management', description: 'Industry-recognized soft skills certification' }
    ],
    industryPartnerships: [
      { company: 'FNB', type: 'Development Partner', description: 'Leadership development opportunities' },
      { company: 'Shoprite Holdings', type: 'Employment Partner', description: 'Management trainee positions' }
    ],
    prerequisites: ['None - open to all levels'],
    outcomes: ['Communicate effectively in all situations', 'Lead teams confidently', 'Manage time and priorities', 'Build strong professional relationships'],
    tools: ['Personal development assessments', 'Goal tracking systems', 'Communication platforms', 'Leadership frameworks'],
    jobPlacementRate: 85,
    averageSalary: 'R 24,000',
    startDates: ['Every month'],
    schedule: 'Monday to Friday, 6:00 PM - 8:00 PM (Evening classes available)',
    assessmentMethods: ['Personal development portfolios', 'Presentation assessments', 'Team project evaluations', 'Peer feedback sessions'],
    supportServices: ['Career coaching', 'Personal mentorship', 'Networking opportunities', 'Continuing development resources']
  },
  // NEW "COMING SOON" PROGRAMS
  {
    id: 'project-management',
    title: 'Project Management Professional',
    description: 'Master project planning, execution, and delivery methodologies.',
    fullDescription: 'In today\'s fast-paced business environment, skilled project managers are essential for organizational success. Our Project Management Professional program covers traditional and agile methodologies, risk management, stakeholder communication, and team leadership. You\'ll prepare for internationally recognized certifications while managing real-world projects.',
    duration: '5 months',
    students: '0',
    price: 'R 11,500',
    slug: '/programs/project-management',
    features: ['PMP Preparation', 'Agile/Scrum', 'Risk Management', 'MS Project'],
    icon: Briefcase,
    gradient: 'from-indigo-500/10 to-purple-500/10',
    level: 'Advanced',
    rating: 0,
    curriculum: [
      { 
        module: 'Project Management Fundamentals', 
        duration: '3 weeks', 
        topics: ['Project Lifecycle', 'PMBOK Guide', 'Project Charter', 'Stakeholder Analysis'],
        description: 'Learn core project management principles and frameworks'
      },
      { 
        module: 'Planning & Scheduling', 
        duration: '4 weeks', 
        topics: ['Work Breakdown Structure', 'Critical Path Method', 'Resource Planning', 'MS Project'],
        description: 'Create detailed project plans and schedules'
      },
      { 
        module: 'Agile & Scrum Methodologies', 
        duration: '3 weeks', 
        topics: ['Scrum Framework', 'Sprint Planning', 'User Stories', 'Retrospectives'],
        description: 'Master agile project management approaches'
      },
      { 
        module: 'Risk & Quality Management', 
        duration: '3 weeks', 
        topics: ['Risk Assessment', 'Risk Mitigation', 'Quality Planning', 'Quality Assurance'],
        description: 'Manage project risks and ensure quality delivery'
      },
      { 
        module: 'Leadership & Communication', 
        duration: '3 weeks', 
        topics: ['Team Leadership', 'Stakeholder Communication', 'Conflict Resolution', 'Change Management'],
        description: 'Lead project teams and manage stakeholder relationships'
      }
    ],
    careerPaths: [
      { title: 'Project Manager', salaryRange: 'R 35,000 - R 65,000', description: 'Lead complex projects from initiation to closure' },
      { title: 'Scrum Master', salaryRange: 'R 40,000 - R 70,000', description: 'Facilitate agile development teams' },
      { title: 'Program Manager', salaryRange: 'R 50,000 - R 90,000', description: 'Oversee multiple related projects' },
      { title: 'Project Coordinator', salaryRange: 'R 25,000 - R 40,000', description: 'Support project management activities' },
      { title: 'PMO Analyst', salaryRange: 'R 30,000 - R 50,000', description: 'Support project management offices' }
    ],
    certifications: [
      { name: 'PMP Certification Prep', provider: 'PMI', description: 'Preparation for Project Management Professional certification' },
      { name: 'Certified Scrum Master', provider: 'Scrum Alliance', description: 'Agile project management certification' },
      { name: 'Project Management Certificate', provider: 'Azania Academy', description: 'Comprehensive program completion certificate' }
    ],
    industryPartnerships: [
      { company: 'Deloitte', type: 'Industry Partner', description: 'Real-world project opportunities' },
      { company: 'Standard Bank', type: 'Employment Partner', description: 'Project management roles in banking' }
    ],
    prerequisites: ['Bachelor\'s degree or 5 years work experience', 'Basic business knowledge'],
    outcomes: ['Plan and execute complex projects', 'Lead cross-functional teams', 'Manage project risks effectively', 'Deliver projects on time and budget'],
    tools: ['MS Project', 'Jira', 'Trello', 'Slack', 'Risk registers'],
    jobPlacementRate: 0,
    averageSalary: 'R 48,000',
    startDates: ['March 2025', 'July 2025', 'November 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 3:00 PM',
    assessmentMethods: ['Project deliverables', 'Case study analysis', 'Simulation exercises', 'Certification exam prep'],
    supportServices: ['Career coaching', 'Certification support', 'Industry networking', 'Alumni mentorship'],
    comingSoon: true
  },
  {
    id: 'graphic-design',
    title: 'Graphic Design & Visual Communication',
    description: 'Create compelling visual designs for print and digital media.',
    fullDescription: 'Visual communication is at the heart of modern marketing and branding. Our Graphic Design & Visual Communication program teaches you to create compelling designs using industry-standard software like Adobe Creative Suite. You\'ll develop a strong foundation in design principles while building a professional portfolio that showcases your creative abilities.',
    duration: '7 months',
    students: '0',
    price: 'R 10,800',
    slug: '/programs/graphic-design',
    features: ['Adobe Creative Suite', 'Brand Design', 'Print Design', 'Digital Media'],
    icon: Palette,
    gradient: 'from-pink-500/10 to-orange-500/10',
    level: 'Intermediate',
    rating: 0,
    curriculum: [
      { 
        module: 'Design Fundamentals', 
        duration: '3 weeks', 
        topics: ['Design Principles', 'Color Theory', 'Typography', 'Composition'],
        description: 'Master the foundational principles of visual design'
      },
      { 
        module: 'Adobe Photoshop', 
        duration: '4 weeks', 
        topics: ['Image Editing', 'Photo Manipulation', 'Digital Painting', 'Web Graphics'],
        description: 'Create and edit digital images professionally'
      },
      { 
        module: 'Adobe Illustrator', 
        duration: '4 weeks', 
        topics: ['Vector Graphics', 'Logo Design', 'Illustrations', 'Icon Creation'],
        description: 'Design scalable vector graphics and illustrations'
      },
      { 
        module: 'Adobe InDesign', 
        duration: '3 weeks', 
        topics: ['Layout Design', 'Print Publications', 'Document Design', 'Typography'],
        description: 'Create professional layouts for print and digital'
      },
      { 
        module: 'Brand Identity Design', 
        duration: '4 weeks', 
        topics: ['Brand Strategy', 'Logo Design', 'Brand Guidelines', 'Marketing Materials'],
        description: 'Develop complete brand identity systems'
      },
      { 
        module: 'Portfolio Development', 
        duration: '3 weeks', 
        topics: ['Portfolio Planning', 'Project Presentation', 'Client Communication', 'Freelancing'],
        description: 'Build a professional design portfolio'
      }
    ],
    careerPaths: [
      { title: 'Graphic Designer', salaryRange: 'R 18,000 - R 35,000', description: 'Create visual designs for various media' },
      { title: 'Brand Designer', salaryRange: 'R 25,000 - R 45,000', description: 'Develop brand identities and guidelines' },
      { title: 'UI/UX Designer', salaryRange: 'R 30,000 - R 55,000', description: 'Design user interfaces and experiences' },
      { title: 'Freelance Designer', salaryRange: 'R 300 - R 800/hour', description: 'Work independently on design projects' },
      { title: 'Art Director', salaryRange: 'R 40,000 - R 70,000', description: 'Lead creative teams and projects' }
    ],
    certifications: [
      { name: 'Adobe Certified Expert', provider: 'Adobe', description: 'Official Adobe software proficiency certification' },
      { name: 'Graphic Design Certificate', provider: 'Azania Academy', description: 'Comprehensive design program completion' }
    ],
    industryPartnerships: [
      { company: 'Ogilvy Cape Town', type: 'Industry Partner', description: 'Creative industry exposure and opportunities' },
      { company: 'King James Group', type: 'Training Partner', description: 'Real client project experience' }
    ],
    prerequisites: ['Creative interest', 'Basic computer skills', 'Portfolio review (preferred)'],
    outcomes: ['Create professional graphic designs', 'Use Adobe Creative Suite expertly', 'Develop brand identities', 'Build a strong design portfolio'],
    tools: ['Adobe Photoshop', 'Adobe Illustrator', 'Adobe InDesign', 'Sketch', 'Figma'],
    jobPlacementRate: 0,
    averageSalary: 'R 32,000',
    startDates: ['February 2025', 'June 2025', 'September 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 4:00 PM',
    assessmentMethods: ['Design projects', 'Portfolio reviews', 'Creative briefs', 'Client presentations'],
    supportServices: ['Portfolio development', 'Creative mentorship', 'Industry networking', 'Freelance guidance'],
    comingSoon: true
  },
  {
    id: 'data-analysis',
    title: 'Data Analysis & Business Intelligence',
    description: 'Transform raw data into actionable business insights.',
    fullDescription: 'In the age of big data, organizations need skilled professionals who can turn raw information into actionable insights. Our Data Analysis & Business Intelligence program teaches you to collect, analyze, and visualize data using tools like Excel, Power BI, and SQL. You\'ll learn statistical analysis, data visualization, and how to communicate findings to drive business decisions.',
    duration: '6 months',
    students: '0',
    price: 'R 9,800',
    slug: '/programs/data-analysis',
    features: ['Excel Advanced', 'Power BI', 'SQL Database', 'Statistical Analysis'],
    icon: TrendingUp,
    gradient: 'from-blue-500/10 to-green-500/10',
    level: 'Intermediate',
    rating: 0,
    curriculum: [
      { 
        module: 'Data Fundamentals', 
        duration: '2 weeks', 
        topics: ['Data Types', 'Data Quality', 'Data Sources', 'Data Ethics'],
        description: 'Understand the foundations of data analysis'
      },
      { 
        module: 'Advanced Excel', 
        duration: '4 weeks', 
        topics: ['Advanced Functions', 'Pivot Tables', 'Data Modeling', 'Automation'],
        description: 'Master Excel for complex data analysis'
      },
      { 
        module: 'SQL Database Queries', 
        duration: '4 weeks', 
        topics: ['SQL Basics', 'Complex Queries', 'Database Design', 'Data Extraction'],
        description: 'Extract and manipulate data from databases'
      },
      { 
        module: 'Statistical Analysis', 
        duration: '3 weeks', 
        topics: ['Descriptive Statistics', 'Hypothesis Testing', 'Regression Analysis', 'Forecasting'],
        description: 'Apply statistical methods to analyze data'
      },
      { 
        module: 'Power BI & Visualization', 
        duration: '4 weeks', 
        topics: ['Dashboard Creation', 'Data Modeling', 'DAX Functions', 'Report Design'],
        description: 'Create compelling data visualizations'
      },
      { 
        module: 'Business Intelligence', 
        duration: '3 weeks', 
        topics: ['KPI Development', 'Performance Metrics', 'Business Cases', 'Presentation Skills'],
        description: 'Transform analysis into business recommendations'
      }
    ],
    careerPaths: [
      { title: 'Data Analyst', salaryRange: 'R 25,000 - R 45,000', description: 'Analyze data to support business decisions' },
      { title: 'Business Intelligence Analyst', salaryRange: 'R 30,000 - R 55,000', description: 'Develop BI solutions and dashboards' },
      { title: 'Reporting Specialist', salaryRange: 'R 22,000 - R 38,000', description: 'Create automated reports and dashboards' },
      { title: 'Data Scientist', salaryRange: 'R 40,000 - R 80,000', description: 'Apply advanced analytics and machine learning' },
      { title: 'Business Analyst', salaryRange: 'R 28,000 - R 50,000', description: 'Bridge business and technical requirements' }
    ],
    certifications: [
      { name: 'Microsoft Power BI Certification', provider: 'Microsoft', description: 'Official Power BI proficiency certification' },
      { name: 'Data Analysis Certificate', provider: 'Azania Academy', description: 'Comprehensive data analysis program completion' }
    ],
    industryPartnerships: [
      { company: 'Nedbank', type: 'Industry Partner', description: 'Banking data analysis opportunities' },
      { company: 'MTN', type: 'Training Partner', description: 'Telecommunications data projects' }
    ],
    prerequisites: ['Strong mathematics background', 'Basic computer skills', 'Analytical mindset'],
    outcomes: ['Analyze complex datasets', 'Create interactive dashboards', 'Extract insights from databases', 'Present data-driven recommendations'],
    tools: ['Microsoft Excel', 'Power BI', 'SQL Server', 'Tableau', 'Python (basic)'],
    jobPlacementRate: 0,
    averageSalary: 'R 38,000',
    startDates: ['January 2025', 'April 2025', 'August 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 3:00 PM',
    assessmentMethods: ['Data analysis projects', 'Dashboard presentations', 'Case study solutions', 'Statistical analysis reports'],
    supportServices: ['Technical mentorship', 'Industry projects', 'Certification support', 'Career guidance'],
    comingSoon: true
  },
  {
    id: 'photography',
    title: 'Professional Photography & Videography',
    description: 'Master visual storytelling through photography and video production.',
    fullDescription: 'Visual content is driving modern communication and marketing. Our Professional Photography & Videography program teaches both traditional and digital photography techniques, video production, and post-production editing. You\'ll learn to tell compelling stories through images and video while building a professional portfolio that showcases your unique creative vision.',
    duration: '8 months',
    students: '0',
    price: 'R 13,500',
    slug: '/programs/photography',
    features: ['Digital Photography', 'Video Production', 'Adobe Creative Suite', 'Studio Lighting'],
    icon: Camera,
    gradient: 'from-purple-500/10 to-pink-500/10',
    level: 'Intermediate',
    rating: 0,
    curriculum: [
      { 
        module: 'Photography Fundamentals', 
        duration: '3 weeks', 
        topics: ['Camera Basics', 'Exposure Triangle', 'Composition Rules', 'Light & Shadow'],
        description: 'Master the technical and artistic foundations of photography'
      },
      { 
        module: 'Studio & Portrait Photography', 
        duration: '4 weeks', 
        topics: ['Studio Lighting', 'Portrait Techniques', 'Fashion Photography', 'Product Photography'],
        description: 'Create professional studio and portrait photographs'
      },
      { 
        module: 'Event & Documentary Photography', 
        duration: '3 weeks', 
        topics: ['Wedding Photography', 'Corporate Events', 'Photojournalism', 'Street Photography'],
        description: 'Capture compelling moments and tell visual stories'
      },
      { 
        module: 'Video Production', 
        duration: '5 weeks', 
        topics: ['Camera Operation', 'Shot Composition', 'Audio Recording', 'Interview Techniques'],
        description: 'Produce professional video content'
      },
      { 
        module: 'Post-Production Editing', 
        duration: '4 weeks', 
        topics: ['Adobe Lightroom', 'Adobe Photoshop', 'Adobe Premiere Pro', 'Color Grading'],
        description: 'Edit and enhance photos and videos professionally'
      },
      { 
        module: 'Business & Portfolio Development', 
        duration: '3 weeks', 
        topics: ['Portfolio Creation', 'Client Relations', 'Pricing Strategies', 'Marketing'],
        description: 'Build a successful photography business'
      }
    ],
    careerPaths: [
      { title: 'Professional Photographer', salaryRange: 'R 15,000 - R 50,000', description: 'Specialize in various photography genres' },
      { title: 'Wedding Photographer', salaryRange: 'R 25,000 - R 80,000', description: 'Capture wedding and special events' },
      { title: 'Commercial Photographer', salaryRange: 'R 30,000 - R 70,000', description: 'Create images for advertising and business' },
      { title: 'Video Producer', salaryRange: 'R 20,000 - R 45,000', description: 'Produce video content for various clients' },
      { title: 'Content Creator', salaryRange: 'R 18,000 - R 40,000', description: 'Create visual content for social media and marketing' }
    ],
    certifications: [
      { name: 'Professional Photography Certificate', provider: 'Azania Academy', description: 'Comprehensive photography program completion' },
      { name: 'Adobe Certified Expert', provider: 'Adobe', description: 'Certification in Adobe Creative Suite' }
    ],
    industryPartnerships: [
      { company: 'Orms Photo', type: 'Equipment Partner', description: 'Access to professional photography equipment' },
      { company: 'Cape Town Photography Studios', type: 'Training Partner', description: 'Studio access and professional mentorship' }
    ],
    prerequisites: ['Creative interest', 'Basic computer skills', 'Own camera (preferred but not required)'],
    outcomes: ['Create professional photographs', 'Produce high-quality videos', 'Edit visual content expertly', 'Run a photography business'],
    tools: ['Professional cameras', 'Studio lighting', 'Adobe Creative Suite', 'Video equipment'],
    jobPlacementRate: 0,
    averageSalary: 'R 35,000',
    startDates: ['February 2025', 'July 2025'],
    schedule: 'Monday to Friday, 9:00 AM - 4:00 PM',
    assessmentMethods: ['Photography portfolios', 'Video projects', 'Client simulations', 'Technical skills tests'],
    supportServices: ['Equipment training', 'Portfolio development', 'Business mentorship', 'Industry networking'],
    comingSoon: true
  }
];

export const ACTIVE_PROGRAMS = ALL_PROGRAMS.filter(program => !program.comingSoon);
export const COMING_SOON_PROGRAMS = ALL_PROGRAMS.filter(program => program.comingSoon);

export function getProgramById(id: string): Program | undefined {
  return ALL_PROGRAMS.find(program => program.id === id);
}

export function getProgramsByLevel(level: string): Program[] {
  return ALL_PROGRAMS.filter(program => program.level === level);
}

export function getFeaturedPrograms(count: number = 8): Program[] {
  return ACTIVE_PROGRAMS.slice(0, count);
}