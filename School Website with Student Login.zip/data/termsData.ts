import { FileText, Scale, GraduationCap, CreditCard, Shield, AlertTriangle } from 'lucide-react';

export const lastUpdated = "January 15, 2025";

export const termsSections = [
  {
    icon: Scale,
    title: "Acceptance of Terms",
    content: [
      "By accessing and using MyAzania Academy's services, you accept and agree to be bound by the terms and provision of this agreement.",
      "If you do not agree to abide by the above, please do not use this service.",
      "These terms apply to all visitors, users, and students of our services.",
      "We reserve the right to change these terms at any time with notice to users."
    ]
  },
  {
    icon: GraduationCap,
    title: "Educational Services",
    content: [
      "MyAzania Academy provides vocational training and skills development programs.",
      "Course content, schedules, and requirements are subject to change with reasonable notice.",
      "We strive to maintain high educational standards but do not guarantee specific outcomes.",
      "Students are responsible for meeting course requirements and deadlines.",
      "Completion certificates are awarded upon successful fulfillment of program requirements."
    ]
  },
  {
    icon: CreditCard,
    title: "Payment Terms",
    content: [
      "All fees must be paid according to the agreed payment schedule.",
      "Payment can be made in full or through approved installment plans.",
      "Late payments may incur additional charges as specified in your enrollment agreement.",
      "Refund policies are outlined in your specific program enrollment agreement.",
      "Non-payment may result in suspension of services or program termination."
    ]
  },
  {
    icon: Shield,
    title: "Student Responsibilities",
    content: [
      "Attend classes regularly and participate actively in program activities.",
      "Complete assignments and assessments within specified timeframes.",
      "Respect fellow students, instructors, and academy property.",
      "Maintain professional conduct during classes and academy events.",
      "Provide accurate information during enrollment and maintain updated contact details."
    ]
  },
  {
    icon: AlertTriangle,
    title: "Limitation of Liability",
    content: [
      "MyAzania Academy's liability is limited to the fees paid for services.",
      "We are not responsible for indirect, consequential, or punitive damages.",
      "The academy is not liable for any loss of data, profits, or business opportunities.",
      "Students participate in programs at their own risk and responsibility.",
      "Our liability does not extend to actions of third-party service providers."
    ]
  }
];

export const policies = [
  {
    title: "Enrollment and Registration",
    details: [
      "Students must meet minimum age and education requirements for program enrollment",
      "All application information must be accurate and complete",
      "Enrollment is subject to program availability and academy approval",
      "Students must provide required documentation for registration",
      "Program start dates are subject to minimum enrollment requirements"
    ]
  },
  {
    title: "Attendance and Academic Policies",
    details: [
      "Regular attendance is required for all scheduled classes and activities",
      "Students with excessive absences may be removed from the program",
      "Make-up sessions may be available for excused absences",
      "Academic progress is monitored and students will be notified of concerns",
      "Satisfactory progress must be maintained to continue in the program"
    ]
  },
  {
    title: "Code of Conduct",
    details: [
      "Students must maintain professional behavior at all times",
      "Discrimination, harassment, or violence will not be tolerated",
      "Use of academy resources must be for educational purposes only",
      "Students are responsible for their personal belongings",
      "Violations may result in disciplinary action or program termination"
    ]
  },
  {
    title: "Intellectual Property",
    details: [
      "All course materials and content are owned by MyAzania Academy",
      "Students may not reproduce or distribute academy materials without permission",
      "Student work created during programs may be used for academy promotional purposes",
      "Students retain rights to their original creative work and projects",
      "Third-party materials are used under appropriate licensing agreements"
    ]
  }
];