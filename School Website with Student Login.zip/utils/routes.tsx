// Page imports
import { HomePage } from '../components/pages/HomePage';
import { ProgramsPage } from '../components/pages/ProgramsPage';
import { AboutPage } from '../components/pages/AboutPage';
import { ContactPage } from '../components/pages/ContactPage';

// Program page imports - Active Programs
import { BasicCodingPage } from '../components/pages/programs/BasicCodingPage';
import { DigitalMarketingPage } from '../components/pages/programs/DigitalMarketingPage';
import { BeautyTherapyPage } from '../components/pages/programs/BeautyTherapyPage';
import { BookkeepingPayrollPage } from '../components/pages/programs/BookkeepingPayrollPage';
import { CustomerServicePage } from '../components/pages/programs/CustomerServicePage';
import { EntrepreneurshipPage } from '../components/pages/programs/EntrepreneurshipPage';
import { HealthSafetyPage } from '../components/pages/programs/HealthSafetyPage';
import { LifeSkillsPage } from '../components/pages/programs/LifeSkillsPage';

// Program page imports - Coming Soon Programs  
import { ProjectManagementPage } from '../components/pages/programs/ProjectManagementPage';
import { GraphicDesignPage } from '../components/pages/programs/GraphicDesignPage';
import { DataAnalysisPage } from '../components/pages/programs/DataAnalysisPage';
import { PhotographyPage } from '../components/pages/programs/PhotographyPage';

// Auth and Dashboard imports
import { LoginPage } from '../components/auth/LoginPage';
import { StudentDashboard } from '../components/dashboards/StudentDashboard';
import { TeacherDashboard } from '../components/dashboards/TeacherDashboard';
import { AdminDashboard } from '../components/dashboards/AdminDashboard';

export interface RouteConfig {
  path: string;
  component: React.ComponentType;
  requiresAuth?: boolean;
  allowedRoles?: string[];
  isPublic?: boolean;
}

export const PUBLIC_ROUTES: RouteConfig[] = [
  { path: '/', component: HomePage, isPublic: true },
  { path: '/programs', component: ProgramsPage, isPublic: true },
  { path: '/about', component: AboutPage, isPublic: true },
  { path: '/contact', component: ContactPage, isPublic: true },
  
  // Active Programs
  { path: '/programs/basic-coding', component: BasicCodingPage, isPublic: true },
  { path: '/programs/digital-marketing', component: DigitalMarketingPage, isPublic: true },
  { path: '/programs/beauty-therapy', component: BeautyTherapyPage, isPublic: true },
  { path: '/programs/bookkeeping-payroll', component: BookkeepingPayrollPage, isPublic: true },
  { path: '/programs/customer-service', component: CustomerServicePage, isPublic: true },
  { path: '/programs/entrepreneurship', component: EntrepreneurshipPage, isPublic: true },
  { path: '/programs/health-safety', component: HealthSafetyPage, isPublic: true },
  { path: '/programs/life-skills', component: LifeSkillsPage, isPublic: true },
  
  // Coming Soon Programs
  { path: '/programs/project-management', component: ProjectManagementPage, isPublic: true },
  { path: '/programs/graphic-design', component: GraphicDesignPage, isPublic: true },
  { path: '/programs/data-analysis', component: DataAnalysisPage, isPublic: true },
  { path: '/programs/photography', component: PhotographyPage, isPublic: true },
];

export const AUTH_ROUTES: RouteConfig[] = [
  { path: '/login', component: LoginPage, isPublic: true },
];

export const PROTECTED_ROUTES: RouteConfig[] = [
  { path: '/dashboard', component: StudentDashboard, requiresAuth: true, allowedRoles: ['student', 'teacher', 'admin'] },
  { path: '/student-dashboard', component: StudentDashboard, requiresAuth: true, allowedRoles: ['student'] },
  { path: '/teacher-dashboard', component: TeacherDashboard, requiresAuth: true, allowedRoles: ['teacher', 'admin'] },
  { path: '/admin-dashboard', component: AdminDashboard, requiresAuth: true, allowedRoles: ['admin'] },
];

export const ALL_ROUTES = [...PUBLIC_ROUTES, ...AUTH_ROUTES, ...PROTECTED_ROUTES];

export function getRouteByPath(path: string): RouteConfig | undefined {
  return ALL_ROUTES.find(route => route.path === path);
}

export function getDashboardComponentByRole(role: string): React.ComponentType {
  switch (role) {
    case 'student':
      return StudentDashboard;
    case 'teacher':
      return TeacherDashboard;
    case 'admin':
      return AdminDashboard;
    default:
      return StudentDashboard;
  }
}