// Comprehensive brochure content generator using HTML download approach

// Academy and program data with real contact information
const academyData = {
  name: 'Azania Academy',
  tagline: 'Transform Your Future with Skills-Focused Training',
  description: 'Empowering South Africans with practical skills and qualifications for career success. Join thousands who have transformed their lives through our comprehensive training programs.',
  contact: {
    phone: '065 324 8692',
    email: 'academy@myazania.co.za',
    address: 'Wilma Court Building office number 12 1floor, Springs, Gauteng 1559, South Africa',
    website: 'www.myazania.co.za'
  },
  stats: {
    programs: '8+ Training Programs',
    graduates: '1000+ Students Graduated',
    placement: '95% Job Placement Rate'
  }
};

const programs = [
  {
    title: 'Basic Coding',
    description: 'Learn fundamental programming skills with HTML, CSS, and JavaScript.',
    duration: '6 months',
    price: 'R 8,500',
    features: ['HTML/CSS', 'JavaScript', 'React.js', 'Portfolio Projects'],
    career: 'Web Developer, Frontend Developer, Junior Programmer'
  },
  {
    title: 'Digital Marketing',
    description: 'Master social media, SEO, and online advertising strategies.',
    duration: '5 months',
    price: 'R 7,800',
    features: ['Social Media', 'SEO', 'Google Ads', 'Analytics'],
    career: 'Digital Marketer, Social Media Manager, SEO Specialist'
  },
  {
    title: 'Beauty Therapy & More',
    description: 'Comprehensive beauty and wellness training with industry certification.',
    duration: '8 months',
    price: 'R 12,500',
    features: ['Facial Treatments', 'Nail Technology', 'Hair Styling', 'CIDESCO Prep'],
    career: 'Beauty Therapist, Salon Owner, Wellness Consultant'
  },
  {
    title: 'Bookkeeping & Payroll',
    description: 'Master financial record keeping and payroll management systems.',
    duration: '4 months',
    price: 'R 6,500',
    features: ['QuickBooks', 'Pastel', 'VAT Returns', 'Financial Reports'],
    career: 'Bookkeeper, Payroll Administrator, Financial Clerk'
  },
  {
    title: 'Customer Service Excellence',
    description: 'Develop exceptional customer service and communication skills.',
    duration: '3 months',
    price: 'R 4,500',
    features: ['Communication Skills', 'Conflict Resolution', 'CRM Systems', 'Quality Service'],
    career: 'Customer Service Rep, Call Center Agent, Client Relations'
  },
  {
    title: 'Entrepreneurship Development',
    description: 'Build business skills and create your own successful venture.',
    duration: '6 months',
    price: 'R 9,200',
    features: ['Business Planning', 'Financial Management', 'Marketing', 'Leadership'],
    career: 'Business Owner, Startup Founder, Business Consultant'
  },
  {
    title: 'Health & Safety Management',
    description: 'Comprehensive workplace safety training and certification.',
    duration: '2 months',
    price: 'R 3,800',
    features: ['Risk Assessment', 'SAMTRAC', 'Emergency Response', 'Compliance'],
    career: 'Safety Officer, Health & Safety Manager, Compliance Officer'
  },
  {
    title: 'Life Skills Development',
    description: 'Essential personal and professional development skills for success.',
    duration: '3 months',
    price: 'R 4,200',
    features: ['Communication', 'Time Management', 'Leadership', 'Emotional Intelligence'],
    career: 'Team Leader, Supervisor, Personal Development Coach'
  }
];

// Colors matching the light theme
const colors = {
  primary: '#141414',      // --foreground
  gold: '#9B7E46',         // --accent (chamoisee)
  lightGrey: '#A79D7F',    // --muted-foreground
  veryLightGrey: '#F5F6F5', // --muted
  white: '#FFFFFF',        // --background
  border: '#D9DEDB'        // --secondary
};

// Generate comprehensive brochure content as HTML and create downloadable file
export function generateBrochurePDF(): void {
  // Show loading notification
  console.log('Generating brochure...');
  
  // Create comprehensive brochure HTML
  const brochureHTML = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Azania Academy - Complete Program Brochure</title>
      <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Montserrat', sans-serif;
          line-height: 1.6;
          color: #141414;
          background: #FFFFFF;
        }
        
        .page {
          width: 210mm;
          min-height: 297mm;
          margin: 0 auto;
          background: white;
          padding: 20mm;
          page-break-after: always;
        }
        
        .page:last-child {
          page-break-after: avoid;
        }
        
        .header-section {
          background: linear-gradient(135deg, #9B7E46, #A79D7F);
          color: white;
          text-align: center;
          padding: 40px 20px;
          margin: -20mm -20mm 30px -20mm;
          border-radius: 0 0 20px 20px;
        }
        
        .academy-name {
          font-size: 2.5em;
          font-weight: 700;
          margin-bottom: 10px;
        }
        
        .tagline {
          font-size: 1.2em;
          font-weight: 300;
          opacity: 0.95;
        }
        
        .section-header {
          background: #9B7E46;
          color: white;
          padding: 15px 20px;
          margin: 0 -20mm 20px -20mm;
          font-size: 1.5em;
          font-weight: 600;
        }
        
        .description {
          font-size: 1.1em;
          text-align: center;
          margin: 30px 0;
          color: #141414;
          line-height: 1.8;
        }
        
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
          margin: 40px 0;
          text-align: center;
        }
        
        .stat-item {
          background: #F5F6F5;
          padding: 25px 15px;
          border-radius: 10px;
          border-left: 4px solid #9B7E46;
        }
        
        .stat-number {
          font-size: 2em;
          font-weight: 700;
          color: #9B7E46;
          margin-bottom: 5px;
        }
        
        .stat-label {
          font-weight: 500;
          color: #141414;
        }
        
        .contact-section {
          background: #F5F6F5;
          padding: 25px;
          border-radius: 10px;
          margin: 30px 0;
        }
        
        .contact-title {
          color: #9B7E46;
          font-weight: 600;
          font-size: 1.3em;
          margin-bottom: 15px;
        }
        
        .contact-info {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 15px;
        }
        
        .program-header {
          background: #9B7E46;
          color: white;
          text-align: center;
          padding: 30px 20px;
          margin: -20mm -20mm 30px -20mm;
          font-size: 1.8em;
          font-weight: 600;
        }
        
        .program-overview {
          background: #F5F6F5;
          padding: 20px;
          border-radius: 10px;
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 20px;
          margin-bottom: 25px;
        }
        
        .overview-item {
          text-align: center;
        }
        
        .overview-label {
          font-weight: 600;
          color: #9B7E46;
          font-size: 1.1em;
        }
        
        .overview-value {
          font-size: 1.3em;
          font-weight: 500;
          color: #141414;
          margin-top: 5px;
        }
        
        .program-description {
          font-size: 1.1em;
          margin: 25px 0;
          line-height: 1.8;
        }
        
        .skills-section, .career-section {
          margin: 25px 0;
        }
        
        .section-title {
          color: #9B7E46;
          font-weight: 600;
          font-size: 1.2em;
          margin-bottom: 15px;
        }
        
        .skills-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
        }
        
        .skill-item {
          background: #F5F6F5;
          padding: 12px 15px;
          border-radius: 8px;
          border-left: 3px solid #9B7E46;
        }
        
        .career-opportunities {
          background: #F5F6F5;
          padding: 20px;
          border-radius: 10px;
          line-height: 1.8;
        }
        
        .cta-section {
          background: linear-gradient(135deg, #9B7E46, #A79D7F);
          color: white;
          text-align: center;
          padding: 30px;
          border-radius: 15px;
          margin: 30px 0;
        }
        
        .steps-list {
          counter-reset: step-counter;
          list-style: none;
          margin: 25px 0;
        }
        
        .steps-list li {
          counter-increment: step-counter;
          padding: 15px 0;
          border-bottom: 1px solid #D9DEDB;
          position: relative;
          padding-left: 50px;
        }
        
        .steps-list li:before {
          content: counter(step-counter);
          position: absolute;
          left: 0;
          top: 15px;
          width: 30px;
          height: 30px;
          background: #9B7E46;
          color: white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
        }
        
        .footer-info {
          text-align: center;
          color: #A79D7F;
          font-size: 0.9em;
          margin-top: 40px;
          padding-top: 20px;
          border-top: 2px solid #D9DEDB;
        }
        
        @media print {
          .page {
            margin: 0;
            box-shadow: none;
            width: 100%;
            min-height: 100vh;
          }
          
          body {
            margin: 0;
          }
          
          .no-print {
            display: none !important;
          }
        }
        
        .print-button {
          position: fixed;
          top: 20px;
          right: 20px;
          background: #9B7E46;
          color: white;
          border: none;
          padding: 12px 20px;
          border-radius: 8px;
          font-family: 'Montserrat', sans-serif;
          font-weight: 500;
          cursor: pointer;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15);
          z-index: 10000;
        }
        
        .print-button:hover {
          background: #876c3e;
        }
      </style>
    </head>
    <body>
      <!-- Print Button -->
      <button class="print-button no-print" onclick="window.print()">🖨️ Print This Brochure</button>
      <!-- COVER PAGE -->
      <div class="page">
        <div class="header-section">
          <div class="academy-name">${academyData.name}</div>
          <div class="tagline">${academyData.tagline}</div>
        </div>
        
        <div class="description">
          ${academyData.description}
        </div>
        
        <div class="stats-grid">
          <div class="stat-item">
            <div class="stat-number">8+</div>
            <div class="stat-label">Training Programs</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">1000+</div>
            <div class="stat-label">Students Graduated</div>
          </div>
          <div class="stat-item">
            <div class="stat-number">95%</div>
            <div class="stat-label">Job Placement Rate</div>
          </div>
        </div>
        
        <div class="contact-section">
          <div class="contact-title">Contact Information</div>
          <div class="contact-info">
            <div><strong>Phone:</strong> ${academyData.contact.phone}</div>
            <div><strong>Email:</strong> ${academyData.contact.email}</div>
            <div><strong>Website:</strong> ${academyData.contact.website}</div>
            <div><strong>Address:</strong> ${academyData.contact.address}</div>
          </div>
        </div>
      </div>
      
      ${programs.map(program => `
        <!-- PROGRAM PAGE: ${program.title} -->
        <div class="page">
          <div class="program-header">${program.title}</div>
          
          <div class="program-overview">
            <div class="overview-item">
              <div class="overview-label">Duration</div>
              <div class="overview-value">${program.duration}</div>
            </div>
            <div class="overview-item">
              <div class="overview-label">Investment</div>
              <div class="overview-value">${program.price}</div>
            </div>
          </div>
          
          <div class="program-description">
            ${program.description}
          </div>
          
          <div class="skills-section">
            <div class="section-title">Key Skills You'll Learn</div>
            <div class="skills-grid">
              ${program.features.map(feature => `<div class="skill-item">${feature}</div>`).join('')}
            </div>
          </div>
          
          <div class="career-section">
            <div class="section-title">Career Opportunities</div>
            <div class="career-opportunities">
              ${program.career}
            </div>
          </div>
          
          <div class="cta-section">
            <h3>Ready to Start Your Journey?</h3>
            <p>Contact us today to enroll in this program and transform your future!</p>
          </div>
        </div>
      `).join('')}
      
      <!-- FINAL PAGE - HOW TO APPLY -->
      <div class="page">
        <div class="section-header">Take the Next Step</div>
        
        <div class="description">
          Transform Your Future Today - Join Our Community of Successful Graduates
        </div>
        
        <div class="section-title">How to Apply:</div>
        <ol class="steps-list">
          <li>Choose your preferred program from our comprehensive offerings</li>
          <li>Contact us via phone, email, or visit our campus for consultation</li>
          <li>Complete the application process with our friendly admissions team</li>
          <li>Secure your spot with flexible payment options available</li>
          <li>Start your journey to career success with expert instruction</li>
        </ol>
        
        <div class="contact-section">
          <div class="contact-title">Get In Touch</div>
          <div class="contact-info">
            <div>📞 <strong>Phone:</strong> ${academyData.contact.phone}</div>
            <div>✉️ <strong>Email:</strong> ${academyData.contact.email}</div>
            <div>🌐 <strong>Website:</strong> ${academyData.contact.website}</div>
            <div>📍 <strong>Address:</strong> ${academyData.contact.address}</div>
          </div>
        </div>
        
        <div class="footer-info">
          <div>© 2024 Azania Academy. All rights reserved.</div>
          <div>Accredited Skills Training Programs for Career Success</div>
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    console.log('Creating brochure blob...');
    
    // Create downloadable HTML file
    const blob = new Blob([brochureHTML], { type: 'text/html;charset=utf-8' });
    console.log('Blob created, size:', blob.size);
    
    const url = URL.createObjectURL(blob);
    console.log('Object URL created:', url);
    
    // Create download link
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = 'Azania-Academy-Complete-Brochure.html';
    downloadLink.style.display = 'none';
    
    // Add to document, click, and remove
    document.body.appendChild(downloadLink);
    console.log('Download link added to document');
    
    // Force download
    downloadLink.click();
    console.log('Download link clicked');
    
    document.body.removeChild(downloadLink);
    console.log('Download link removed from document');
    
    // Clean up the URL object
    setTimeout(() => {
      URL.revokeObjectURL(url);
      console.log('Object URL revoked');
    }, 100);
    
    console.log('Brochure download initiated successfully');
    
  } catch (error) {
    console.error('Error generating brochure:', error);
    
    // Fallback: Try creating a simpler download
    try {
      console.log('Attempting fallback download...');
      
      // Create a simpler HTML version for testing
      const simpleHTML = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Azania Academy Brochure</title>
          <meta charset="UTF-8">
        </head>
        <body>
          <h1>Azania Academy</h1>
          <p>Transform Your Future with Skills-Focused Training</p>
          <p>This is a test brochure. If you can see this, the download is working!</p>
        </body>
        </html>
      `;
      
      const simpleBlob = new Blob([simpleHTML], { type: 'text/html;charset=utf-8' });
      const simpleUrl = URL.createObjectURL(simpleBlob);
      
      const testLink = document.createElement('a');
      testLink.href = simpleUrl;
      testLink.download = 'Azania-Academy-Test-Brochure.html';
      testLink.style.display = 'none';
      
      document.body.appendChild(testLink);
      testLink.click();
      document.body.removeChild(testLink);
      
      setTimeout(() => URL.revokeObjectURL(simpleUrl), 100);
      
      console.log('Fallback download completed');
      
    } catch (fallbackError) {
      console.error('Fallback also failed:', fallbackError);
      
      // Last resort: Open in new tab
      try {
        const printWindow = window.open('data:text/html;charset=utf-8,' + encodeURIComponent(brochureHTML), '_blank');
        if (printWindow) {
          printWindow.focus();
          console.log('Brochure opened in new tab as final fallback');
        } else {
          console.error('All download methods failed');
          throw new Error('All download methods failed');
        }
      } catch (finalError) {
        console.error('All methods failed:', finalError);
        throw finalError;
      }
    }
  }
}