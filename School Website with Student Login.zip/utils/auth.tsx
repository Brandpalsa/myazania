import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { projectId, publicAnonKey } from './supabase/info';
import { toast } from 'sonner@2.0.3';
import { router } from './router';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'teacher' | 'admin';
}

interface UserData {
  id: string;
  email: string;
  name: string;
  role: string;
  enrolledCourses?: string[];
  assignedCourses?: string[];
  profile: {
    phone: string;
    address: string;
    joinDate: string;
    progress?: { [courseId: string]: number };
    specialization?: string;
    experience?: string;
  };
  notifications?: Array<{
    id: string;
    message: string;
    date: string;
    read: boolean;
  }>;
}

interface AuthContextType {
  user: User | null;
  userData: UserData | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string, role?: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

// Demo mode enabled by default - change to false when server is fully deployed
const DEMO_MODE = true;

// Helper function to get dashboard path based on user role
function getDashboardPath(role: string): string {
  switch (role) {
    case 'admin':
      return '/admin-dashboard';
    case 'teacher':
      return '/teacher-dashboard';
    case 'student':
    default:
      return '/student-dashboard';
  }
}

// Demo users for development
const DEMO_USERS = {
  'student@azania.edu': {
    password: 'student123',
    user: { id: 'demo-student', email: 'student@azania.edu', name: 'Demo Student', role: 'student' as const },
    userData: {
      id: 'demo-student',
      email: 'student@azania.edu',
      name: 'Demo Student',
      role: 'student',
      enrolledCourses: ['basic-coding', 'digital-marketing'],
      profile: {
        phone: '+27 12 345 6789',
        address: '123 Student Street, Cape Town',
        joinDate: '2024-01-15T10:00:00Z',
        progress: { 'basic-coding': 65, 'digital-marketing': 30 }
      },
      notifications: [
        { id: '1', message: 'Welcome to Azania Academy!', date: '2024-01-15T10:00:00Z', read: false },
        { id: '2', message: 'New assignment available in Basic Coding', date: '2024-01-20T14:30:00Z', read: true }
      ]
    }
  },
  'teacher@azania.edu': {
    password: 'teacher123',
    user: { id: 'demo-teacher', email: 'teacher@azania.edu', name: 'Demo Teacher', role: 'teacher' as const },
    userData: {
      id: 'demo-teacher',
      email: 'teacher@azania.edu',
      name: 'Demo Teacher',
      role: 'teacher',
      assignedCourses: ['basic-coding'],
      profile: {
        phone: '+27 12 345 6790',
        address: '456 Teacher Avenue, Johannesburg',
        joinDate: '2023-08-01T09:00:00Z',
        specialization: 'Web Development',
        experience: '5 years'
      },
      notifications: [
        { id: '1', message: 'Welcome to the teaching platform!', date: '2023-08-01T09:00:00Z', read: true }
      ]
    }
  },
  'admin@azania.edu': {
    password: 'admin123',
    user: { id: 'demo-admin', email: 'admin@azania.edu', name: 'Demo Admin', role: 'admin' as const },
    userData: {
      id: 'demo-admin',
      email: 'admin@azania.edu',
      name: 'Demo Admin',
      role: 'admin',
      profile: {
        phone: '+27 12 345 6791',
        address: '789 Admin Boulevard, Pretoria',
        joinDate: '2023-01-01T08:00:00Z'
      },
      notifications: [
        { id: '1', message: 'Admin dashboard ready', date: '2023-01-01T08:00:00Z', read: true }
      ]
    }
  }
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  const makeRequest = async (endpoint: string, options: RequestInit = {}) => {
    try {
      const serverUrl = `https://${projectId}.supabase.co/functions/v1/make-server-8c6b9460${endpoint}`;
      console.log('Making request to:', serverUrl);

      const response = await fetch(serverUrl, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('auth_token') || publicAnonKey}`,
          ...options.headers,
        },
      });

      console.log('Response status:', response.status);

      if (!response.ok) {
        let errorMessage = 'Request failed';
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorMessage;
        } catch {
          errorMessage = `HTTP ${response.status}: ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }

      return response.json();
    } catch (error) {
      console.error('Request failed:', error);
      throw error;
    }
  };

  const loginWithDemo = (email: string, password: string) => {
    const demoUser = DEMO_USERS[email as keyof typeof DEMO_USERS];
    if (demoUser && demoUser.password === password) {
      setUser(demoUser.user);
      setUserData(demoUser.userData);
      localStorage.setItem('auth_token', `demo-${demoUser.user.id}`);
      toast.success(`Welcome back, ${demoUser.user.name}! (Demo Mode)`);
      return true;
    }
    return false;
  };

  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      
      // Try demo login first if demo mode is enabled
      if (DEMO_MODE) {
        const demoUser = DEMO_USERS[email as keyof typeof DEMO_USERS];
        if (loginWithDemo(email, password)) {
          // Navigate to appropriate dashboard after successful login
          const dashboardPath = getDashboardPath(demoUser.user.role);
          setTimeout(() => router.navigate(dashboardPath), 100);
          return;
        } else {
          throw new Error('Invalid demo credentials. Please use the provided demo accounts.');
        }
      }

      // Try server authentication
      try {
        const data = await makeRequest('/auth/signin', {
          method: 'POST',
          body: JSON.stringify({ email, password }),
        });

        setUser(data.user);
        setUserData(data.userData);
        localStorage.setItem('auth_token', data.access_token);
        
        toast.success(`Welcome back, ${data.user.name}!`);
        
        // Navigate to appropriate dashboard after successful login
        const dashboardPath = getDashboardPath(data.user.role);
        setTimeout(() => router.navigate(dashboardPath), 100);
      } catch (serverError) {
        console.log('Server authentication failed, trying demo mode...', serverError);
        
        // Fallback to demo mode if server fails
        const fallbackDemoUser = DEMO_USERS[email as keyof typeof DEMO_USERS];
        if (loginWithDemo(email, password)) {
          const dashboardPath = getDashboardPath(fallbackDemoUser.user.role);
          setTimeout(() => router.navigate(dashboardPath), 100);
          return;
        }
        
        // If demo also fails, show appropriate error
        const errorMessage = serverError instanceof Error ? serverError.message : 'Authentication failed';
        
        if (errorMessage.includes('Invalid login credentials') || errorMessage.includes('invalid_credentials')) {
          throw new Error('Invalid email or password. Please check your credentials or use the demo accounts provided.');
        } else if (errorMessage.includes('Server unavailable') || errorMessage.includes('fetch')) {
          throw new Error('Authentication server is currently unavailable. Using demo mode - please try the demo accounts.');
        } else {
          throw new Error(errorMessage);
        }
      }
    } catch (error) {
      console.error('Login error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Login failed';
      toast.error(errorMessage);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, password: string, name: string, role: string = 'student') => {
    try {
      setLoading(true);
      
      if (DEMO_MODE) {
        toast.info('Demo mode: Signup functionality is limited. Use existing demo accounts.');
        throw new Error('Signup not available in demo mode');
      }

      const data = await makeRequest('/auth/signup', {
        method: 'POST',
        body: JSON.stringify({ email, password, name, role }),
      });

      toast.success('Account created successfully! Please login with your credentials.');
    } catch (error) {
      console.error('Signup error:', error);
      const errorMessage = error instanceof Error ? error.message : 'Signup failed';
      toast.error(errorMessage);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setUserData(null);
    localStorage.removeItem('auth_token');
    toast.success('Logged out successfully');
    // Navigate to login page after logout
    setTimeout(() => router.navigate('/login'), 100);
  };

  const refreshUser = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      if (!token) {
        setLoading(false);
        return;
      }

      // Handle demo mode
      if (token.startsWith('demo-')) {
        const demoUserId = token.replace('demo-', '');
        const demoUser = Object.values(DEMO_USERS).find(u => u.user.id === demoUserId);
        if (demoUser) {
          setUser(demoUser.user);
          setUserData(demoUser.userData);
        } else {
          localStorage.removeItem('auth_token');
        }
        setLoading(false);
        return;
      }

      if (DEMO_MODE) {
        localStorage.removeItem('auth_token');
        setLoading(false);
        return;
      }

      // Try server refresh
      try {
        const data = await makeRequest('/auth/me');
        setUser(data.user);
        setUserData(data.userData);
      } catch (serverError) {
        console.log('Server refresh failed, clearing token:', serverError);
        localStorage.removeItem('auth_token');
        setUser(null);
        setUserData(null);
      }
    } catch (error) {
      console.error('Refresh user error:', error);
      localStorage.removeItem('auth_token');
      setUser(null);
      setUserData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      try {
        console.log('Initializing auth... Demo mode:', DEMO_MODE);
        const token = localStorage.getItem('auth_token');
        
        if (token) {
          console.log('Token found, refreshing user...');
          await refreshUser();
        } else {
          console.log('No token found, setting loading to false');
          setLoading(false);
        }
      } catch (error) {
        console.error('Auth initialization error:', error);
        setLoading(false);
      }
    };

    // Add a timeout to prevent infinite loading
    const timeoutId = setTimeout(() => {
      console.log('Auth initialization timeout, forcing loading to false');
      setLoading(false);
    }, 3000); // Reduced timeout for demo mode

    initAuth().finally(() => {
      clearTimeout(timeoutId);
    });

    return () => {
      clearTimeout(timeoutId);
    };
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      userData,
      loading,
      login,
      signup,
      logout,
      refreshUser,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}