// Simple client-side router implementation with enhanced debugging

interface Route {
  path: string;
  title: string;
}

class Router {
  private currentPath: string = '/';
  private listeners: (() => void)[] = [];

  private routes: Route[] = [
    { path: '/', title: 'Home' },
    { path: '/programs', title: 'Programs' },
    { path: '/about', title: 'About' },
    { path: '/contact', title: 'Contact' },
    { path: '/login', title: 'Login' },
    { path: '/dashboard', title: 'Dashboard' },
    { path: '/student-dashboard', title: 'Student Dashboard' },
    { path: '/teacher-dashboard', title: 'Teacher Dashboard' },
    { path: '/admin-dashboard', title: 'Admin Dashboard' },
    
    // Program pages
    { path: '/programs/basic-coding', title: 'Basic Coding' },
    { path: '/programs/digital-marketing', title: 'Digital Marketing' },
    { path: '/programs/beauty-therapy', title: 'Beauty Therapy & More' },
    { path: '/programs/bookkeeping-payroll', title: 'Bookkeeping & Payroll' },
    { path: '/programs/customer-service', title: 'Customer Service Excellence' },
    { path: '/programs/entrepreneurship', title: 'Entrepreneurship Development' },
    { path: '/programs/health-safety', title: 'Health & Safety Management' },
    { path: '/programs/life-skills', title: 'Life Skills Development' },

    // Legal pages
    { path: '/privacy-policy', title: 'Privacy Policy' },
    { path: '/terms-of-service', title: 'Terms of Service' },
    { path: '/cookie-policy', title: 'Cookie Policy' },
  ];

  constructor() {
    this.init();
  }

  private init() {
    // Get initial path from URL
    this.currentPath = window.location.pathname || '/';
    console.log('Router initialized with path:', this.currentPath);

    // Listen for browser navigation
    window.addEventListener('popstate', () => {
      this.currentPath = window.location.pathname || '/';
      console.log('Popstate event, new path:', this.currentPath);
      this.notifyListeners();
    });

    // Handle initial load
    setTimeout(() => {
      console.log('Router initial notification');
      this.notifyListeners();
    }, 100);
  }

  navigate(path: string) {
    console.log('Navigating to:', path);
    if (path !== this.currentPath) {
      this.currentPath = path;
      window.history.pushState({}, '', path);
      this.notifyListeners();
    }
  }

  getCurrentRoute(): Route | null {
    const route = this.routes.find(r => r.path === this.currentPath);
    console.log('Getting current route for path:', this.currentPath, 'found:', route);
    return route || { path: this.currentPath, title: 'Page' };
  }

  subscribe(listener: () => void): () => void {
    console.log('Adding router listener');
    this.listeners.push(listener);
    
    return () => {
      console.log('Removing router listener');
      const index = this.listeners.indexOf(listener);
      if (index > -1) {
        this.listeners.splice(index, 1);
      }
    };
  }

  private notifyListeners() {
    console.log('Notifying', this.listeners.length, 'router listeners');
    this.listeners.forEach(listener => {
      try {
        listener();
      } catch (error) {
        console.error('Error in router listener:', error);
      }
    });
  }
}

// Create router instance
export const router = new Router();

// Link component for navigation
interface LinkProps {
  to: string;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export function Link({ to, children, className, onClick }: LinkProps) {
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    onClick?.();
    router.navigate(to);
  };

  return (
    <a href={to} onClick={handleClick} className={className}>
      {children}
    </a>
  );
}

// Hook to use router in components
export function useRouter() {
  const [currentRoute, setCurrentRoute] = React.useState<Route | null>(router.getCurrentRoute());

  React.useEffect(() => {
    const unsubscribe = router.subscribe(() => {
      setCurrentRoute(router.getCurrentRoute());
    });

    return unsubscribe;
  }, []);

  return { currentRoute, navigate: router.navigate.bind(router) };
}

// Import React for the useRouter hook
import React from 'react';