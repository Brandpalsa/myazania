import { useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Header } from '../components/common/Header';
import { Footer } from '../components/common/Footer';
import { ThemeProvider } from '../components/providers/ThemeProvider';
import { useRouter } from '../utils/router';

interface DefaultTemplateProps {
  children: React.ReactNode;
  pageClass?: string;
}

const pageVariants = {
  initial: {
    opacity: 0,
    y: 20,
    scale: 0.98
  },
  in: {
    opacity: 1,
    y: 0,
    scale: 1
  },
  out: {
    opacity: 0,
    y: -20,
    scale: 1.02
  }
};

const pageTransition = {
  type: "tween",
  ease: "anticipate",
  duration: 0.5
};

export function DefaultTemplate({ children, pageClass = '' }: DefaultTemplateProps) {
  const { currentRoute } = useRouter();
  
  // Ensure scroll to top on route changes
  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'instant'
    });
  }, [currentRoute?.path]);
  
  return (
    <ThemeProvider>
      <motion.div 
        className={`min-h-screen bg-background text-foreground theme-transition ${pageClass}`}
        initial="initial"
        animate="in"
        exit="out"
        variants={pageVariants}
        transition={pageTransition}
      >
        <Header />
        <AnimatePresence mode="wait">
          <motion.main 
            key={currentRoute?.path || 'default'}
            className="main-content relative"
            initial="initial"
            animate="in"
            exit="out"
            variants={pageVariants}
            transition={pageTransition}
          >
            {children}
          </motion.main>
        </AnimatePresence>
        <Footer />
      </motion.div>
    </ThemeProvider>
  );
}