import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Initialize Supabase clients
const supabaseServiceRole = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
);

const supabaseAnon = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_ANON_KEY')!,
);

// Demo users data
const DEMO_USERS = [
  {
    email: 'student@azania.edu',
    password: 'student123',
    name: 'Demo Student',
    role: 'student',
    profile: {
      phone: '+27 12 345 6789',
      address: '123 Student Street, Cape Town',
      joinDate: '2024-01-15T10:00:00Z',
      progress: { 'basic-coding': 65, 'digital-marketing': 30 }
    },
    enrolledCourses: ['basic-coding', 'digital-marketing'],
    notifications: [
      { id: '1', message: 'Welcome to Azania Academy!', date: '2024-01-15T10:00:00Z', read: false },
      { id: '2', message: 'New assignment available in Basic Coding', date: '2024-01-20T14:30:00Z', read: true }
    ]
  },
  {
    email: 'teacher@azania.edu',
    password: 'teacher123',
    name: 'Demo Teacher',
    role: 'teacher',
    profile: {
      phone: '+27 12 345 6790',
      address: '456 Teacher Avenue, Johannesburg',
      joinDate: '2023-08-01T09:00:00Z',
      specialization: 'Web Development',
      experience: '5 years'
    },
    assignedCourses: ['basic-coding'],
    notifications: [
      { id: '1', message: 'Welcome to the teaching platform!', date: '2023-08-01T09:00:00Z', read: true }
    ]
  },
  {
    email: 'admin@azania.edu',
    password: 'admin123',
    name: 'Demo Admin',
    role: 'admin',
    profile: {
      phone: '+27 12 345 6791',
      address: '789 Admin Boulevard, Pretoria',
      joinDate: '2023-01-01T08:00:00Z'
    },
    notifications: [
      { id: '1', message: 'Admin dashboard ready', date: '2023-01-01T08:00:00Z', read: true }
    ]
  }
];

// Initialize demo users on server startup
async function initializeDemoUsers() {
  console.log('Initializing demo users...');
  
  try {
    for (const demoUser of DEMO_USERS) {
      console.log(`Checking demo user: ${demoUser.email}`);
      
      // Check if user already exists
      const existingUserData = await kv.get(`user_by_email:${demoUser.email}`);
      
      if (!existingUserData) {
        console.log(`Creating demo user: ${demoUser.email}`);
        
        try {
          // Create user with Supabase Auth
          const { data: authData, error: authError } = await supabaseServiceRole.auth.admin.createUser({
            email: demoUser.email,
            password: demoUser.password,
            user_metadata: { 
              name: demoUser.name,
              role: demoUser.role 
            },
            email_confirm: true // Auto-confirm email
          });

          if (authError) {
            // If user already exists in auth, that's okay
            if (authError.message.includes('already registered')) {
              console.log(`User ${demoUser.email} already exists in auth system`);
              
              // Try to get existing user info
              const { data: existingUser } = await supabaseServiceRole.auth.admin.listUsers();
              const foundUser = existingUser.users?.find(u => u.email === demoUser.email);
              
              if (foundUser) {
                const userData = {
                  id: foundUser.id,
                  email: demoUser.email,
                  name: demoUser.name,
                  role: demoUser.role,
                  profile: demoUser.profile,
                  ...(demoUser.enrolledCourses && { enrolledCourses: demoUser.enrolledCourses }),
                  ...(demoUser.assignedCourses && { assignedCourses: demoUser.assignedCourses }),
                  notifications: demoUser.notifications
                };

                await kv.set(`user:${foundUser.id}`, userData);
                await kv.set(`user_by_email:${demoUser.email}`, foundUser.id);
                console.log(`Updated existing user data for: ${demoUser.email}`);
              }
              continue;
            } else {
              console.error(`Error creating user ${demoUser.email}:`, authError);
              continue;
            }
          }

          if (authData.user) {
            // Store user data in KV store
            const userData = {
              id: authData.user.id,
              email: demoUser.email,
              name: demoUser.name,
              role: demoUser.role,
              profile: demoUser.profile,
              ...(demoUser.enrolledCourses && { enrolledCourses: demoUser.enrolledCourses }),
              ...(demoUser.assignedCourses && { assignedCourses: demoUser.assignedCourses }),
              notifications: demoUser.notifications
            };

            await kv.set(`user:${authData.user.id}`, userData);
            await kv.set(`user_by_email:${demoUser.email}`, authData.user.id);
            console.log(`Successfully created demo user: ${demoUser.email}`);
          }
          
        } catch (error) {
          console.error(`Failed to create demo user ${demoUser.email}:`, error);
        }
      } else {
        console.log(`Demo user ${demoUser.email} already exists`);
      }
    }
    
    console.log('Demo users initialization completed');
  } catch (error) {
    console.error('Error initializing demo users:', error);
  }
}

// Initialize demo users on startup
initializeDemoUsers();

// Health check endpoint
app.get("/make-server-8c6b9460/health", (c) => {
  return c.json({ 
    status: "ok", 
    timestamp: new Date().toISOString(),
    demoUsersAvailable: DEMO_USERS.map(u => u.email)
  });
});

// Authentication endpoints
app.post("/make-server-8c6b9460/auth/signup", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password, name, role = 'student' } = body;

    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }

    // Create user with Supabase Auth
    const { data: authData, error: authError } = await supabaseServiceRole.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        name,
        role 
      },
      email_confirm: true // Auto-confirm email since we don't have email server configured
    });

    if (authError) {
      console.error('Auth signup error:', authError);
      return c.json({ error: authError.message }, 400);
    }

    if (!authData.user) {
      return c.json({ error: "Failed to create user" }, 500);
    }

    // Store additional user data in KV store
    const userId = authData.user.id;
    const userData = {
      id: userId,
      email,
      name,
      role,
      profile: {
        phone: "",
        address: "",
        joinDate: new Date().toISOString(),
        progress: {},
        ...(role === 'teacher' && { 
          specialization: "",
          experience: "" 
        })
      },
      ...(role === 'student' && { enrolledCourses: [] }),
      ...(role === 'teacher' && { assignedCourses: [] }),
      notifications: []
    };

    await kv.set(`user:${userId}`, userData);
    await kv.set(`user_by_email:${email}`, userId);

    return c.json({ 
      message: "User created successfully",
      user: {
        id: userId,
        email,
        name,
        role
      }
    });

  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: "Internal server error during signup" }, 500);
  }
});

app.post("/make-server-8c6b9460/auth/signin", async (c) => {
  try {
    const body = await c.req.json();
    const { email, password } = body;

    if (!email || !password) {
      return c.json({ error: "Email and password are required" }, 400);
    }

    // Sign in with Supabase Auth
    const { data: authData, error: authError } = await supabaseAnon.auth.signInWithPassword({
      email,
      password,
    });

    if (authError) {
      console.error('Auth signin error:', authError);
      return c.json({ error: authError.message }, 401);
    }

    if (!authData.session || !authData.user) {
      return c.json({ error: "Failed to create session" }, 401);
    }

    // Get user data from KV store
    const userId = authData.user.id;
    let userData = await kv.get(`user:${userId}`);

    // If no user data exists in KV, create it from auth metadata
    if (!userData) {
      const userMeta = authData.user.user_metadata || {};
      userData = {
        id: userId,
        email: authData.user.email!,
        name: userMeta.name || email.split('@')[0],
        role: userMeta.role || 'student',
        profile: {
          phone: "",
          address: "",
          joinDate: authData.user.created_at,
          progress: {},
          ...(userMeta.role === 'teacher' && { 
            specialization: "",
            experience: "" 
          })
        },
        ...(userMeta.role === 'student' && { enrolledCourses: [] }),
        ...(userMeta.role === 'teacher' && { assignedCourses: [] }),
        notifications: []
      };
      
      await kv.set(`user:${userId}`, userData);
      await kv.set(`user_by_email:${authData.user.email!}`, userId);
    }

    return c.json({
      user: {
        id: userData.id,
        email: userData.email,
        name: userData.name,
        role: userData.role
      },
      userData,
      access_token: authData.session.access_token
    });

  } catch (error) {
    console.error('Signin error:', error);
    return c.json({ error: "Internal server error during signin" }, 500);
  }
});

app.get("/make-server-8c6b9460/auth/me", async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ error: "Authorization header required" }, 401);
    }

    const token = authHeader.split(' ')[1];

    // Verify token with Supabase
    const { data: authData, error: authError } = await supabaseAnon.auth.getUser(token);

    if (authError || !authData.user) {
      console.error('Auth verification error:', authError);
      return c.json({ error: "Invalid token" }, 401);
    }

    // Get user data from KV store
    const userId = authData.user.id;
    let userData = await kv.get(`user:${userId}`);

    // If no user data exists, create it
    if (!userData) {
      const userMeta = authData.user.user_metadata || {};
      userData = {
        id: userId,
        email: authData.user.email!,
        name: userMeta.name || authData.user.email!.split('@')[0],
        role: userMeta.role || 'student',
        profile: {
          phone: "",
          address: "",
          joinDate: authData.user.created_at,
          progress: {},
          ...(userMeta.role === 'teacher' && { 
            specialization: "",
            experience: "" 
          })
        },
        ...(userMeta.role === 'student' && { enrolledCourses: [] }),
        ...(userMeta.role === 'teacher' && { assignedCourses: [] }),
        notifications: []
      };
      
      await kv.set(`user:${userId}`, userData);
      await kv.set(`user_by_email:${authData.user.email!}`, userId);
    }

    return c.json({
      user: {
        id: userData.id,
        email: userData.email,
        name: userData.name,
        role: userData.role
      },
      userData
    });

  } catch (error) {
    console.error('Auth me error:', error);
    return c.json({ error: "Internal server error during user verification" }, 500);
  }
});

// Course management endpoints (for future use)
app.get("/make-server-8c6b9460/courses", async (c) => {
  try {
    const courses = await kv.getByPrefix('course:');
    return c.json({ courses });
  } catch (error) {
    console.error('Get courses error:', error);
    return c.json({ error: "Failed to fetch courses" }, 500);
  }
});

app.post("/make-server-8c6b9460/courses", async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ error: "Authorization required" }, 401);
    }

    const token = authHeader.split(' ')[1];
    const { data: authData, error: authError } = await supabaseAnon.auth.getUser(token);

    if (authError || !authData.user) {
      return c.json({ error: "Invalid token" }, 401);
    }

    // Check if user is admin
    const userData = await kv.get(`user:${authData.user.id}`);
    if (!userData || userData.role !== 'admin') {
      return c.json({ error: "Admin access required" }, 403);
    }

    const body = await c.req.json();
    const { title, description, price, duration, level } = body;

    if (!title || !description) {
      return c.json({ error: "Title and description are required" }, 400);
    }

    const courseId = `course_${Date.now()}`;
    const course = {
      id: courseId,
      title,
      description,
      price: price || 0,
      duration: duration || "",
      level: level || "Beginner",
      createdAt: new Date().toISOString(),
      createdBy: authData.user.id,
      enrolledStudents: [],
      modules: []
    };

    await kv.set(`course:${courseId}`, course);

    return c.json({ course });

  } catch (error) {
    console.error('Create course error:', error);
    return c.json({ error: "Failed to create course" }, 500);
  }
});

// User management endpoints (for admin)
app.get("/make-server-8c6b9460/users", async (c) => {
  try {
    const authHeader = c.req.header('Authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return c.json({ error: "Authorization required" }, 401);
    }

    const token = authHeader.split(' ')[1];
    const { data: authData, error: authError } = await supabaseAnon.auth.getUser(token);

    if (authError || !authData.user) {
      return c.json({ error: "Invalid token" }, 401);
    }

    // Check if user is admin
    const userData = await kv.get(`user:${authData.user.id}`);
    if (!userData || userData.role !== 'admin') {
      return c.json({ error: "Admin access required" }, 403);
    }

    const users = await kv.getByPrefix('user:');
    // Filter out email mapping entries
    const actualUsers = users.filter(user => user && typeof user === 'object' && user.id && user.email);
    
    return c.json({ users: actualUsers });

  } catch (error) {
    console.error('Get users error:', error);
    return c.json({ error: "Failed to fetch users" }, 500);
  }
});

// Error handling middleware
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ error: "Internal server error" }, 500);
});

// 404 handler
app.notFound((c) => {
  return c.json({ error: "Route not found" }, 404);
});

Deno.serve(app.fetch);