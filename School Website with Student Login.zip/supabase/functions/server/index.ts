import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { cors } from "https://deno.land/x/hono@v3.12.11/middleware.ts"
import { Hono } from "https://deno.land/x/hono@v3.12.11/mod.ts"
import { logger } from "https://deno.land/x/hono@v3.12.11/middleware.ts"
import * as kv from './kv_store.tsx'

const app = new Hono()

// CORS middleware
app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['POST', 'GET', 'PUT', 'DELETE', 'OPTIONS'],
}))

// Logging middleware
app.use('*', logger(console.log))

// Create Supabase client with service role key for admin operations
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

// User roles
const USER_ROLES = {
  STUDENT: 'student',
  TEACHER: 'teacher',
  ADMIN: 'admin'
}

// Helper function to verify user and get role
async function verifyUser(authHeader: string) {
  if (!authHeader?.startsWith('Bearer ')) {
    return { error: 'Missing or invalid Authorization header', status: 401 }
  }
  
  const token = authHeader.split(' ')[1]
  const { data: { user }, error } = await supabase.auth.getUser(token)
  
  if (error || !user) {
    return { error: 'Invalid token or user not found', status: 401 }
  }

  // Get user role from metadata
  const role = user.user_metadata?.role || USER_ROLES.STUDENT
  
  return { user, role, status: 200 }
}

// Helper function to check admin access
function requireAdmin(role: string) {
  if (role !== USER_ROLES.ADMIN) {
    return { error: 'Admin access required', status: 403 }
  }
  return null
}

// Initialize system data
async function initializeSystemData() {
  console.log('Initializing system data...')
  
  // Sample courses
  const sampleCourses = [
    {
      id: 'basic-coding',
      title: 'Basic Coding',
      description: 'Learn fundamental programming skills with HTML, CSS, and JavaScript.',
      duration: '6 months',
      price: 'R 8,500',
      instructor: 'John Smith',
      enrollmentCount: 24,
      videos: [
        { id: 'intro', title: 'Introduction to Programming', duration: '15:30', completed: false },
        { id: 'html-basics', title: 'HTML Fundamentals', duration: '25:45', completed: false },
        { id: 'css-styling', title: 'CSS Styling Basics', duration: '30:20', completed: false },
        { id: 'js-intro', title: 'JavaScript Introduction', duration: '40:15', completed: false }
      ]
    },
    {
      id: 'digital-marketing',
      title: 'Digital Marketing',
      description: 'Master social media, SEO, and online advertising strategies.',
      duration: '5 months',
      price: 'R 7,800',
      instructor: 'Sarah Johnson',
      enrollmentCount: 18,
      videos: [
        { id: 'marketing-basics', title: 'Digital Marketing Fundamentals', duration: '20:30', completed: false },
        { id: 'social-media', title: 'Social Media Strategy', duration: '28:45', completed: false },
        { id: 'seo-basics', title: 'SEO Fundamentals', duration: '35:20', completed: false },
        { id: 'google-ads', title: 'Google Ads Setup', duration: '45:15', completed: false }
      ]
    },
    {
      id: 'beauty-therapy',
      title: 'Beauty Therapy & More',
      description: 'Comprehensive beauty and wellness training with industry certification.',
      duration: '8 months',
      price: 'R 12,500',
      instructor: 'Maria Rodriguez',
      enrollmentCount: 15,
      videos: [
        { id: 'beauty-intro', title: 'Introduction to Beauty Therapy', duration: '18:30', completed: false },
        { id: 'facial-treatments', title: 'Facial Treatment Techniques', duration: '32:45', completed: false },
        { id: 'nail-tech', title: 'Nail Technology', duration: '28:20', completed: false },
        { id: 'hair-styling', title: 'Hair Styling Basics', duration: '38:15', completed: false }
      ]
    }
  ]

  // Sample users
  const sampleUsers = [
    {
      id: 'student-1',
      email: 'student1@azania.co.za',
      name: 'Thabo Mthembu',
      role: 'student',
      enrolledCourses: ['basic-coding'],
      profile: {
        phone: '065 123 4567',
        address: 'Johannesburg, Gauteng',
        joinDate: '2024-01-15',
        progress: { 'basic-coding': 25 }
      },
      notifications: [
        { id: 'notif-1', message: 'New assignment posted in Basic Coding', date: '2024-01-20', read: false },
        { id: 'notif-2', message: 'Course materials updated', date: '2024-01-18', read: true }
      ]
    },
    {
      id: 'teacher-1',
      email: 'john.smith@azania.co.za',
      name: 'John Smith',
      role: 'teacher',
      assignedCourses: ['basic-coding'],
      profile: {
        phone: '065 234 5678',
        address: 'Cape Town, Western Cape',
        specialization: 'Web Development',
        experience: '8 years',
        joinDate: '2023-06-01'
      }
    },
    {
      id: 'admin-1',
      email: 'admin@azania.co.za',
      name: 'Administrator',
      role: 'admin',
      profile: {
        phone: '065 345 6789',
        address: 'Pretoria, Gauteng',
        joinDate: '2023-01-01'
      }
    }
  ]

  try {
    // Store courses
    for (const course of sampleCourses) {
      await kv.set(`course:${course.id}`, course)
    }
    
    // Store users
    for (const user of sampleUsers) {
      await kv.set(`user:${user.id}`, user)
    }

    // Store system stats
    await kv.set('system:stats', {
      totalStudents: 24,
      totalTeachers: 5,
      totalCourses: 8,
      totalEnrollments: 42
    })

    console.log('System data initialized successfully')
  } catch (error) {
    console.error('Error initializing system data:', error)
  }
}

// Initialize system on startup
initializeSystemData()

// Authentication endpoints
app.post('/make-server-8c6b9460/auth/signup', async (c) => {
  try {
    const { email, password, name, role = 'student' } = await c.req.json()
    
    if (!email || !password || !name) {
      return c.json({ error: 'Email, password, and name are required' }, 400)
    }

    // Create user with Supabase Auth
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role },
      email_confirm: true // Auto-confirm email since no email server configured
    })

    if (error) {
      console.error('Signup error:', error)
      return c.json({ error: error.message }, 400)
    }

    // Store additional user data in KV
    const userData = {
      id: data.user.id,
      email: data.user.email,
      name,
      role,
      enrolledCourses: role === 'student' ? [] : undefined,
      assignedCourses: role === 'teacher' ? [] : undefined,
      profile: {
        phone: '',
        address: '',
        joinDate: new Date().toISOString().split('T')[0],
        ...(role === 'student' && { progress: {} }),
        ...(role === 'teacher' && { specialization: '', experience: '' })
      },
      ...(role === 'student' && { notifications: [] })
    }

    await kv.set(`user:${data.user.id}`, userData)

    return c.json({ 
      message: 'User created successfully', 
      user: { 
        id: data.user.id, 
        email: data.user.email, 
        name, 
        role 
      } 
    })

  } catch (error) {
    console.error('Signup error:', error)
    return c.json({ error: 'Internal server error during signup' }, 500)
  }
})

app.post('/make-server-8c6b9460/auth/signin', async (c) => {
  try {
    const { email, password } = await c.req.json()
    
    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400)
    }

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })

    if (error) {
      console.error('Signin error:', error)
      return c.json({ error: error.message }, 400)
    }

    // Get user data from KV store
    const userData = await kv.get(`user:${data.user.id}`)
    
    return c.json({
      message: 'Login successful',
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata.name,
        role: data.user.user_metadata.role || 'student'
      },
      access_token: data.session.access_token,
      userData
    })

  } catch (error) {
    console.error('Signin error:', error)
    return c.json({ error: 'Internal server error during signin' }, 500)
  }
})

// Get current user info
app.get('/make-server-8c6b9460/auth/me', async (c) => {
  try {
    const authResult = await verifyUser(c.req.header('Authorization') || '')
    
    if (authResult.error) {
      return c.json({ error: authResult.error }, authResult.status)
    }

    const userData = await kv.get(`user:${authResult.user.id}`)
    
    return c.json({
      user: {
        id: authResult.user.id,
        email: authResult.user.email,
        name: authResult.user.user_metadata.name,
        role: authResult.role
      },
      userData
    })

  } catch (error) {
    console.error('Get user error:', error)
    return c.json({ error: 'Internal server error getting user info' }, 500)
  }
})

// Student endpoints
app.get('/make-server-8c6b9460/student/dashboard', async (c) => {
  try {
    const authResult = await verifyUser(c.req.header('Authorization') || '')
    
    if (authResult.error) {
      return c.json({ error: authResult.error }, authResult.status)
    }

    const userData = await kv.get(`user:${authResult.user.id}`)
    if (!userData) {
      return c.json({ error: 'User data not found' }, 404)
    }

    // Get enrolled courses details
    const enrolledCourses = []
    if (userData.enrolledCourses) {
      for (const courseId of userData.enrolledCourses) {
        const course = await kv.get(`course:${courseId}`)
        if (course) {
          enrolledCourses.push({
            ...course,
            progress: userData.profile?.progress?.[courseId] || 0
          })
        }
      }
    }

    return c.json({
      user: userData,
      enrolledCourses,
      notifications: userData.notifications || []
    })

  } catch (error) {
    console.error('Student dashboard error:', error)
    return c.json({ error: 'Internal server error getting dashboard data' }, 500)
  }
})

// Admin endpoints
app.get('/make-server-8c6b9460/admin/dashboard', async (c) => {
  try {
    const authResult = await verifyUser(c.req.header('Authorization') || '')
    
    if (authResult.error) {
      return c.json({ error: authResult.error }, authResult.status)
    }

    const adminCheck = requireAdmin(authResult.role)
    if (adminCheck) {
      return c.json({ error: adminCheck.error }, adminCheck.status)
    }

    // Get all users, courses, and system stats
    const users = await kv.getByPrefix('user:')
    const courses = await kv.getByPrefix('course:')
    const stats = await kv.get('system:stats') || { 
      totalStudents: 0, 
      totalTeachers: 0, 
      totalCourses: 0, 
      totalEnrollments: 0 
    }

    return c.json({
      users: users.map(u => u.value),
      courses: courses.map(c => c.value),
      stats
    })

  } catch (error) {
    console.error('Admin dashboard error:', error)
    return c.json({ error: 'Internal server error getting admin dashboard' }, 500)
  }
})

// Create new course (Admin only)
app.post('/make-server-8c6b9460/admin/courses', async (c) => {
  try {
    const authResult = await verifyUser(c.req.header('Authorization') || '')
    
    if (authResult.error) {
      return c.json({ error: authResult.error }, authResult.status)
    }

    const adminCheck = requireAdmin(authResult.role)
    if (adminCheck) {
      return c.json({ error: adminCheck.error }, adminCheck.status)
    }

    const courseData = await c.req.json()
    const courseId = `course-${Date.now()}`
    
    const course = {
      id: courseId,
      title: courseData.title,
      description: courseData.description,
      duration: courseData.duration,
      price: courseData.price,
      instructor: courseData.instructor,
      enrollmentCount: 0,
      videos: courseData.videos || []
    }

    await kv.set(`course:${courseId}`, course)

    return c.json({ message: 'Course created successfully', course })

  } catch (error) {
    console.error('Create course error:', error)
    return c.json({ error: 'Internal server error creating course' }, 500)
  }
})

// Enroll student in course
app.post('/make-server-8c6b9460/student/enroll', async (c) => {
  try {
    const authResult = await verifyUser(c.req.header('Authorization') || '')
    
    if (authResult.error) {
      return c.json({ error: authResult.error }, authResult.status)
    }

    const { courseId } = await c.req.json()
    
    if (!courseId) {
      return c.json({ error: 'Course ID is required' }, 400)
    }

    // Get user data
    const userData = await kv.get(`user:${authResult.user.id}`)
    if (!userData) {
      return c.json({ error: 'User data not found' }, 404)
    }

    // Check if course exists
    const course = await kv.get(`course:${courseId}`)
    if (!course) {
      return c.json({ error: 'Course not found' }, 404)
    }

    // Add course to user's enrolled courses
    if (!userData.enrolledCourses.includes(courseId)) {
      userData.enrolledCourses.push(courseId)
      userData.profile.progress[courseId] = 0
      
      await kv.set(`user:${authResult.user.id}`, userData)
      
      // Update course enrollment count
      course.enrollmentCount += 1
      await kv.set(`course:${courseId}`, course)
    }

    return c.json({ message: 'Enrolled successfully', course })

  } catch (error) {
    console.error('Enrollment error:', error)
    return c.json({ error: 'Internal server error during enrollment' }, 500)
  }
})

// Get course content
app.get('/make-server-8c6b9460/courses/:id', async (c) => {
  try {
    const authResult = await verifyUser(c.req.header('Authorization') || '')
    
    if (authResult.error) {
      return c.json({ error: authResult.error }, authResult.status)
    }

    const courseId = c.req.param('id')
    const course = await kv.get(`course:${courseId}`)
    
    if (!course) {
      return c.json({ error: 'Course not found' }, 404)
    }

    return c.json(course)

  } catch (error) {
    console.error('Get course error:', error)
    return c.json({ error: 'Internal server error getting course' }, 500)
  }
})

console.log('Server starting...')
serve(app.fetch, { port: 8000 })