import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { CheckCircle, Target, Users, BookOpen, Award, Globe } from 'lucide-react';

export function AboutSection() {
  const features = [
    "Hands-on, practical training approach",
    "Industry-experienced instructors",
    "Small class sizes for personalized attention",
    "Job placement assistance",
    "Flexible scheduling options",
    "Modern facilities and equipment"
  ];

  const values = [
    {
      icon: Target,
      title: "Excellence",
      description: "We strive for the highest standards in education and training delivery."
    },
    {
      icon: Users,
      title: "Community",
      description: "Building a supportive learning environment where everyone can thrive."
    },
    {
      icon: BookOpen,
      title: "Innovation",
      description: "Continuously updating our curriculum to meet industry demands."
    },
    {
      icon: Award,
      title: "Success",
      description: "Measuring our success by the achievements of our graduates."
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main About Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              About MyAzania Academy
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              MyAzania Academy is a skills-focused institution offering hands-on, vocational training 
              that empowers individuals to thrive in the real world. We bridge the gap between 
              traditional education and industry requirements.
            </p>
            <p className="text-gray-600 mb-8">
              Our comprehensive programs are designed in collaboration with industry experts to ensure 
              our graduates possess the practical skills and knowledge needed to excel in their chosen fields. 
              We believe in learning by doing, which is why our curriculum emphasizes real-world application 
              and project-based learning.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>

            <Button size="lg" className="mr-4">
              Learn More About Us
            </Button>
            <Button size="lg" variant="outline">
              Meet Our Team
            </Button>
          </div>

          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-blue-100 to-purple-100 rounded-2xl p-8">
              <div className="h-full bg-white rounded-lg shadow-lg p-6 flex flex-col justify-center items-center text-center">
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4">
                  <Globe className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">Our Mission</h3>
                <p className="text-gray-600">
                  Empowering individuals with practical skills and knowledge to succeed in 
                  the modern workplace and contribute meaningfully to their communities.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Values Section */}
        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Core Values</h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            These principles guide everything we do and shape the learning environment we create for our students.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => {
            const IconComponent = value.icon;
            return (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="font-bold text-gray-900 mb-2">{value.title}</h4>
                  <p className="text-sm text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}