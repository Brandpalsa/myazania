import { Button } from './ui/button';
import { Input } from './ui/input';
import { BookOpen, Phone, Mail, Facebook, Linkedin, Instagram, Twitter, Youtube } from 'lucide-react';

export function Footer() {
  const onlineplatformLinks = [
    "Contact Us",
    "Training",
    "About Us", 
    "Events",
    "Blog"
  ];

  const programLinks = [
    "Basic Coding",
    "Beauty Therapy & More",
    "Bookkeeping & Payroll",
    "Customer Service",
    "Digital Marketing",
    "Entrepreneurship",
    "Health & Safety"
  ];

  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Youtube, href: "#", label: "YouTube" }
  ];

  return (
    <footer className="bg-gray-800 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Academy Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-yellow-500 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-lg">MyAzania Academy</h3>
                <p className="text-sm text-gray-300">Skills-Focused Training</p>
              </div>
            </div>
            
            <p className="text-gray-300 mb-6 text-sm leading-relaxed">
              MyAzania Academy is a skills-focused institution offering hands-on, vocational training 
              that empowers individuals to thrive in the real world.
            </p>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-gray-400" />
                <div className="text-sm">
                  <p>Call: 065 324 8692 / 065 248 8692</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-gray-400" />
                <div className="text-sm">
                  <p>Email: academy@myazania.co.za</p>
                </div>
              </div>
            </div>
          </div>

          {/* Online Platform Links */}
          <div>
            <h4 className="font-bold text-lg mb-6">Online Platform</h4>
            <ul className="space-y-3">
              {onlineplatformLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Program Links */}
          <div>
            <h4 className="font-bold text-lg mb-6">Programs</h4>
            <ul className="space-y-3">
              {programLinks.map((link, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-white transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter & Social */}
          <div>
            <h4 className="font-bold text-lg mb-6">Stay Connected</h4>
            <p className="text-gray-300 text-sm mb-4">
              Enter your email address to register to our newsletter subscription
            </p>
            
            <div className="flex space-x-2 mb-6">
              <Input 
                type="email" 
                placeholder="Your email" 
                className="bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              />
              <Button className="bg-yellow-500 hover:bg-yellow-600 text-white px-6">
                Subscribe
              </Button>
            </div>

            <div className="flex space-x-4">
              {socialLinks.map((social, index) => {
                const IconComponent = social.icon;
                return (
                  <a 
                    key={index}
                    href={social.href} 
                    className="w-8 h-8 bg-gray-700 rounded flex items-center justify-center hover:bg-blue-600 transition-colors"
                    aria-label={social.label}
                  >
                    <IconComponent className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Border */}
        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2025 MyAzania Academy. All rights reserved.
            </p>
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}