import { useState, useEffect } from 'react';
import { router } from '../../utils/router';
import { useAuth } from '../../utils/auth';
import { getRouteByPath, getDashboardComponentByRole } from '../../utils/routes';

interface RouteHandlerProps {
  onComponentChange: (component: React.ComponentType | null) => void;
  onLoadingChange: (loading: boolean) => void;
}

export function RouteHandler({ onComponentChange, onLoadingChange }: RouteHandlerProps) {
  const { user, loading: authLoading } = useAuth();
  const [lastRoute, setLastRoute] = useState<string | null>(null);

  useEffect(() => {
    const handleRouteChange = () => {
      try {
        console.log('Route change triggered, authLoading:', authLoading);
        
        // Don't handle routes while auth is still loading, unless this is the initial mount
        if (authLoading && lastRoute !== null) {
          console.log('Auth still loading, waiting...');
          return;
        }

        const route = router.getCurrentRoute();
        console.log('Current route:', route);
        
        if (!route) {
          console.log('No route found, setting component to null');
          onComponentChange(null);
          return;
        }

        // Update document title
        document.title = `${route.title} - Azania Academy`;
        setLastRoute(route.path);
        
        const routeConfig = getRouteByPath(route.path);
        console.log('Route config:', routeConfig);
        
        if (!routeConfig) {
          console.log('No route config found');
          onComponentChange(null);
          return;
        }

        // Handle authentication routes - allow access even when not logged in
        if (route.path === '/login') {
          console.log('Setting login component');
          onComponentChange(routeConfig.component);
          return;
        }

        // Handle dashboard routes with role-based routing
        if (route.path === '/dashboard' || route.path === '/student-dashboard') {
          if (!user) {
            console.log('No user, redirecting to login for dashboard');
            router.navigate('/login');
            return;
          }
          
          const DashboardComponent = getDashboardComponentByRole(user.role);
          console.log('Setting dashboard component for role:', user.role, 'component:', DashboardComponent.name);
          onComponentChange(DashboardComponent);
          return;
        }

        // Handle specific role-based dashboards
        if (route.path === '/teacher-dashboard') {
          if (!user || (user.role !== 'teacher' && user.role !== 'admin')) {
            console.log('Access denied for teacher dashboard, redirecting to login');
            router.navigate('/login');
            return;
          }
          console.log('Setting teacher dashboard component');
          onComponentChange(routeConfig.component);
          return;
        }

        if (route.path === '/admin-dashboard') {
          if (!user || user.role !== 'admin') {
            console.log('Access denied for admin dashboard, redirecting to login');
            router.navigate('/login');
            return;
          }
          console.log('Setting admin dashboard component');
          onComponentChange(routeConfig.component);
          return;
        }

        // Handle public routes
        if (routeConfig.isPublic) {
          console.log('Setting public route component');
          onComponentChange(routeConfig.component);
          return;
        }

        // Handle protected routes
        if (routeConfig.requiresAuth) {
          if (!user) {
            console.log('Protected route requires auth, redirecting to login');
            router.navigate('/login');
            return;
          }

          if (routeConfig.allowedRoles && !routeConfig.allowedRoles.includes(user.role)) {
            // Redirect to appropriate dashboard based on role
            const dashboardPath = user.role === 'admin' ? '/admin-dashboard' : 
                                 user.role === 'teacher' ? '/teacher-dashboard' : '/student-dashboard';
            console.log('Access denied, redirecting to dashboard:', dashboardPath);
            router.navigate(dashboardPath);
            return;
          }

          console.log('Setting protected route component');
          onComponentChange(routeConfig.component);
          return;
        }

        // Fallback
        console.log('Setting fallback component');
        onComponentChange(routeConfig.component);
      } catch (error) {
        console.error('Error in route handler:', error);
        onComponentChange(null);
      }
    };

    // Subscribe to router changes
    const unsubscribe = router.subscribe(handleRouteChange);
    
    // Handle initial route when auth loading changes
    if (!authLoading || lastRoute === null) {
      console.log('Handling route change - authLoading:', authLoading, 'lastRoute:', lastRoute);
      handleRouteChange();
    }

    return () => {
      unsubscribe();
    };
  }, [user, authLoading, onComponentChange, lastRoute]);

  // Update loading state based on auth loading
  useEffect(() => {
    console.log('Auth loading state changed:', authLoading);
    onLoadingChange(authLoading);
  }, [authLoading, onLoadingChange]);

  return null; // This component only handles routing logic
}