import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { useAuth } from '../../utils/auth';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { Progress } from '../ui/progress';
import { 
  BookOpen, Users, TrendingUp, Clock, GraduationCap, 
  LogOut, User, Bell, Mail, Phone, MapPin, Calendar,
  Award, FileText, Video, Settings
} from 'lucide-react';
import { projectId } from '../../utils/supabase/info';

interface Course {
  id: string;
  title: string;
  description: string;
  duration: string;
  price: string;
  instructor: string;
  enrollmentCount: number;
  videos: Array<{
    id: string;
    title: string;
    duration: string;
    completed: boolean;
  }>;
}

interface Student {
  id: string;
  name: string;
  email: string;
  enrolledCourses: string[];
  profile: {
    progress: { [courseId: string]: number };
    joinDate: string;
  };
}

export function TeacherDashboard() {
  const { user, userData, logout } = useAuth();
  const [assignedCourses, setAssignedCourses] = useState<Course[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTeacherData();
  }, []);

  const fetchTeacherData = async () => {
    try {
      // Fetch courses assigned to this teacher
      const coursesResponse = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-8c6b9460/admin/dashboard`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
        },
      });

      if (coursesResponse.ok) {
        const data = await coursesResponse.json();
        
        // Filter courses assigned to this teacher
        const teacherCourses = data.courses.filter((course: Course) => 
          course.instructor === user?.name
        );
        setAssignedCourses(teacherCourses);

        // Filter students enrolled in teacher's courses
        const enrolledStudents = data.users.filter((userData: any) => 
          userData.role === 'student' && 
          userData.enrolledCourses?.some((courseId: string) =>
            teacherCourses.some((course: Course) => course.id === courseId)
          )
        );
        setStudents(enrolledStudents);
      }
    } catch (error) {
      console.error('Error fetching teacher data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getTotalStudents = () => {
    return assignedCourses.reduce((total, course) => total + course.enrollmentCount, 0);
  };

  const getAverageProgress = () => {
    if (students.length === 0) return 0;
    
    const totalProgress = students.reduce((sum, student) => {
      const studentProgress = Object.values(student.profile?.progress || {});
      const avgProgress = studentProgress.length > 0 
        ? studentProgress.reduce((a, b) => a + b, 0) / studentProgress.length 
        : 0;
      return sum + avgProgress;
    }, 0);

    return Math.round(totalProgress / students.length);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gold"></div>
          <span className="font-montserrat">Loading teacher dashboard...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-secondary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center justify-center w-10 h-10 bg-gold rounded-lg">
                <GraduationCap className="w-6 h-6 text-black" />
              </div>
              <div>
                <h1 className="font-montserrat font-semibold text-lg">Azania Academy</h1>
                <p className="text-sm text-muted-foreground">Teacher Portal</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4 mr-2" />
                Notifications
              </Button>
              <div className="flex items-center space-x-2">
                <Avatar>
                  <AvatarFallback className="bg-blue-500 text-white">
                    {getInitials(user?.name || 'Teacher')}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden sm:block">
                  <p className="font-medium text-sm">{user?.name}</p>
                  <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={logout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Navigation */}
          <TabsList className="grid w-full grid-cols-4 lg:w-fit lg:grid-cols-4">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="courses" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">My Courses</span>
            </TabsTrigger>
            <TabsTrigger value="students" className="flex items-center space-x-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Students</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span className="hidden sm:inline">Profile</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Assigned Courses</p>
                        <p className="text-2xl font-bold text-foreground">{assignedCourses.length}</p>
                      </div>
                      <div className="w-12 h-12 bg-gold/10 rounded-lg flex items-center justify-center">
                        <BookOpen className="w-6 h-6 text-gold" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Students</p>
                        <p className="text-2xl font-bold text-foreground">{getTotalStudents()}</p>
                      </div>
                      <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Avg. Progress</p>
                        <p className="text-2xl font-bold text-foreground">{getAverageProgress()}%</p>
                      </div>
                      <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-green-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Experience</p>
                        <p className="text-2xl font-bold text-foreground">
                          {userData?.profile?.experience || 'N/A'}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-purple-500/10 rounded-lg flex items-center justify-center">
                        <Award className="w-6 h-6 text-purple-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Course Overview</CardTitle>
                    <CardDescription>Your assigned courses and their performance</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {assignedCourses.map((course) => (
                        <div key={course.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                              <BookOpen className="w-5 h-5 text-black" />
                            </div>
                            <div>
                              <p className="font-medium">{course.title}</p>
                              <p className="text-sm text-muted-foreground">
                                {course.enrollmentCount} students enrolled
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium text-gold">{course.price}</p>
                            <p className="text-sm text-muted-foreground">{course.duration}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Student Activity</CardTitle>
                    <CardDescription>Latest progress from your students</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {students.slice(0, 5).map((student) => {
                        const avgProgress = student.profile?.progress 
                          ? Object.values(student.profile.progress).reduce((a, b) => a + b, 0) / Object.values(student.profile.progress).length
                          : 0;
                        
                        return (
                          <div key={student.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                            <div className="flex items-center space-x-4">
                              <Avatar>
                                <AvatarFallback className="bg-blue-500 text-white">
                                  {getInitials(student.name)}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{student.name}</p>
                                <p className="text-sm text-muted-foreground">
                                  {student.enrolledCourses.length} courses
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Progress value={avgProgress} className="w-16 mb-1" />
                              <p className="text-xs text-muted-foreground">{Math.round(avgProgress)}%</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </motion.div>
          </TabsContent>

          {/* Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {assignedCourses.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {assignedCourses.map((course) => (
                    <Card key={course.id} className="hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg">{course.title}</CardTitle>
                            <CardDescription className="mt-2">{course.description}</CardDescription>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Duration:</span>
                            <span className="font-medium">{course.duration}</span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Price:</span>
                            <span className="font-medium text-gold">{course.price}</span>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Students:</span>
                            <Badge variant="secondary">{course.enrollmentCount} enrolled</Badge>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">Videos:</span>
                            <span className="font-medium">{course.videos.length} lessons</span>
                          </div>

                          <div className="space-y-2">
                            <p className="font-medium text-sm">Course Videos:</p>
                            <div className="space-y-1 max-h-32 overflow-y-auto">
                              {course.videos.map((video, index) => (
                                <div key={video.id} className="flex items-center justify-between p-2 bg-muted/30 rounded text-sm">
                                  <div className="flex items-center space-x-2">
                                    <Video className="w-3 h-3 text-muted-foreground" />
                                    <span className="truncate">{video.title}</span>
                                  </div>
                                  <span className="text-muted-foreground text-xs">{video.duration}</span>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" className="flex-1">
                              <FileText className="w-4 h-4 mr-2" />
                              Materials
                            </Button>
                            <Button variant="outline" size="sm" className="flex-1">
                              <Users className="w-4 h-4 mr-2" />
                              Students
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="text-center py-16">
                    <BookOpen className="w-24 h-24 text-muted-foreground mx-auto mb-6" />
                    <h3 className="text-xl font-semibold mb-2">No courses assigned</h3>
                    <p className="text-muted-foreground mb-6">
                      Contact the administrator to get courses assigned to you
                    </p>
                  </CardContent>
                </Card>
              )}
            </motion.div>
          </TabsContent>

          {/* Students Tab */}
          <TabsContent value="students" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Student Management</CardTitle>
                  <CardDescription>Monitor your students' progress and performance</CardDescription>
                </CardHeader>
                <CardContent>
                  {students.length > 0 ? (
                    <div className="space-y-4">
                      {students.map((student) => {
                        const enrolledInMyCourses = student.enrolledCourses.filter(courseId =>
                          assignedCourses.some(course => course.id === courseId)
                        );
                        
                        const avgProgress = student.profile?.progress 
                          ? Object.values(student.profile.progress).reduce((a, b) => a + b, 0) / Object.values(student.profile.progress).length
                          : 0;

                        return (
                          <div key={student.id} className="flex items-center justify-between p-6 bg-muted/30 rounded-lg">
                            <div className="flex items-center space-x-4">
                              <Avatar className="w-12 h-12">
                                <AvatarFallback className="bg-blue-500 text-white">
                                  {getInitials(student.name)}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="flex items-center space-x-2">
                                  <p className="font-medium">{student.name}</p>
                                  <Badge variant="outline">Student</Badge>
                                </div>
                                <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1">
                                  <span className="flex items-center space-x-1">
                                    <Mail className="w-3 h-3" />
                                    <span>{student.email}</span>
                                  </span>
                                  <span className="flex items-center space-x-1">
                                    <BookOpen className="w-3 h-3" />
                                    <span>{enrolledInMyCourses.length} of your courses</span>
                                  </span>
                                  <span className="flex items-center space-x-1">
                                    <Calendar className="w-3 h-3" />
                                    <span>Joined {student.profile?.joinDate}</span>
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className="text-sm text-muted-foreground">Progress:</span>
                                <Progress value={avgProgress} className="w-24" />
                                <span className="text-sm font-medium">{Math.round(avgProgress)}%</span>
                              </div>
                              <Button variant="outline" size="sm">
                                View Details
                              </Button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-16">
                      <Users className="w-24 h-24 text-muted-foreground mx-auto mb-6" />
                      <h3 className="text-xl font-semibold mb-2">No students yet</h3>
                      <p className="text-muted-foreground">
                        Students will appear here when they enroll in your courses
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Teacher Profile</CardTitle>
                  <CardDescription>Manage your professional information and settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-20 h-20">
                      <AvatarFallback className="bg-blue-500 text-white text-lg">
                        {getInitials(user?.name || 'Teacher')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold">{user?.name}</h3>
                      <p className="text-muted-foreground capitalize">{user?.role}</p>
                      <Badge variant="secondary">Teaching Professional</Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Email Address</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Mail className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{user?.email}</span>
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Phone Number</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.phone || 'Not provided'}</span>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Address</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.address || 'Not provided'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Join Date</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.joinDate}</span>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Specialization</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Award className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.specialization || 'Not specified'}</span>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Experience</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.experience || 'Not specified'}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <Button variant="outline">
                      <Settings className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                    <Button variant="outline">
                      <FileText className="w-4 h-4 mr-2" />
                      Teaching Materials
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}