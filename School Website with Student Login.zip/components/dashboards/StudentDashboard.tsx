import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../../utils/auth';
import { Button } from '../ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { 
  BookOpen, Play, Clock, Award, Bell, User, Settings, 
  ChevronRight, Video, FileText, Download, LogOut,
  GraduationCap, TrendingUp, Calendar, Mail, Phone, MapPin
} from 'lucide-react';
import { projectId, publicAnonKey } from '../../utils/supabase/info';

interface Course {
  id: string;
  title: string;
  description: string;
  duration: string;
  price: string;
  instructor: string;
  progress: number;
  videos: Array<{
    id: string;
    title: string;
    duration: string;
    completed: boolean;
  }>;
}

export function StudentDashboard() {
  const { user, userData, logout } = useAuth();
  const [enrolledCourses, setEnrolledCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-8c6b9460/student/dashboard`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setEnrolledCourses(data.enrolledCourses || []);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const enrollInCourse = async (courseId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-8c6b9460/student/enroll`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ courseId }),
      });

      if (response.ok) {
        fetchDashboardData(); // Refresh dashboard data
      }
    } catch (error) {
      console.error('Error enrolling in course:', error);
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gold"></div>
          <span className="font-montserrat">Loading dashboard...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-secondary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center justify-center w-10 h-10 bg-gold rounded-lg">
                <GraduationCap className="w-6 h-6 text-black" />
              </div>
              <div>
                <h1 className="font-montserrat font-semibold text-lg">Azania Academy</h1>
                <p className="text-sm text-muted-foreground">Student Portal</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4 mr-2" />
                Notifications
                {userData?.notifications?.filter(n => !n.read).length > 0 && (
                  <Badge variant="destructive" className="ml-2 px-1 text-xs">
                    {userData.notifications.filter(n => !n.read).length}
                  </Badge>
                )}
              </Button>
              <div className="flex items-center space-x-2">
                <Avatar>
                  <AvatarFallback className="bg-gold text-black">
                    {getInitials(user?.name || 'Student')}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden sm:block">
                  <p className="font-medium text-sm">{user?.name}</p>
                  <p className="text-xs text-muted-foreground capitalize">{user?.role}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={logout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Navigation */}
          <TabsList className="grid w-full grid-cols-4 lg:w-fit lg:grid-cols-4">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="courses" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">My Courses</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span className="hidden sm:inline">Profile</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center space-x-2">
              <Bell className="w-4 h-4" />
              <span className="hidden sm:inline">Notifications</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Enrolled Courses</p>
                        <p className="text-2xl font-bold text-foreground">{enrolledCourses.length}</p>
                      </div>
                      <div className="w-12 h-12 bg-gold/10 rounded-lg flex items-center justify-center">
                        <BookOpen className="w-6 h-6 text-gold" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Avg. Progress</p>
                        <p className="text-2xl font-bold text-foreground">
                          {enrolledCourses.length > 0 
                            ? Math.round(enrolledCourses.reduce((acc, course) => acc + course.progress, 0) / enrolledCourses.length)
                            : 0}%
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-green-500/10 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-green-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Completed Videos</p>
                        <p className="text-2xl font-bold text-foreground">
                          {enrolledCourses.reduce((acc, course) => 
                            acc + course.videos.filter(v => v.completed).length, 0
                          )}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center">
                        <Play className="w-6 h-6 text-blue-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-muted-foreground">Notifications</p>
                        <p className="text-2xl font-bold text-foreground">
                          {userData?.notifications?.filter(n => !n.read).length || 0}
                        </p>
                      </div>
                      <div className="w-12 h-12 bg-red-500/10 rounded-lg flex items-center justify-center">
                        <Bell className="w-6 h-6 text-red-500" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Your latest course progress and updates</CardDescription>
                </CardHeader>
                <CardContent>
                  {enrolledCourses.length > 0 ? (
                    <div className="space-y-4">
                      {enrolledCourses.slice(0, 3).map((course) => (
                        <div key={course.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-gold rounded-lg flex items-center justify-center">
                              <BookOpen className="w-5 h-5 text-black" />
                            </div>
                            <div>
                              <p className="font-medium">{course.title}</p>
                              <p className="text-sm text-muted-foreground">
                                Progress: {course.progress}% complete
                              </p>
                            </div>
                          </div>
                          <Progress value={course.progress} className="w-24" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="font-medium mb-2">No courses yet</h3>
                      <p className="text-muted-foreground mb-4">Start your learning journey by enrolling in a course</p>
                      <Button 
                        onClick={() => enrollInCourse('basic-coding')}
                        className="bg-gold hover:bg-gold-600 text-black"
                      >
                        Enroll in Basic Coding
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {enrolledCourses.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {enrolledCourses.map((course) => (
                    <Card key={course.id} className="cursor-pointer hover:shadow-lg transition-shadow">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div>
                            <CardTitle className="text-lg">{course.title}</CardTitle>
                            <CardDescription className="mt-2">{course.description}</CardDescription>
                          </div>
                          <Badge variant="secondary">{course.progress}%</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <Progress value={course.progress} className="h-2" />
                          
                          <div className="flex items-center justify-between text-sm text-muted-foreground">
                            <div className="flex items-center space-x-1">
                              <Clock className="w-4 h-4" />
                              <span>{course.duration}</span>
                            </div>
                            <div className="flex items-center space-x-1">
                              <Video className="w-4 h-4" />
                              <span>{course.videos.length} videos</span>
                            </div>
                          </div>

                          <div className="space-y-2">
                            <p className="font-medium text-sm">Course Videos:</p>
                            <div className="space-y-1">
                              {course.videos.slice(0, 3).map((video, index) => (
                                <div key={video.id} className="flex items-center justify-between p-2 bg-muted/30 rounded text-sm">
                                  <div className="flex items-center space-x-2">
                                    <div className={`w-2 h-2 rounded-full ${video.completed ? 'bg-green-500' : 'bg-muted-foreground'}`} />
                                    <span>{video.title}</span>
                                  </div>
                                  <span className="text-muted-foreground">{video.duration}</span>
                                </div>
                              ))}
                              {course.videos.length > 3 && (
                                <p className="text-xs text-muted-foreground text-center">
                                  +{course.videos.length - 3} more videos
                                </p>
                              )}
                            </div>
                          </div>

                          <Button 
                            className="w-full bg-gold hover:bg-gold-600 text-black"
                            onClick={() => setSelectedCourse(course)}
                          >
                            <Play className="w-4 h-4 mr-2" />
                            Continue Learning
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="text-center py-16">
                    <BookOpen className="w-24 h-24 text-muted-foreground mx-auto mb-6" />
                    <h3 className="text-xl font-semibold mb-2">No courses enrolled</h3>
                    <p className="text-muted-foreground mb-6">
                      Start your learning journey by enrolling in one of our courses
                    </p>
                    <div className="space-x-4">
                      <Button 
                        onClick={() => enrollInCourse('basic-coding')}
                        className="bg-gold hover:bg-gold-600 text-black"
                      >
                        Enroll in Basic Coding
                      </Button>
                      <Button 
                        onClick={() => enrollInCourse('digital-marketing')}
                        variant="outline"
                      >
                        Enroll in Digital Marketing
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </motion.div>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>Manage your account details and preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-20 h-20">
                      <AvatarFallback className="bg-gold text-black text-lg">
                        {getInitials(user?.name || 'Student')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold">{user?.name}</h3>
                      <p className="text-muted-foreground capitalize">{user?.role} Account</p>
                      <Badge variant="secondary">Active Student</Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Email Address</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Mail className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{user?.email}</span>
                        </div>
                      </div>
                      
                      <div>
                        <label className="text-sm font-medium">Phone Number</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Phone className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.phone || 'Not provided'}</span>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Address</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.address || 'Not provided'}</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium">Join Date</label>
                        <div className="flex items-center space-x-2 mt-1">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{userData?.profile?.joinDate}</span>
                        </div>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Enrolled Courses</label>
                        <p className="text-2xl font-bold text-gold">{enrolledCourses.length}</p>
                      </div>

                      <div>
                        <label className="text-sm font-medium">Overall Progress</label>
                        <div className="mt-2">
                          <Progress 
                            value={enrolledCourses.length > 0 
                              ? enrolledCourses.reduce((acc, course) => acc + course.progress, 0) / enrolledCourses.length
                              : 0
                            } 
                            className="h-3"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-4">
                    <Button variant="outline">
                      <Settings className="w-4 h-4 mr-2" />
                      Edit Profile
                    </Button>
                    <Button variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Download Certificate
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Notifications</CardTitle>
                  <CardDescription>Stay updated with your course progress and announcements</CardDescription>
                </CardHeader>
                <CardContent>
                  {userData?.notifications && userData.notifications.length > 0 ? (
                    <div className="space-y-4">
                      {userData.notifications.map((notification) => (
                        <div 
                          key={notification.id}
                          className={`p-4 rounded-lg border ${
                            notification.read ? 'bg-muted/30' : 'bg-gold/10 border-gold/20'
                          }`}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-start space-x-3">
                              <div className={`w-2 h-2 rounded-full mt-2 ${
                                notification.read ? 'bg-muted-foreground' : 'bg-gold'
                              }`} />
                              <div>
                                <p className={`${notification.read ? 'text-muted-foreground' : 'text-foreground'}`}>
                                  {notification.message}
                                </p>
                                <p className="text-xs text-muted-foreground mt-1">{notification.date}</p>
                              </div>
                            </div>
                            {!notification.read && (
                              <Badge variant="secondary" className="text-xs">New</Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Bell className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="font-medium mb-2">No notifications</h3>
                      <p className="text-muted-foreground">You're all caught up!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Course Video Modal */}
      <AnimatePresence>
        {selectedCourse && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedCourse(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-card rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold">{selectedCourse.title}</h2>
                  <Button variant="ghost" onClick={() => setSelectedCourse(null)}>
                    ×
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {selectedCourse.videos.map((video) => (
                    <div key={video.id} className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${video.completed ? 'bg-green-500' : 'bg-muted-foreground'}`} />
                        <Play className="w-5 h-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{video.title}</p>
                          <p className="text-sm text-muted-foreground">{video.duration}</p>
                        </div>
                      </div>
                      <Button size="sm" variant="ghost">
                        Watch
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}