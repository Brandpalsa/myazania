import { HeroSection } from '../sections/HeroSection';
import { ProgramsSection } from '../sections/ProgramsSection';
import { AboutSection } from '../sections/AboutSection';

export function HomePage() {
  return (
    <div>
      <HeroSection />
      <ProgramsSection />
      <AboutSection />
    </div>
  );
}