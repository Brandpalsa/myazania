import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { 
  Code, Megaphone, Sparkles, Calculator, 
  Headphones, TrendingUp, Shield, Heart, 
  Clock, Users, Star, ChevronRight, Calendar 
} from 'lucide-react';
import { Link } from '../../utils/router';
import { ALL_PROGRAMS, ACTIVE_PROGRAMS, COMING_SOON_PROGRAMS } from '../../data/programsData';

export function ProgramsPage() {
  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner': return 'bg-green-100 text-green-800 border-green-200';
      case 'Intermediate': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Advanced': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Professional': return 'bg-gold-100 text-gold-800 border-gold-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="min-h-screen bg-background py-16">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl md:text-5xl font-montserrat font-semibold text-foreground mb-6">
            Our Training Programs
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto font-montserrat font-light">
            Choose from our comprehensive range of skills-focused training programs designed to prepare you for career success in today's competitive market.
          </p>
        </motion.div>

        {/* Active Programs Section */}
        <motion.div 
          className="mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="text-center mb-12">
            <h2 className="text-3xl font-montserrat font-medium text-foreground mb-4">
              Available <span className="text-gold">Programs</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Currently enrolling students for these comprehensive training programs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {ACTIVE_PROGRAMS.map((program, index) => {
              const IconComponent = program.icon;
              return (
                <motion.div
                  key={program.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-xl transition-all duration-300 group cursor-pointer">
                    <CardHeader className="pb-4">
                      <div className="flex items-start justify-between mb-4">
                        <div className="w-14 h-14 bg-gold rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                          <IconComponent className="w-7 h-7 text-black" />
                        </div>
                        <div className="flex flex-col gap-2">
                          <Badge variant="outline" className={getLevelColor(program.level)}>
                            {program.level}
                          </Badge>
                          {program.rating > 0 && (
                            <div className="flex items-center space-x-1">
                              <Star className="w-3 h-3 fill-gold text-gold" />
                              <span className="text-xs font-montserrat">{program.rating}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <CardTitle className="text-xl font-montserrat font-medium text-foreground group-hover:text-gold transition-colors">
                        {program.title}
                      </CardTitle>
                      <CardDescription className="text-muted-foreground font-montserrat font-light leading-relaxed">
                        {program.description}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="space-y-6">
                      {/* Course Details */}
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-1 text-muted-foreground">
                          <Clock className="w-4 h-4" />
                          <span className="font-montserrat">{program.duration}</span>
                        </div>
                        <div className="flex items-center space-x-1 text-muted-foreground">
                          <Users className="w-4 h-4" />
                          <span className="font-montserrat">{program.students} students</span>
                        </div>
                      </div>

                      {/* Pricing and Rating */}
                      <div className="flex items-center justify-between">
                        <span className="text-2xl font-semibold text-gold font-montserrat">{program.price}</span>
                        <div className="text-sm text-muted-foreground">
                          <div className="font-medium">Job Placement</div>
                          <div className="text-gold font-semibold">{program.jobPlacementRate}%</div>
                        </div>
                      </div>

                      {/* Features */}
                      <div className="space-y-2">
                        <p className="text-sm font-medium text-foreground font-montserrat">What you'll learn:</p>
                        <div className="grid grid-cols-2 gap-1">
                          {program.features.slice(0, 4).map((feature, idx) => (
                            <div key={idx} className="flex items-center space-x-1">
                              <div className="w-1.5 h-1.5 bg-gold rounded-full" />
                              <span className="text-xs text-muted-foreground font-montserrat">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Action Button */}
                      <Link to={program.slug}>
                        <Button className="w-full bg-gold hover:bg-gold-600 text-black font-montserrat font-medium group-hover:scale-105 transition-transform">
                          Learn More
                          <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Coming Soon Programs Section */}
        {COMING_SOON_PROGRAMS.length > 0 && (
          <motion.div 
            className="mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <div className="text-center mb-12">
              <h2 className="text-3xl font-montserrat font-medium text-foreground mb-4">
                Coming Soon <span className="text-gold">Programs</span>
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Exciting new programs launching in 2025. Register your interest to be notified when applications open.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {COMING_SOON_PROGRAMS.map((program, index) => {
                const IconComponent = program.icon;
                return (
                  <motion.div
                    key={program.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-xl transition-all duration-300 group cursor-pointer relative opacity-90">
                      {/* Coming Soon Badge */}
                      <div className="absolute top-4 right-4 z-10">
                        <Badge className="bg-gold text-black font-medium">
                          <Calendar className="w-3 h-3 mr-1" />
                          Coming Soon
                        </Badge>
                      </div>

                      <CardHeader className="pb-4">
                        <div className="flex items-start justify-between mb-4">
                          <div className="w-14 h-14 bg-muted rounded-xl flex items-center justify-center">
                            <IconComponent className="w-7 h-7 text-muted-foreground" />
                          </div>
                          <Badge variant="outline" className={getLevelColor(program.level)}>
                            {program.level}
                          </Badge>
                        </div>
                        <CardTitle className="text-xl font-montserrat font-medium text-muted-foreground">
                          {program.title}
                        </CardTitle>
                        <CardDescription className="text-muted-foreground font-montserrat font-light leading-relaxed opacity-80">
                          {program.description}
                        </CardDescription>
                      </CardHeader>
                      
                      <CardContent className="space-y-6">
                        {/* Course Details */}
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center space-x-1 text-muted-foreground">
                            <Clock className="w-4 h-4" />
                            <span className="font-montserrat">{program.duration}</span>
                          </div>
                          <div className="flex items-center space-x-1 text-muted-foreground">
                            <Calendar className="w-4 h-4" />
                            <span className="font-montserrat">2025</span>
                          </div>
                        </div>

                        {/* Pricing */}
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-semibold text-muted-foreground font-montserrat">{program.price}</span>
                          <div className="text-sm text-muted-foreground">
                            <div className="font-medium">Expected Launch</div>
                            <div className="text-gold font-semibold">2025</div>
                          </div>
                        </div>

                        {/* Features */}
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-muted-foreground font-montserrat">Will include:</p>
                          <div className="grid grid-cols-2 gap-1">
                            {program.features.slice(0, 4).map((feature, idx) => (
                              <div key={idx} className="flex items-center space-x-1">
                                <div className="w-1.5 h-1.5 bg-muted-foreground rounded-full" />
                                <span className="text-xs text-muted-foreground font-montserrat">{feature}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Action Button */}
                        <Button 
                          variant="outline" 
                          className="w-full border-muted-foreground text-muted-foreground hover:bg-muted font-montserrat font-medium"
                          disabled
                        >
                          <Calendar className="w-4 h-4 mr-2" />
                          Notify Me When Available
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* Call to Action */}
        <motion.div 
          className="text-center mt-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="bg-muted rounded-2xl p-8 md:p-12">
            <h2 className="text-3xl font-montserrat font-semibold text-foreground mb-4">
              Ready to Start Your Journey?
            </h2>
            <p className="text-lg text-muted-foreground mb-8 font-montserrat font-light max-w-2xl mx-auto">
              Contact us today to learn more about our programs and find the perfect training to advance your career.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/contact">
                <Button size="lg" className="bg-gold hover:bg-gold-600 text-black font-montserrat font-medium">
                  Contact Us Today
                </Button>
              </Link>
              <Link to="/about">
                <Button size="lg" variant="outline" className="font-montserrat font-medium">
                  Learn About Us
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}