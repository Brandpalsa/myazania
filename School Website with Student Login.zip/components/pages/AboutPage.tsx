import { motion } from 'motion/react';
import { AboutSection } from '../sections/AboutSection';

export function AboutPage() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="pt-8"
    >
      <AboutSection />
    </motion.div>
  );
}