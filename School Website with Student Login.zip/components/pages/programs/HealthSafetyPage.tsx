import { getProgramById } from '../../../data/programsData';
import { ProgramPageLayout } from '../../common/ProgramPageLayout';

export function HealthSafetyPage() {
  const program = getProgramById('health-safety');
  
  if (!program) {
    return <div>Program not found</div>;
  }

  return <ProgramPageLayout program={program} />;
}