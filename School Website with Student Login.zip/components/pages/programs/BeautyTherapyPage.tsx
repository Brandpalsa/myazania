import { getProgramById } from '../../../data/programsData';
import { ProgramPageLayout } from '../../common/ProgramPageLayout';

export function BeautyTherapyPage() {
  const program = getProgramById('beauty-therapy');
  
  if (!program) {
    return <div>Program not found</div>;
  }

  return <ProgramPageLayout program={program} />;
}