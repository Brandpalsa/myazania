import { getProgramById } from '../../../data/programsData';
import { ProgramPageLayout } from '../../common/ProgramPageLayout';

export function CustomerServicePage() {
  const program = getProgramById('customer-service');
  
  if (!program) {
    return <div>Program not found</div>;
  }

  return <ProgramPageLayout program={program} />;
}