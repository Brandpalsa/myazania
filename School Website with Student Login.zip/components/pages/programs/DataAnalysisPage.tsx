import { getProgramById } from '../../../data/programsData';
import { ProgramPageLayout } from '../../common/ProgramPageLayout';

export function DataAnalysisPage() {
  const program = getProgramById('data-analysis');
  
  if (!program) {
    return <div>Program not found</div>;
  }

  return <ProgramPageLayout program={program} />;
}