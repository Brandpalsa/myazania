import { getProgramById } from '../../../data/programsData';
import { ProgramPageLayout } from '../../common/ProgramPageLayout';

export function EntrepreneurshipPage() {
  const program = getProgramById('entrepreneurship');
  
  if (!program) {
    return <div>Program not found</div>;
  }

  return <ProgramPageLayout program={program} />;
}