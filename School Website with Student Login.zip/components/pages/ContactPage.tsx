import { motion, useInView } from 'motion/react';
import { useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { MapPin, Phone, Mail, Clock, BookOpen } from 'lucide-react';
import { Map } from '../common/Map';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { 
    opacity: 0, 
    y: 30,
    scale: 0.9
  },
  visible: { 
    opacity: 1, 
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15
    }
  }
};

export function ContactPage() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const siteInfo = {
    name: "Azania Academy",
    tagline: "Skills-Focused Training",
    description: "Azania Academy is a skills-focused institution offering hands-on, vocational training that empowers individuals to thrive in the real world.",
    phone: ["065 324 8692", "065 248 8692"],
    email: "academy@myazania.co.za",
    address: {
      street: "Wilma Court Building office number 12 1floor",
      city: "Springs",
      province: "Gauteng",
      postalCode: "1559",
      country: "South Africa"
    }
  };

  return (
    <section className="py-20 bg-muted/30" id="contact">
      <div className="content-container">
        <motion.div 
          ref={ref}
          className="space-y-16"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          
          {/* Header */}
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h2 className="text-3xl md:text-4xl lg:text-5xl mb-4">
              Get In <span className="text-gold">Touch</span>
            </h2>
            <div className="w-20 h-1 bg-gradient-to-r from-gold to-gold-400 rounded-full mb-6 mx-auto"></div>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Ready to start your learning journey? Contact us today and let's discuss 
              how we can help you achieve your career goals.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            
            {/* Contact Information */}
            <motion.div
              className="space-y-8"
              variants={itemVariants}
            >
              <Card className="border border-border/50 hover:border-gold/30 transition-all duration-300 hover:shadow-lg hover:shadow-gold/10">
                <CardHeader className="pb-4">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="w-12 h-12 bg-gold rounded-lg flex items-center justify-center">
                      <BookOpen className="w-6 h-6 text-black" />
                    </div>
                    <div>
                      <CardTitle className="text-xl font-montserrat font-medium text-foreground">
                        {siteInfo.name}
                      </CardTitle>
                      <p className="text-sm text-gold font-montserrat font-normal">{siteInfo.tagline}</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground font-montserrat font-light leading-relaxed">
                    {siteInfo.description}
                  </p>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gold rounded-lg flex items-center justify-center">
                      <Phone className="w-6 h-6 text-black" />
                    </div>
                    <div>
                      <h3 className="font-medium font-montserrat mb-1">Phone</h3>
                      <p className="text-muted-foreground font-montserrat">{siteInfo.phone.join(' / ')}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gold rounded-lg flex items-center justify-center">
                      <Mail className="w-6 h-6 text-black" />
                    </div>
                    <div>
                      <h3 className="font-medium font-montserrat mb-1">Email</h3>
                      <p className="text-muted-foreground font-montserrat">{siteInfo.email}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gold rounded-lg flex items-center justify-center">
                      <MapPin className="w-6 h-6 text-black" />
                    </div>
                    <div>
                      <h3 className="font-medium font-montserrat mb-1">Address</h3>
                      <p className="text-muted-foreground font-montserrat">
                        {siteInfo.address.street}<br />
                        {siteInfo.address.city}, {siteInfo.address.province} {siteInfo.address.postalCode}<br />
                        {siteInfo.address.country}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-gold rounded-lg flex items-center justify-center">
                      <Clock className="w-6 h-6 text-black" />
                    </div>
                    <div>
                      <h3 className="font-medium font-montserrat mb-1">Office Hours</h3>
                      <p className="text-muted-foreground font-montserrat">
                        Monday - Friday: 8:00 AM - 5:00 PM<br />
                        Saturday: 9:00 AM - 2:00 PM<br />
                        Sunday: Closed
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Map */}
              <motion.div variants={itemVariants}>
                <Card className="border border-border/50 hover:border-gold/30 transition-all duration-300 hover:shadow-lg hover:shadow-gold/10">
                  <CardHeader>
                    <CardTitle className="text-xl font-montserrat font-medium">Visit Our Campus</CardTitle>
                    <p className="text-muted-foreground font-montserrat">
                      Find us at our Springs location in Gauteng.
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 rounded-lg overflow-hidden">
                      <Map />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              variants={itemVariants}
            >
              <Card className="border border-border/50 hover:border-gold/30 transition-all duration-300 hover:shadow-lg hover:shadow-gold/10">
                <CardHeader>
                  <CardTitle className="text-2xl font-montserrat font-medium">Send us a message</CardTitle>
                  <p className="text-muted-foreground font-montserrat">
                    Fill out the form below and we'll get back to you as soon as possible.
                  </p>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">First Name</label>
                        <Input placeholder="Enter your first name" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Last Name</label>
                        <Input placeholder="Enter your last name" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Email</label>
                      <Input type="email" placeholder="Enter your email address" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Phone</label>
                      <Input type="tel" placeholder="Enter your phone number" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Program Interest</label>
                      <select className="w-full px-3 py-2 bg-background border border-input rounded-md text-sm">
                        <option value="">Select a program</option>
                        <option value="basic-coding">Basic Coding</option>
                        <option value="digital-marketing">Digital Marketing</option>
                        <option value="beauty-therapy">Beauty Therapy & More</option>
                        <option value="bookkeeping">Bookkeeping & Payroll</option>
                        <option value="customer-service">Customer Service Excellence</option>
                        <option value="entrepreneurship">Entrepreneurship Development</option>
                        <option value="health-safety">Health & Safety Management</option>
                        <option value="life-skills">Life Skills Development</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Message</label>
                      <Textarea 
                        placeholder="Tell us about your goals and how we can help you..."
                        rows={4}
                      />
                    </div>
                    <motion.div
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Button className="w-full bg-gold hover:bg-gold-600 text-black font-montserrat font-medium">
                        Send Message
                      </Button>
                    </motion.div>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}