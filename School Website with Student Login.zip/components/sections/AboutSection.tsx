import { motion, useInView } from 'motion/react';
import { useRef } from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Link } from '../../utils/router';
import { Target, Users, Award, Heart, ArrowRight } from 'lucide-react';

const stats = [
  { 
    icon: Users, 
    number: "1,000+", 
    label: "Students Trained",
    description: "Across all programs"
  },
  { 
    icon: Award, 
    number: "95%", 
    label: "Job Placement Rate",
    description: "Within 6 months"
  },
  { 
    icon: Target, 
    number: "8+", 
    label: "Specialized Programs",
    description: "Industry-relevant skills"
  },
  { 
    icon: Heart, 
    number: "100%", 
    label: "Student Satisfaction",
    description: "Excellence commitment"
  }
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.1
    }
  }
};

const itemVariants = {
  hidden: { 
    opacity: 0, 
    y: 30,
    scale: 0.9
  },
  visible: { 
    opacity: 1, 
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15
    }
  }
};

export function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section className="py-20 bg-muted/30" id="about">
      <div className="content-container">
        <motion.div 
          ref={ref}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          
          {/* Content */}
          <motion.div className="space-y-6" variants={itemVariants}>
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <h2 className="text-3xl md:text-4xl lg:text-5xl mb-4">
                Empowering <span className="text-gold">African</span> Talent
              </h2>
              <div className="w-20 h-1 bg-gradient-to-r from-gold to-gold-400 rounded-full mb-6"></div>
            </motion.div>
            
            <motion.p 
              className="text-lg text-muted-foreground leading-relaxed"
              variants={itemVariants}
            >
              At MyAzania Academy, we believe in the transformative power of education and skills development. 
              Our mission is to bridge the skills gap in South Africa by providing world-class training 
              programs that prepare individuals for successful careers in today's competitive job market.
            </motion.p>
            
            <motion.p 
              className="text-lg text-muted-foreground leading-relaxed"
              variants={itemVariants}
            >
              Since our founding, we have been committed to creating opportunities for South Africans 
              to develop practical, industry-relevant skills that lead to meaningful employment and 
              entrepreneurial success.
            </motion.p>

            <motion.div 
              className="pt-4"
              variants={itemVariants}
            >
              <Link to="/about">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 25 }}
                >
                  <Button 
                    size="lg" 
                    className="bg-gold text-black hover:bg-gold-600 hover:text-black font-montserrat font-medium group"
                  >
                    Learn Our Story
                    <motion.div
                      className="ml-2"
                      animate={{ x: [0, 3, 0] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      <ArrowRight className="w-4 h-4 text-foreground" />
                    </motion.div>
                  </Button>
                </motion.div>
              </Link>
            </motion.div>
          </motion.div>

          {/* Stats Grid */}
          <motion.div 
            className="grid grid-cols-2 gap-8 items-start"
            variants={containerVariants}
          >
            {stats.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  whileHover={{ 
                    scale: 1.05,
                    rotateY: 5,
                    transition: { duration: 0.3 }
                  }}
                  className="group"
                >
                  <Card className="h-full p-6 border border-border/50 hover:border-gold/30 transition-all duration-300 hover:shadow-lg hover:shadow-gold/10 min-h-[200px] flex items-center">
                    <CardContent className="p-0 text-center space-y-3 w-full flex flex-col items-center justify-center">
                      <motion.div 
                        className="inline-flex items-center justify-center w-20 h-20 bg-black rounded-xl group-hover:bg-gray-800 transition-colors duration-300"
                        whileHover={{ rotate: 360 }}
                        transition={{ duration: 0.6 }}
                      >
                        <IconComponent className="w-10 h-10 text-white" />
                      </motion.div>
                      
                      <motion.div 
                        className="text-2xl md:text-3xl font-bold text-gold"
                        initial={{ scale: 0 }}
                        animate={isInView ? { scale: 1 } : {}}
                        transition={{ 
                          delay: 0.3 + (index * 0.1),
                          type: "spring",
                          stiffness: 200
                        }}
                      >
                        {stat.number}
                      </motion.div>
                      
                      <div className="space-y-1">
                        <div className="font-medium text-foreground group-hover:text-gold transition-colors">
                          {stat.label}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {stat.description}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}