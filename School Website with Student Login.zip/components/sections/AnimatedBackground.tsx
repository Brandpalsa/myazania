import { motion } from 'motion/react';
import backgroundImage from 'figma:asset/0cbed85f6b82128b655c7b44d8516828c34966dc.png';

export function AnimatedBackground() {
  return (
    <div className="animated-background absolute inset-0 overflow-hidden">
      {/* Static background with subtle animation */}
      <div
        className="absolute inset-0 w-full h-full"
        style={{
          backgroundImage: `url(${backgroundImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center center',
          backgroundRepeat: 'no-repeat',
          filter: 'brightness(1.0) contrast(1.0)',
        }}
      />


      {/* Static overlay system */}
      <div className="absolute inset-0 z-10">
        {/* Primary dark overlay */}
        <div 
          className="absolute inset-0"
          style={{
            background: `
              linear-gradient(
                135deg,
                rgba(0, 0, 0, 0.85) 0%,
                rgba(0, 0, 0, 0.75) 20%,
                rgba(0, 0, 0, 0.65) 40%,
                rgba(0, 0, 0, 0.70) 60%,
                rgba(0, 0, 0, 0.80) 80%,
                rgba(0, 0, 0, 0.90) 100%
              ),
              radial-gradient(
                ellipse at center,
                rgba(0, 0, 0, 0.3) 0%,
                rgba(0, 0, 0, 0.8) 100%
              )
            `
          }}
        />
        
        {/* Secondary overlay for depth */}
        <div 
          className="absolute inset-0"
          style={{
            background: `
              linear-gradient(
                45deg,
                rgba(0, 0, 0, 0.3) 0%,
                transparent 30%,
                transparent 70%,
                rgba(0, 0, 0, 0.2) 100%
              )
            `
          }}
        />
      </div>

      {/* Static ambient lighting effects */}
      <div
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(
              ellipse 800px 600px at 25% 25%,
              rgba(155, 126, 70, 0.10) 0%,
              rgba(155, 126, 70, 0.05) 25%,
              transparent 50%
            ),
            radial-gradient(
              ellipse 600px 800px at 75% 75%,
              rgba(155, 126, 70, 0.06) 0%,
              rgba(155, 126, 70, 0.03) 25%,
              transparent 50%
            ),
            radial-gradient(
              ellipse 400px 400px at 50% 20%,
              rgba(255, 255, 255, 0.02) 0%,
              transparent 40%
            )
          `
        }}
      />

      {/* Static particle field */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `
            radial-gradient(circle at 15% 25%, rgba(155, 126, 70, 0.03) 1px, transparent 1px),
            radial-gradient(circle at 85% 75%, rgba(155, 126, 70, 0.02) 1px, transparent 1px),
            radial-gradient(circle at 65% 15%, rgba(255, 255, 255, 0.015) 1px, transparent 1px),
            radial-gradient(circle at 35% 85%, rgba(155, 126, 70, 0.02) 1px, transparent 1px)
          `,
          backgroundSize: '120px 120px, 180px 180px, 140px 140px, 160px 160px',
        }}
      />

      {/* Cinematic vignette effect */}
      <div 
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(
              ellipse at center,
              transparent 20%,
              rgba(0, 0, 0, 0.1) 40%,
              rgba(0, 0, 0, 0.25) 70%,
              rgba(0, 0, 0, 0.5) 100%
            )
          `
        }}
      />
    </div>
  );
}