import { motion, useInView } from 'motion/react';
import { useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Link } from '../../utils/router';
import { 
  ChevronRight, 
  Clock, 
  Users, 
  Award, 
  Briefcase,
  Calendar
} from 'lucide-react';
import { ALL_PROGRAMS, ACTIVE_PROGRAMS, COMING_SOON_PROGRAMS } from '../../data/programsData';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.2
    }
  }
};

const cardVariants = {
  hidden: { 
    opacity: 0, 
    y: 50,
    scale: 0.9
  },
  visible: { 
    opacity: 1, 
    y: 0,
    scale: 1,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15
    }
  }
};

export function ProgramsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner': return 'bg-green-100 text-green-800 border-green-200';
      case 'Intermediate': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Advanced': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Professional': return 'bg-gold-100 text-gold-800 border-gold-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <section className="py-20 bg-gradient-to-b from-background to-muted/20" id="programs">
      <div className="content-container">
        <motion.div 
          ref={ref}
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.h2 
            className="text-3xl md:text-4xl lg:text-5xl mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.6 }}
          >
            Featured <span className="text-gold">Training Programs</span>
          </motion.h2>
          <motion.p 
            className="text-lg text-muted-foreground max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4, duration: 0.6 }}
          >
            Choose from our comprehensive range of skills-based training programs designed 
            to prepare you for the modern workforce.
          </motion.p>
        </motion.div>

        {/* Active Programs */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {ACTIVE_PROGRAMS.map((program, index) => (
            <motion.div
              key={program.id}
              variants={cardVariants}
              whileHover={{ 
                y: -8,
                transition: { duration: 0.3, ease: "easeOut" }
              }}
              className="group"
            >
              <Card className="h-full overflow-hidden border border-border/50 hover:border-gold/30 transition-all duration-300 hover:shadow-lg hover:shadow-gold/10 flex flex-col">
                <div className={`h-2 bg-gradient-to-r ${program.gradient}`} />
                
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between mb-3">
                    <motion.div 
                      className="w-16 h-16 bg-gold rounded-xl flex items-center justify-center"
                      whileHover={{ 
                        scale: 1.1, 
                        rotate: [0, -5, 5, 0],
                        transition: { duration: 0.5 }
                      }}
                    >
                      <program.icon className="w-8 h-8 text-black" />
                    </motion.div>
                    <div className="flex flex-col gap-2">
                      <Badge 
                        variant="secondary" 
                        className="bg-gold/10 text-gold hover:bg-gold/20 transition-colors"
                      >
                        {program.price}
                      </Badge>
                      <Badge variant="outline" className={getLevelColor(program.level)}>
                        {program.level}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardTitle className="program-title text-xl group-hover:text-gold transition-colors duration-300">
                    {program.title}
                  </CardTitle>
                  
                  <p className="program-description text-muted-foreground">
                    {program.description}
                  </p>
                </CardHeader>

                <CardContent className="flex flex-col flex-1">
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4 text-muted-foreground" />
                      <span>{program.duration}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="w-4 h-4 text-muted-foreground" />
                      <span>{program.students}</span>
                    </div>
                  </div>

                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-1 text-sm font-medium">
                      <Award className="w-4 h-4 text-foreground" />
                      <span>Key Skills:</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {program.features.map((feature, featureIndex) => (
                        <motion.span
                          key={featureIndex}
                          className="text-xs px-2 py-1 bg-muted rounded-full text-muted-foreground hover:bg-gold/10 hover:text-gold transition-colors cursor-default"
                          whileHover={{ scale: 1.05 }}
                          transition={{ type: "spring", stiffness: 400, damping: 25 }}
                        >
                          {feature}
                        </motion.span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 pt-4">
                    <Link to={program.slug}>
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button 
                          className="w-full bg-black text-white hover:bg-gray-800 group/btn"
                          size="sm"
                        >
                          <Briefcase className="w-4 h-4 mr-2 text-primary-foreground" />
                          View Program Details
                          <motion.div
                            className="ml-2"
                            animate={{ x: [0, 3, 0] }}
                            transition={{ 
                              duration: 1.5, 
                              repeat: Infinity,
                              ease: "easeInOut"
                            }}
                          >
                            <ChevronRight className="w-4 h-4 text-primary-foreground" />
                          </motion.div>
                        </Button>
                      </motion.div>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Coming Soon Programs Section */}
        {COMING_SOON_PROGRAMS.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 1.0, duration: 0.6 }}
            className="mb-12"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl md:text-3xl font-montserrat font-medium text-foreground mb-4">
                Coming Soon <span className="text-gold">Programs</span>
              </h3>
              <p className="text-muted-foreground max-w-xl mx-auto">
                Exciting new programs launching soon. Register your interest to be notified when applications open.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {COMING_SOON_PROGRAMS.map((program, index) => (
                <motion.div
                  key={program.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 1.2 + (index * 0.1), duration: 0.6 }}
                  className="group"
                >
                  <Card className="h-full overflow-hidden border border-border/50 hover:border-gold/30 transition-all duration-300 hover:shadow-lg hover:shadow-gold/10 flex flex-col relative">
                    <div className={`h-2 bg-gradient-to-r ${program.gradient} opacity-60`} />
                    
                    {/* Coming Soon Badge */}
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-gold text-black font-medium">
                        <Calendar className="w-3 h-3 mr-1" />
                        Coming Soon
                      </Badge>
                    </div>
                    
                    <CardHeader className="pb-4 opacity-90">
                      <div className="flex items-start justify-between mb-3">
                        <div className="w-16 h-16 bg-muted rounded-xl flex items-center justify-center">
                          <program.icon className="w-8 h-8 text-muted-foreground" />
                        </div>
                        <div className="flex flex-col gap-2">
                          <Badge 
                            variant="secondary" 
                            className="bg-muted text-muted-foreground"
                          >
                            {program.price}
                          </Badge>
                          <Badge variant="outline" className={getLevelColor(program.level)}>
                            {program.level}
                          </Badge>
                        </div>
                      </div>
                      
                      <CardTitle className="text-xl text-muted-foreground">
                        {program.title}
                      </CardTitle>
                      
                      <p className="text-muted-foreground opacity-80">
                        {program.description}
                      </p>
                    </CardHeader>

                    <CardContent className="flex flex-col flex-1 opacity-90">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{program.duration}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>2025</span>
                        </div>
                      </div>

                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-1 text-sm font-medium text-muted-foreground">
                          <Award className="w-4 h-4" />
                          <span>Will Include:</span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {program.features.slice(0, 3).map((feature, featureIndex) => (
                            <span
                              key={featureIndex}
                              className="text-xs px-2 py-1 bg-muted/50 rounded-full text-muted-foreground"
                            >
                              {feature}
                            </span>
                          ))}
                          {program.features.length > 3 && (
                            <span className="text-xs px-2 py-1 bg-muted/50 rounded-full text-muted-foreground">
                              +{program.features.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="mt-4 pt-4">
                        <Button 
                          variant="outline"
                          className="w-full border-muted-foreground text-muted-foreground hover:bg-muted"
                          size="sm"
                          disabled
                        >
                          <Calendar className="w-4 h-4 mr-2" />
                          Notify Me When Available
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.6 }}
        >
          <Link to="/programs">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 25 }}
            >
              <Button 
                size="lg" 
                variant="outline" 
                className="border-gold text-gold hover:bg-gold hover:text-black font-montserrat font-medium px-8 group"
              >
                View All Programs
                <motion.div
                  className="ml-2"
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <ChevronRight className="w-5 h-5 text-foreground" />
                </motion.div>
              </Button>
            </motion.div>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}