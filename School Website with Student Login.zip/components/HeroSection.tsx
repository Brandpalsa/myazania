import { Button } from './ui/button';
import { ArrowRight, Play, Users, Award, Globe } from 'lucide-react';

export function HeroSection() {
  return (
    <section id="home" className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div className="text-center lg:text-left">
            <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6">
              Empowering Skills for the
              <span className="text-blue-600 block">Real World</span>
            </h1>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl">
              MyAzania Academy is a skills-focused institution offering hands-on, vocational training 
              that empowers individuals to thrive in the real world through practical education and industry expertise.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
              <Button size="lg" className="flex items-center space-x-2">
                <span>Explore Programs</span>
                <ArrowRight className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="lg" className="flex items-center space-x-2">
                <Play className="w-4 h-4" />
                <span>Watch Video</span>
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-gray-200">
              <div className="text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start mb-2">
                  <Users className="w-6 h-6 text-blue-600 mr-2" />
                  <span className="text-2xl font-bold text-gray-900">1000+</span>
                </div>
                <p className="text-sm text-gray-600">Students Trained</p>
              </div>
              <div className="text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start mb-2">
                  <Award className="w-6 h-6 text-blue-600 mr-2" />
                  <span className="text-2xl font-bold text-gray-900">15+</span>
                </div>
                <p className="text-sm text-gray-600">Programs Offered</p>
              </div>
              <div className="text-center lg:text-left">
                <div className="flex items-center justify-center lg:justify-start mb-2">
                  <Globe className="w-6 h-6 text-blue-600 mr-2" />
                  <span className="text-2xl font-bold text-gray-900">95%</span>
                </div>
                <p className="text-sm text-gray-600">Job Placement</p>
              </div>
            </div>
          </div>

          {/* Right Column - Image */}
          <div className="relative">
            <div className="aspect-square bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl p-8 text-center flex items-center justify-center">
              <div className="text-white">
                <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-12 h-12" />
                </div>
                <h3 className="text-xl font-bold mb-2">Quality Education</h3>
                <p className="text-blue-100">Hands-on training with industry experts</p>
              </div>
            </div>
            
            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-yellow-400 rounded-full flex items-center justify-center">
              <span className="text-white font-bold">New</span>
            </div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
              <Play className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}