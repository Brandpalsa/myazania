import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from '../ui/button';
import { ThemeToggle } from '../ui/theme-toggle';
import { Link, useRouter } from '../../utils/router';
import { useAuth } from '../../utils/auth';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { 
  Menu, X, GraduationCap, LogIn, ChevronDown, 
  User, LogOut, Settings, BookOpen 
} from 'lucide-react';

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const { currentRoute } = useRouter();
  const { user, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigationItems = [
    { label: 'Home', to: '/' },
    { label: 'Programs', to: '/programs' },
    { label: 'About', to: '/about' },
    { label: 'Contact', to: '/contact' }
  ];

  const isActiveRoute = (path: string) => {
    if (path === '/' && currentRoute?.path === '/') return true;
    if (path !== '/' && currentRoute?.path?.startsWith(path)) return true;
    return false;
  };

  const getDashboardPath = () => {
    if (!user) return '/login';
    switch (user.role) {
      case 'admin':
        return '/admin-dashboard';
      case 'teacher':
        return '/teacher-dashboard';
      case 'student':
      default:
        return '/student-dashboard';
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const menuVariants = {
    closed: {
      opacity: 0,
      height: 0,
      transition: {
        duration: 0.3,
        ease: "easeInOut"
      }
    },
    open: {
      opacity: 1,
      height: "auto",
      transition: {
        duration: 0.3,
        ease: "easeInOut",
        staggerChildren: 0.05,
        delayChildren: 0.1
      }
    }
  };

  const menuItemVariants = {
    closed: { opacity: 0, x: -20 },
    open: { opacity: 1, x: 0 }
  };

  return (
    <motion.header 
      className={`site-header ${isScrolled ? 'scrolled' : ''}`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <div className="content-container">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo */}
          <Link to="/">
            <motion.div 
              className="flex items-center space-x-2 group"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 25 }}
            >
              <motion.div
                className="flex items-center justify-center w-10 h-10 bg-gold rounded-lg group-hover:bg-gold-600 transition-colors duration-300"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <GraduationCap className="w-6 h-6 text-black" />
              </motion.div>
              <div className="flex flex-col">
                <span className="site-title text-foreground text-lg leading-tight">Azania</span>
                <span className="site-tagline text-gold text-xs leading-tight">Academy</span>
              </div>
            </motion.div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center primary-navigation">
            {navigationItems.map((item, index) => (
              <motion.div
                key={item.to}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 + 0.3 }}
              >
                <Link to={item.to}>
                  <motion.div
                    className={`nav-link relative ${isActiveRoute(item.to) ? 'text-gold' : ''}`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    {item.label}
                    {isActiveRoute(item.to) && (
                      <motion.div
                        className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-gold rounded-full"
                        layoutId="activeIndicator"
                        transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      />
                    )}
                  </motion.div>
                </Link>
              </motion.div>
            ))}
          </nav>

          {/* Right side actions */}
          <div className="flex items-center space-x-4">
            {/* User Authentication Area */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
            >
              {user ? (
                // Authenticated User Menu
                <div className="relative">
                  <motion.button
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-gold text-black text-sm">
                        {getInitials(user.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden sm:block text-left">
                      <p className="text-sm font-medium">{user.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
                    </div>
                    <ChevronDown className={`w-4 h-4 transition-transform ${showUserMenu ? 'rotate-180' : ''}`} />
                  </motion.button>

                  {/* User Dropdown Menu */}
                  <AnimatePresence>
                    {showUserMenu && (
                      <motion.div
                        initial={{ opacity: 0, y: -10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -10, scale: 0.95 }}
                        transition={{ duration: 0.2 }}
                        className="absolute right-0 top-full mt-2 w-64 bg-card border border-border rounded-lg shadow-lg z-50"
                        onMouseLeave={() => setShowUserMenu(false)}
                      >
                        <div className="p-4 border-b border-border">
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-12 h-12">
                              <AvatarFallback className="bg-gold text-black">
                                {getInitials(user.name)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{user.name}</p>
                              <p className="text-sm text-muted-foreground">{user.email}</p>
                              <p className="text-xs text-gold capitalize">{user.role} Account</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="p-2">
                          <Link to={getDashboardPath()}>
                            <motion.button
                              onClick={() => setShowUserMenu(false)}
                              className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-colors text-left"
                              whileHover={{ x: 4 }}
                            >
                              <BookOpen className="w-4 h-4" />
                              <span>Dashboard</span>
                            </motion.button>
                          </Link>
                          
                          <motion.button
                            onClick={() => {
                              setShowUserMenu(false);
                              logout();
                            }}
                            className="w-full flex items-center space-x-3 p-3 rounded-lg hover:bg-muted transition-colors text-left text-destructive"
                            whileHover={{ x: 4 }}
                          >
                            <LogOut className="w-4 h-4" />
                            <span>Sign Out</span>
                          </motion.button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ) : (
                // Login Button for Non-authenticated Users
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Link to="/login">
                    <Button 
                      size="sm" 
                      className="student-login-btn bg-gold text-black hover:bg-gold-600 hover:text-black font-montserrat font-medium hidden sm:flex"
                    >
                      <LogIn className="w-4 h-4 mr-2 text-black" />
                      Student Login
                    </Button>
                  </Link>
                </motion.div>
              )}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7 }}
            >
              <ThemeToggle />
            </motion.div>

            {/* Mobile menu toggle */}
            <motion.button
              className="md:hidden mobile-menu-toggle p-2 text-foreground hover:text-gold transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.8 }}
            >
              <AnimatePresence mode="wait">
                {isMobileMenuOpen ? (
                  <motion.div
                    key="close"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <X className="w-6 h-6 text-foreground" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="menu"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Menu className="w-6 h-6 text-foreground" />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.nav
              className="md:hidden mobile-navigation border-t border-gold/20 overflow-hidden"
              variants={menuVariants}
              initial="closed"
              animate="open"
              exit="closed"
            >
              <div className="py-4 space-y-2">
                {navigationItems.map((item, index) => (
                  <motion.div
                    key={item.to}
                    variants={menuItemVariants}
                  >
                    <Link 
                      to={item.to} 
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <motion.div
                        className={`nav-link ${isActiveRoute(item.to) ? 'text-gold bg-muted' : ''}`}
                        whileHover={{ x: 10, backgroundColor: "var(--muted)" }}
                        transition={{ type: "spring", stiffness: 400, damping: 25 }}
                      >
                        {item.label}
                        {isActiveRoute(item.to) && (
                          <motion.div
                            className="ml-auto"
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ type: "spring", stiffness: 400 }}
                          >
                            <ChevronDown className="w-4 h-4 rotate-90 text-foreground" />
                          </motion.div>
                        )}
                      </motion.div>
                    </Link>
                  </motion.div>
                ))}
                
                <motion.div
                  variants={menuItemVariants}
                  className="pt-4 border-t border-gold/20"
                >
                  {user ? (
                    // Mobile authenticated user section
                    <div className="space-y-2">
                      <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-gold text-black">
                            {getInitials(user.name)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-sm">{user.name}</p>
                          <p className="text-xs text-muted-foreground capitalize">{user.role}</p>
                        </div>
                      </div>
                      
                      <Link to={getDashboardPath()} onClick={() => setIsMobileMenuOpen(false)}>
                        <Button className="w-full bg-gold text-black hover:bg-gold-600 mb-2">
                          <BookOpen className="w-4 h-4 mr-2" />
                          Dashboard
                        </Button>
                      </Link>
                      
                      <Button 
                        variant="outline" 
                        className="w-full text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          logout();
                        }}
                      >
                        <LogOut className="w-4 h-4 mr-2" />
                        Sign Out
                      </Button>
                    </div>
                  ) : (
                    // Mobile login button
                    <motion.div
                      whileHover={{ x: 10 }}
                      transition={{ type: "spring", stiffness: 400, damping: 25 }}
                    >
                      <Link to="/login" onClick={() => setIsMobileMenuOpen(false)}>
                        <Button 
                          size="sm" 
                          className="student-login-btn bg-gold text-black hover:bg-gold-600 hover:text-black font-montserrat font-medium w-full"
                        >
                          <LogIn className="w-4 h-4 mr-2 text-black" />
                          Student Login
                        </Button>
                      </Link>
                    </motion.div>
                  )}
                </motion.div>
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </div>
    </motion.header>
  );
}