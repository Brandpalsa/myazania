import { motion } from 'motion/react';
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Clock, Users, Star, CheckCircle, ChevronRight, 
  Award, Calendar, Target, AlertCircle
} from 'lucide-react';
import { Link } from '../../utils/router';
import { useAuth } from '../../utils/auth';
import { Program } from '../../data/programsData';

interface ProgramPageLayoutProps {
  program: Program;
  onEnrollment?: () => void;
}

export function ProgramPageLayout({ program, onEnrollment }: ProgramPageLayoutProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner': return 'bg-green-100 text-green-800 border-green-200';
      case 'Intermediate': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Advanced': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Professional': return 'bg-gold-100 text-gold-800 border-gold-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleEnrollment = () => {
    if (onEnrollment) {
      onEnrollment();
    } else if (user) {
      window.location.href = `/student-dashboard?enroll=${program.id}`;
    } else {
      window.location.href = `/login?return=/programs/${program.id}&enroll=true`;
    }
  };

  return (
    <div className="min-h-screen bg-background py-16">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Coming Soon Banner */}
        {program.comingSoon && (
          <motion.div 
            className="bg-gold/10 border border-gold/20 rounded-lg p-4 mb-8 text-center"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center justify-center space-x-2 text-gold">
              <Calendar className="w-5 h-5" />
              <span className="font-montserrat font-medium">Coming Soon - Launching {program.startDates[0]}</span>
            </div>
            <p className="text-sm text-muted-foreground mt-2 font-montserrat">
              Register your interest to be notified when applications open
            </p>
          </motion.div>
        )}

        {/* Hero Section */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: program.comingSoon ? 0.2 : 0 }}
        >
          <div className="flex items-center justify-center mb-6">
            <div className={`w-20 h-20 ${program.comingSoon ? 'bg-muted' : 'bg-gold'} rounded-2xl flex items-center justify-center mr-4`}>
              <program.icon className={`w-10 h-10 ${program.comingSoon ? 'text-muted-foreground' : 'text-black'}`} />
            </div>
            <div className="text-left">
              <h1 className="text-4xl md:text-5xl font-montserrat font-semibold text-foreground">
                {program.title}
              </h1>
              <div className="flex items-center space-x-4 mt-2">
                <Badge variant="outline" className={getLevelColor(program.level)}>
                  {program.level}
                </Badge>
                {program.comingSoon && (
                  <Badge className="bg-gold text-black">
                    <Calendar className="w-3 h-3 mr-1" />
                    Coming Soon
                  </Badge>
                )}
                {!program.comingSoon && program.rating > 0 && (
                  <div className="flex items-center space-x-1 text-muted-foreground">
                    <Star className="w-4 h-4 fill-gold text-gold" />
                    <span className="font-montserrat">{program.rating} rating</span>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto font-montserrat font-light mb-8">
            {program.fullDescription}
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <div className="flex items-center space-x-6 text-muted-foreground">
              <div className="flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span className="font-montserrat">{program.duration}</span>
              </div>
              <div className="flex items-center space-x-2">
                {program.comingSoon ? <Calendar className="w-5 h-5" /> : <Users className="w-5 h-5" />}
                <span className="font-montserrat">
                  {program.comingSoon ? program.startDates[0] : `${program.students} students`}
                </span>
              </div>
              {!program.comingSoon && (
                <div className="flex items-center space-x-2">
                  <Target className="w-5 h-5" />
                  <span className="font-montserrat">Avg. salary: {program.averageSalary}</span>
                </div>
              )}
            </div>
            <div className={`text-3xl font-semibold ${program.comingSoon ? 'text-muted-foreground' : 'text-gold'} font-montserrat`}>
              {program.price}
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                <TabsTrigger value="careers">Careers</TabsTrigger>
                <TabsTrigger value="certification">Certification</TabsTrigger>
                <TabsTrigger value="requirements">Requirements</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-8">
                <ProgramOverview program={program} />
              </TabsContent>

              <TabsContent value="curriculum" className="space-y-8">
                <ProgramCurriculum program={program} />
              </TabsContent>

              <TabsContent value="careers" className="space-y-8">
                <ProgramCareers program={program} />
              </TabsContent>

              <TabsContent value="certification" className="space-y-8">
                <ProgramCertification program={program} />
              </TabsContent>

              <TabsContent value="requirements" className="space-y-8">
                <ProgramRequirements program={program} />
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <ProgramSidebar 
              program={program} 
              user={user} 
              onEnrollment={handleEnrollment} 
            />
          </div>
        </div>
      </div>
    </div>
  );
}

// Sub-components
function ProgramOverview({ program }: { program: Program }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-montserrat font-medium">Program Overview</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="prose prose-lg max-w-none">
            <p className="text-muted-foreground leading-relaxed font-montserrat font-light">
              {program.fullDescription}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground font-montserrat">Program Outcomes</h4>
              <ul className="space-y-2">
                {program.outcomes.map((outcome, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <CheckCircle className="w-5 h-5 text-gold mt-0.5 flex-shrink-0" />
                    <span className="text-muted-foreground font-montserrat">{outcome}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold text-foreground font-montserrat">Tools & Technologies</h4>
              <div className="flex flex-wrap gap-2">
                {program.tools.map((tool, index) => (
                  <Badge key={index} variant="outline" className="font-montserrat">
                    {tool}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ProgramCurriculum({ program }: { program: Program }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-montserrat font-medium">Curriculum</CardTitle>
          <CardDescription className="font-montserrat">
            A comprehensive {program.duration} journey to master {program.title.toLowerCase()}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            {program.curriculum.map((module, index) => (
              <div key={index} className="border-l-4 border-gold pl-6 pb-6 last:pb-0">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-medium font-montserrat">{module.module}</h3>
                  <Badge variant="outline">{module.duration}</Badge>
                </div>
                {module.description && (
                  <p className="text-muted-foreground mb-4 font-montserrat font-light">
                    {module.description}
                  </p>
                )}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {module.topics.map((topic, idx) => (
                    <div key={idx} className="flex items-center space-x-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-gold flex-shrink-0" />
                      <span className="font-montserrat text-muted-foreground">{topic}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ProgramCareers({ program }: { program: Program }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-montserrat font-medium">Career Opportunities</CardTitle>
          <CardDescription className="font-montserrat">
            Potential job roles and salaries after completing this program
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-6">
            {program.careerPaths.map((career, index) => (
              <div key={index} className="p-4 bg-muted/50 rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-foreground font-montserrat">{career.title}</h4>
                  <Badge variant="outline" className="bg-gold/10 text-gold">
                    {career.salaryRange}
                  </Badge>
                </div>
                <p className="text-muted-foreground font-montserrat font-light">{career.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ProgramCertification({ program }: { program: Program }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-montserrat font-medium">Certifications & Partnerships</CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <div>
            <h4 className="font-semibold text-foreground font-montserrat mb-4">
              {program.comingSoon ? 'Certification Preparation' : 'Available Certifications'}
            </h4>
            <div className="grid grid-cols-1 gap-4">
              {program.certifications.map((cert, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium font-montserrat">{cert.name}</h5>
                    <Badge variant="outline">{cert.provider}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground font-montserrat">{cert.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-foreground font-montserrat mb-4">Industry Partnerships</h4>
            <div className="grid grid-cols-1 gap-4">
              {program.industryPartnerships.map((partnership, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium font-montserrat">{partnership.company}</h5>
                    <Badge variant="outline">{partnership.type}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground font-montserrat">{partnership.description}</p>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ProgramRequirements({ program }: { program: Program }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-montserrat font-medium">Requirements & Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h4 className="font-semibold text-foreground font-montserrat mb-3">Prerequisites</h4>
            <ul className="space-y-2">
              {program.prerequisites.map((req, index) => (
                <li key={index} className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-gold" />
                  <span className="font-montserrat text-muted-foreground">{req}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-foreground font-montserrat mb-3">Schedule</h4>
              <p className="text-muted-foreground font-montserrat">{program.schedule}</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-foreground font-montserrat mb-3">Assessment Methods</h4>
              <ul className="space-y-1">
                {program.assessmentMethods.map((method, index) => (
                  <li key={index} className="text-sm text-muted-foreground font-montserrat">
                    • {method}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div>
            <h4 className="font-semibold text-foreground font-montserrat mb-3">
              {program.comingSoon ? 'Expected Start Dates' : 'Start Dates'}
            </h4>
            <div className="flex flex-wrap gap-2">
              {program.startDates.map((date, index) => (
                <Badge key={index} variant="outline" className={`font-montserrat ${program.comingSoon ? 'text-muted-foreground' : ''}`}>
                  <Calendar className="w-3 h-3 mr-1" />
                  {date}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ProgramSidebar({ program, user, onEnrollment }: { program: Program; user: any; onEnrollment: () => void }) {
  return (
    <>
      {/* Enrollment/Interest Card */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <Card className="sticky top-8">
          <CardHeader>
            <CardTitle className="text-xl font-montserrat font-medium">
              {program.comingSoon ? 'Register Interest' : 'Enroll Now'}
            </CardTitle>
            <CardDescription className="font-montserrat">
              {program.comingSoon ? 'Be notified when applications open' : 'Start your journey today'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center">
              <div className={`text-3xl font-semibold ${program.comingSoon ? 'text-muted-foreground' : 'text-gold'} font-montserrat mb-2`}>
                {program.price}
              </div>
              <p className="text-sm text-muted-foreground font-montserrat">{program.duration} program</p>
            </div>

            {program.comingSoon && (
              <div className="p-4 bg-gold/10 rounded-lg">
                <div className="flex items-center space-x-2 text-gold mb-2">
                  <AlertCircle className="w-4 h-4" />
                  <span className="text-sm font-medium font-montserrat">Coming Soon</span>
                </div>
                <p className="text-xs text-muted-foreground font-montserrat">
                  This program launches in {program.startDates[0]}. Register your interest to be notified when applications open.
                </p>
              </div>
            )}

            <div className="space-y-4">
              <Button 
                onClick={onEnrollment}
                className={`w-full font-montserrat font-medium ${
                  program.comingSoon 
                    ? 'border-gold text-gold hover:bg-gold hover:text-black' 
                    : 'bg-gold hover:bg-gold-600 text-black'
                }`}
                variant={program.comingSoon ? 'outline' : 'default'}
                disabled={program.comingSoon}
              >
                {program.comingSoon ? (
                  <>
                    <Calendar className="w-4 h-4 mr-2" />
                    Notify Me When Available
                  </>
                ) : (
                  <>
                    {user ? 'Enroll Now' : 'Login to Enroll'}
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
              <Link to="/contact">
                <Button variant="outline" className="w-full font-montserrat font-medium">
                  Contact for More Info
                </Button>
              </Link>
            </div>

            <div className="text-center pt-4 border-t">
              <p className="text-sm text-muted-foreground font-montserrat mb-3">
                {program.comingSoon ? 'Will Include:' : 'Support Services:'}
              </p>
              <div className="space-y-2 text-sm">
                {program.supportServices.map((service, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-gold" />
                    <span className="font-montserrat">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Program Stats */}
      {!program.comingSoon && (
        <ProgramStats program={program} />
      )}

      {/* Related Programs */}
      <ProgramRelated />
    </>
  );
}

function ProgramStats({ program }: { program: Program }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: 0.4 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-montserrat font-medium">Program Statistics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm font-montserrat">Job Placement Rate</span>
            <span className="font-semibold text-gold">{program.jobPlacementRate}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm font-montserrat">Average Salary</span>
            <span className="font-semibold text-gold">{program.averageSalary}</span>
          </div>
          {program.rating > 0 && (
            <div className="flex justify-between items-center">
              <span className="text-sm font-montserrat">Student Rating</span>
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4 fill-gold text-gold" />
                <span className="font-semibold">{program.rating}</span>
              </div>
            </div>
          )}
          <div className="flex justify-between items-center">
            <span className="text-sm font-montserrat">Total Graduates</span>
            <span className="font-semibold text-gold">{program.students}</span>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ProgramRelated() {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.6, delay: 0.6 }}
    >
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-montserrat font-medium">Related Programs</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Link to="/programs/digital-marketing">
            <div className="p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors cursor-pointer">
              <h4 className="font-medium font-montserrat">Digital Marketing</h4>
              <p className="text-sm text-muted-foreground font-montserrat">Learn online marketing strategies</p>
            </div>
          </Link>
          <Link to="/programs/entrepreneurship">
            <div className="p-3 bg-muted/50 rounded-lg hover:bg-muted transition-colors cursor-pointer">
              <h4 className="font-medium font-montserrat">Entrepreneurship Development</h4>
              <p className="text-sm text-muted-foreground font-montserrat">Build your own business</p>
            </div>
          </Link>
        </CardContent>
      </Card>
    </motion.div>
  );
}