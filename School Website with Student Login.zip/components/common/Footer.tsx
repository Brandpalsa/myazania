import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Link } from '../../utils/router';
import { BookOpen, Phone, Mail, MapPin, Facebook, Linkedin, Instagram, Twitter, Youtube } from 'lucide-react';

export function Footer() {
  const siteInfo = {
    name: "Azania Academy",
    tagline: "Skills-Focused Training",
    description: "Azania Academy is a skills-focused institution offering hands-on, vocational training that empowers individuals to thrive in the real world.",
    phone: ["065 324 8692", "065 248 8692"],
    email: "academy@myazania.co.za",
    address: {
      street: "Wilma Court Building office number 12 1floor",
      city: "Springs",
      province: "Gauteng",
      postalCode: "1559",
      country: "South Africa"
    }
  };

  const navigationMenus = {
    platform: {
      title: "Online Platform",
      links: [
        { label: "Contact Us", href: "/contact", id: "contact" },
        { label: "Training", href: "/programs", id: "training" },
        { label: "About Us", href: "/about", id: "about" },
        { label: "Events", href: "/events", id: "events" },
        { label: "Blog", href: "/blog", id: "blog" }
      ]
    },
    programs: {
      title: "Programs",
      links: [
        { label: "Basic Coding", href: "/programs/basic-coding", id: "basic-coding" },
        { label: "Beauty Therapy & More", href: "/programs/beauty-therapy", id: "beauty-therapy" },
        { label: "Bookkeeping & Payroll", href: "/programs/bookkeeping-payroll", id: "bookkeeping" },
        { label: "Customer Service", href: "/programs/customer-service", id: "customer-service" },
        { label: "Digital Marketing", href: "/programs/digital-marketing", id: "digital-marketing" },
        { label: "Entrepreneurship", href: "/programs/entrepreneurship", id: "entrepreneurship" },
        { label: "Health & Safety", href: "/programs/health-safety", id: "health-safety" }
      ]
    }
  };

  const socialMedia = [
    { icon: Facebook, href: "#facebook", label: "Facebook", platform: "facebook" },
    { icon: Linkedin, href: "#linkedin", label: "LinkedIn", platform: "linkedin" },
    { icon: Instagram, href: "#instagram", label: "Instagram", platform: "instagram" },
    { icon: Twitter, href: "#twitter", label: "Twitter", platform: "twitter" },
    { icon: Youtube, href: "#youtube", label: "YouTube", platform: "youtube" }
  ];

  const legalLinks = [
    { label: "Privacy Policy", href: "/privacy-policy", id: "privacy" },
    { label: "Terms of Service", href: "/terms-of-service", id: "terms" },
    { label: "Cookie Policy", href: "/cookie-policy", id: "cookies" }
  ];

  return (
    <footer className="site-footer bg-black text-white py-16 transition-colors duration-300" role="contentinfo">
      <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="footer-content">
          
          {/* Site Info Widget */}
          <div className="footer-widget site-info">
            <div className="widget-header flex items-center space-x-3 mb-6">
              <div className="site-logo w-12 h-12 bg-gold rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-black" />
              </div>
              <div className="site-branding">
                <h3 className="site-title font-montserrat font-medium text-lg m-0 text-white">{siteInfo.name}</h3>
                <p className="site-tagline text-sm text-gold m-0 font-montserrat font-normal">{siteInfo.tagline}</p>
              </div>
            </div>
            
            <div className="widget-content">
              <p className="site-description text-gray-300 mb-6 text-sm leading-relaxed font-montserrat font-light">
                {siteInfo.description}
              </p>
              
              {/* Contact Information */}
              <div className="contact-info space-y-3">
                <div className="contact-item phone flex items-center space-x-3">
                  <Phone className="w-4 h-4 text-gold" />
                  <div className="contact-details text-sm">
                    <p className="m-0 font-montserrat font-normal text-white">Call: {siteInfo.phone.join(' / ')}</p>
                  </div>
                </div>
                <div className="contact-item email flex items-center space-x-3">
                  <Mail className="w-4 h-4 text-gold" />
                  <div className="contact-details text-sm">
                    <p className="m-0 font-montserrat font-normal text-white">Email: {siteInfo.email}</p>
                  </div>
                </div>
                <div className="contact-item address flex items-start space-x-3">
                  <MapPin className="w-4 h-4 text-gold mt-0.5" />
                  <div className="contact-details text-sm">
                    <p className="m-0 font-montserrat font-normal text-white">{siteInfo.address.street}</p>
                    <p className="m-0 font-montserrat font-normal text-gray-300">{siteInfo.address.city}, {siteInfo.address.province} {siteInfo.address.postalCode}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Platform Navigation Widget */}
          <div className="footer-widget navigation-menu">
            <div className="widget-header mb-6">
              <h4 className="widget-title font-montserrat font-medium text-lg m-0 text-gold">{navigationMenus.platform.title}</h4>
            </div>
            <div className="widget-content">
              <nav aria-label="Platform Navigation">
                <ul className="menu space-y-3 list-none p-0 m-0">
                  {navigationMenus.platform.links.map((link) => (
                    <li key={link.id} className="menu-item">
                      <Link
                        to={link.href}
                        className="menu-link text-gray-300 hover:text-gold transition-colors text-sm font-montserrat font-normal"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </nav>
            </div>
          </div>

          {/* Programs Navigation Widget */}
          <div className="footer-widget navigation-menu">
            <div className="widget-header mb-6">
              <h4 className="widget-title font-montserrat font-medium text-lg m-0 text-gold">{navigationMenus.programs.title}</h4>
            </div>
            <div className="widget-content">
              <nav aria-label="Programs Navigation">
                <ul className="menu space-y-3 list-none p-0 m-0">
                  {navigationMenus.programs.links.map((link) => (
                    <li key={link.id} className="menu-item">
                      <Link
                        to={link.href}
                        className="menu-link text-gray-300 hover:text-gold transition-colors text-sm font-montserrat font-normal"
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </nav>
            </div>
          </div>

          {/* Newsletter & Social Widget */}
          <div className="footer-widget newsletter-social">
            <div className="widget-header mb-6">
              <h4 className="widget-title font-montserrat font-medium text-lg m-0 text-gold">Stay Connected</h4>
            </div>
            <div className="widget-content">
              
              {/* Newsletter Signup */}
              <div className="newsletter-signup mb-6">
                <p className="newsletter-description text-gray-300 text-sm mb-4 font-montserrat font-light">
                  Enter your email address to register to our newsletter subscription
                </p>
                
                <form className="newsletter-form flex space-x-2" aria-label="Newsletter Signup">
                  <Input 
                    type="email" 
                    name="newsletter_email"
                    placeholder="Your email" 
                    className="newsletter-input bg-gray-800 border-gray-600 text-white placeholder-gray-400 font-montserrat font-normal"
                    aria-label="Email address for newsletter"
                    required
                  />
                  <Button 
                    type="submit"
                    className="newsletter-submit bg-gold hover:bg-yellow-600 text-black px-6 font-montserrat font-medium"
                  >
                    Subscribe
                  </Button>
                </form>
              </div>

              {/* Social Media Links */}
              <div className="social-media">
                <h5 className="social-title sr-only">Follow Us</h5>
                <div className="social-links flex space-x-4">
                  {socialMedia.map((social) => {
                    const IconComponent = social.icon;
                    return (
                      <a 
                        key={social.platform}
                        href={social.href} 
                        className="social-link w-8 h-8 bg-gray-800 rounded flex items-center justify-center hover:bg-gold hover:text-black transition-all duration-300 text-white"
                        aria-label={`Follow us on ${social.label}`}
                        data-platform={social.platform}
                      >
                        <IconComponent className="w-4 h-4 text-foreground" />
                      </a>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="footer-bottom border-t border-gray-800 mt-12 pt-8">
          <div className="footer-bottom-content flex flex-col md:flex-row justify-between items-center">
            <div className="copyright text-gray-400 text-sm mb-4 md:mb-0">
              <p className="m-0 font-montserrat font-normal">© 2025 {siteInfo.name}. All rights reserved.</p>
            </div>
            
            <nav className="legal-navigation" aria-label="Legal Navigation">
              <ul className="legal-menu flex space-x-6 list-none p-0 m-0">
                {legalLinks.map((link) => (
                  <li key={link.id} className="legal-menu-item">
                    <Link
                      to={link.href}
                      className="legal-link text-gray-400 hover:text-gold text-sm transition-colors font-montserrat font-normal"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </footer>
  );
}