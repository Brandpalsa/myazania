import { Button } from '../ui/button';
import { Link } from '../../utils/router';
import { ArrowLeft, Home, BookOpen, Phone, Users } from 'lucide-react';

interface BottomNavigationProps {
  currentPage?: 'home' | 'programs' | 'program-detail' | 'about' | 'contact' | 'legal';
  backTo?: string;
  backLabel?: string;
}

export function BottomNavigation({ 
  currentPage = 'home', 
  backTo = '/',
  backLabel = 'Back to Home'
}: BottomNavigationProps) {
  
  // Define navigation options based on current page
  const getNavigationOptions = () => {
    switch (currentPage) {
      case 'program-detail':
        return [
          { to: '/programs', label: 'Back to Programs', icon: BookOpen, primary: true },
          { to: '/contact', label: 'Enroll Now', icon: Phone, primary: false }
        ];
      
      case 'programs':
        return [
          { to: '/', label: 'Back to Home', icon: Home, primary: true },
          { to: '/contact', label: 'Get Started', icon: Phone, primary: false }
        ];
      
      case 'about':
        return [
          { to: '/', label: 'Back to Home', icon: Home, primary: true },
          { to: '/programs', label: 'View Programs', icon: BookOpen, primary: false }
        ];
      
      case 'contact':
        return [
          { to: '/', label: 'Back to Home', icon: Home, primary: true },
          { to: '/programs', label: 'View Programs', icon: BookOpen, primary: false }
        ];
      
      case 'legal':
        return [
          { to: '/', label: 'Back to Home', icon: Home, primary: true }
        ];
      
      case 'home':
      default:
        return [
          { to: '/programs', label: 'Explore Programs', icon: BookOpen, primary: true },
          { to: '/about', label: 'Learn More', icon: Users, primary: false }
        ];
    }
  };

  const navigationOptions = getNavigationOptions();

  return (
    <section className="bottom-navigation py-8 mt-16">
      <div className="content-container">
        <div className="flex flex-col sm:flex-row items-center justify-center button-spacing">
          {navigationOptions.map((option, index) => {
            const IconComponent = option.icon;
            return (
              <Link key={index} to={option.to}>
                <Button
                  size="lg"
                  variant="default"
                  className="bg-black text-white hover:bg-gray-800 hover:text-white border border-gray-600 font-montserrat font-medium btn-consistent min-w-48"
                >
                  <IconComponent className="w-4 h-4 mr-2 text-primary-foreground" />
                  {option.label}
                </Button>
              </Link>
            );
          })}
        </div>
        
        {/* Optional custom back navigation */}
        {backTo !== '/' && currentPage === 'program-detail' && (
          <div className="text-center mt-4">
            <Link to={backTo} className="inline-flex items-center text-gold hover:text-gold-400 transition-colors text-sm font-montserrat font-normal">
              <ArrowLeft className="w-4 h-4 mr-1 text-foreground" />
              {backLabel}
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}