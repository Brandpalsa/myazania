import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { MapPin, Navigation, Share2, ExternalLink } from 'lucide-react';

interface MapProps {
  address?: string;
  className?: string;
}

export function Map({ 
  address = "Wilma Court Building office number 12 1floor, Springs, Gauteng 1559, South Africa",
  className = ""
}: MapProps) {
  // Coordinates for Springs, Gauteng (approximate location)
  const coordinates = {
    lat: -26.2498,
    lng: 28.4186
  };

  // Generate Google Maps URLs
  const mapEmbedUrl = `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3579.8574851234567!2d28.4186!3d-26.2498!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e9516a6b8b8b8b8%3A0x1234567890abcdef!2sWilma%20Court%20Building%2C%20Springs%2C%20Gauteng%2C%20South%20Africa!5e0!3m2!1sen!2sza!4v1234567890123!5m2!1sen!2sza`;
  
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
  const mapViewUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
  
  const shareData = {
    title: 'MyAzania Academy Location',
    text: 'Find us at MyAzania Academy - Skills-Focused Training',
    url: mapViewUrl
  };

  const handleGetDirections = () => {
    window.open(directionsUrl, '_blank', 'noopener,noreferrer');
  };

  const handleViewOnMap = () => {
    window.open(mapViewUrl, '_blank', 'noopener,noreferrer');
  };

  const handleShareLocation = async () => {
    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
      } catch (error) {
        console.log('Error sharing:', error);
        // Fallback to copying to clipboard
        await fallbackShare();
      }
    } else {
      await fallbackShare();
    }
  };

  const fallbackShare = async () => {
    try {
      await navigator.clipboard.writeText(`${shareData.title}\n${shareData.text}\n${shareData.url}`);
      // You could show a toast notification here
      alert('Location details copied to clipboard!');
    } catch (error) {
      console.log('Error copying to clipboard:', error);
      // Final fallback - just open the URL
      window.open(shareData.url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <motion.div 
      className={`map-container bg-card rounded-lg overflow-hidden border border-border shadow-lg ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      {/* Map Header */}
      <div className="map-header bg-muted/50 p-4 border-b border-border">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <motion.div
              className="flex items-center justify-center w-10 h-10 bg-gold rounded-lg"
              whileHover={{ rotate: 5 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <MapPin className="w-5 h-5 text-black" />
            </motion.div>
            <div>
              <h3 className="font-montserrat font-medium text-foreground">Visit Our Campus</h3>
              <p className="text-sm text-muted-foreground mt-1 max-w-md">
                {address}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Map */}
      <div className="map-embed relative">
        <motion.iframe
          src={mapEmbedUrl}
          className="w-full h-64 md:h-80 border-0"
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="MyAzania Academy Location Map"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
        />
        
        {/* Map overlay for loading state */}
        <motion.div 
          className="absolute inset-0 bg-muted/20 flex items-center justify-center"
          initial={{ opacity: 1 }}
          animate={{ opacity: 0 }}
          transition={{ delay: 1, duration: 0.5 }}
          style={{ pointerEvents: 'none' }}
        >
          <div className="text-muted-foreground text-sm">Loading map...</div>
        </motion.div>
      </div>

      {/* Action Buttons */}
      <div className="map-actions p-4 bg-muted/20">
        <div className="flex flex-col sm:flex-row gap-3">
          <motion.div
            className="flex-1"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={handleGetDirections}
              className="w-full bg-gold text-black hover:bg-gold-600 hover:text-black font-montserrat font-medium"
              size="sm"
            >
              <Navigation className="w-4 h-4 mr-2 text-black" />
              Get Directions
            </Button>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={handleViewOnMap}
              variant="outline"
              className="border-gold text-gold hover:bg-gold hover:text-black font-montserrat font-medium"
              size="sm"
            >
              <ExternalLink className="w-4 h-4 mr-2 text-foreground" />
              View on Map
            </Button>
          </motion.div>

          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={handleShareLocation}
              variant="outline"
              className="border-muted-foreground text-muted-foreground hover:bg-muted hover:text-foreground font-montserrat font-medium"
              size="sm"
            >
              <Share2 className="w-4 h-4 mr-2 text-muted-foreground" />
              Share
            </Button>
          </motion.div>
        </div>

        {/* Additional Info */}
        <motion.div 
          className="mt-4 pt-4 border-t border-border"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.4 }}
        >
          <div className="flex flex-col sm:flex-row justify-between gap-4 text-sm text-muted-foreground">
            <div>
              <span className="font-medium text-foreground">Campus Hours:</span>
              <br />
              Monday - Friday: 8:00 AM - 5:00 PM
              <br />
              Saturday: 9:00 AM - 2:00 PM
            </div>
            <div>
              <span className="font-medium text-foreground">Contact:</span>
              <br />
              Phone: 065 324 8692 / 065 248 8692
              <br />
              Email: academy@myazania.co.za
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}