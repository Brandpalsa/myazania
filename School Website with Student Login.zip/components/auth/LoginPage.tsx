import { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Alert, AlertDescription } from '../ui/alert';
import { useAuth } from '../../utils/auth';
import { Eye, EyeOff, GraduationCap, LogIn, UserPlus, Mail, Lock, User, Users, AlertCircle, Info, PlayCircle } from 'lucide-react';
import { Link } from '../../utils/router';

export function LoginPage() {
  const { login, signup, loading } = useAuth();
  const [showPassword, setShowPassword] = useState(false);
  const [activeTab, setActiveTab] = useState('login');
  
  // Login form state
  const [loginForm, setLoginForm] = useState({
    email: '',
    password: ''
  });

  // Signup form state
  const [signupForm, setSignupForm] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    name: '',
    role: 'student'
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(loginForm.email, loginForm.password);
      // Navigation will be handled by the app based on user role
    } catch (error) {
      // Error handling is done in the auth context
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (signupForm.password !== signupForm.confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    try {
      await signup(signupForm.email, signupForm.password, signupForm.name, signupForm.role);
      setActiveTab('login');
      setSignupForm({
        email: '',
        password: '',
        confirmPassword: '',
        name: '',
        role: 'student'
      });
    } catch (error) {
      // Error handling is done in the auth context
    }
  };

  // Demo credentials that match the auth system
  const sampleCredentials = [
    { 
      role: 'Student', 
      email: 'student@azania.edu', 
      password: 'student123',
      description: 'Access student dashboard with enrolled courses'
    },
    { 
      role: 'Teacher', 
      email: 'teacher@azania.edu', 
      password: 'teacher123',
      description: 'Access teacher dashboard with course management'
    },
    { 
      role: 'Admin', 
      email: 'admin@azania.edu', 
      password: 'admin123',
      description: 'Access admin dashboard with full system controls'
    }
  ];

  const fillSampleCredentials = (email: string, password: string) => {
    setLoginForm({ email, password });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.6 }}
        >
          <Link to="/">
            <div className="flex items-center justify-center space-x-2 mb-4 group">
              <motion.div
                className="flex items-center justify-center w-12 h-12 bg-gold rounded-lg group-hover:bg-gold-600 transition-colors duration-300"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.6 }}
              >
                <GraduationCap className="w-7 h-7 text-black" />
              </motion.div>
              <div className="flex flex-col">
                <span className="text-foreground text-xl font-montserrat font-semibold leading-tight">Azania</span>
                <span className="text-gold text-sm font-montserrat leading-tight">Academy</span>
              </div>
            </div>
          </Link>
          <p className="text-muted-foreground font-montserrat">
            Access your learning dashboard
          </p>
        </motion.div>

        {/* Demo Mode Alert */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, duration: 0.4 }}
          className="mb-6"
        >
          <Alert className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
            <PlayCircle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <strong>Demo Platform Ready!</strong> Use any of the demo accounts below to explore 
              the complete Azania Academy experience with full functionality.
            </AlertDescription>
          </Alert>
        </motion.div>

        <Card className="backdrop-blur-sm bg-card/80 border-secondary shadow-xl">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <CardHeader>
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="login" className="flex items-center space-x-2">
                  <LogIn className="w-4 h-4" />
                  <span>Login</span>
                </TabsTrigger>
                <TabsTrigger value="signup" className="flex items-center space-x-2">
                  <UserPlus className="w-4 h-4" />
                  <span>Sign Up</span>
                </TabsTrigger>
              </TabsList>
            </CardHeader>

            {/* Login Tab */}
            <TabsContent value="login" className="mt-0">
              <form onSubmit={handleLogin} className="space-y-4">
                <CardContent className="space-y-4">
                  <CardTitle className="text-center">Welcome Back</CardTitle>
                  <CardDescription className="text-center">
                    Sign in to access your courses and dashboard
                  </CardDescription>

                  <div className="space-y-2">
                    <Label htmlFor="login-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="login-email"
                        type="email"
                        placeholder="Enter your email"
                        value={loginForm.email}
                        onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="login-password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="login-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your password"
                        value={loginForm.password}
                        onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                        className="pl-10 pr-10"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Demo credentials */}
                  <div className="bg-muted/50 p-4 rounded-lg border">
                    <div className="flex items-center space-x-2 mb-3">
                      <PlayCircle className="w-4 h-4 text-gold" />
                      <p className="text-sm font-medium">Demo Accounts (Click to Use):</p>
                    </div>
                    <div className="space-y-3">
                      {sampleCredentials.map((cred, index) => (
                        <motion.button
                          key={index}
                          type="button"
                          onClick={() => fillSampleCredentials(cred.email, cred.password)}
                          className="text-left w-full p-3 rounded-lg hover:bg-muted transition-colors border border-transparent hover:border-gold/20 bg-background/50"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="flex items-center justify-between mb-1">
                            <div className="font-medium text-sm">{cred.role}</div>
                            <div className="text-xs text-gold">Click to login</div>
                          </div>
                          <div className="text-xs text-muted-foreground mb-1">
                            {cred.email} / {cred.password}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {cred.description}
                          </div>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                </CardContent>

                <CardFooter>
                  <Button 
                    type="submit" 
                    className="w-full bg-gold hover:bg-gold-600 text-black font-medium"
                    disabled={loading}
                  >
                    {loading ? 'Signing in...' : 'Sign In'}
                  </Button>
                </CardFooter>
              </form>
            </TabsContent>

            {/* Signup Tab */}
            <TabsContent value="signup" className="mt-0">
              <form onSubmit={handleSignup} className="space-y-4">
                <CardContent className="space-y-4">
                  <CardTitle className="text-center">Create Account</CardTitle>
                  <CardDescription className="text-center">
                    Join Azania Academy and start your learning journey
                  </CardDescription>

                  <Alert className="border-amber-200 bg-amber-50 dark:bg-amber-950 dark:border-amber-800">
                    <AlertCircle className="h-4 w-4 text-amber-600" />
                    <AlertDescription className="text-amber-800 dark:text-amber-200">
                      Demo mode: New registrations are limited. Use the demo accounts to explore all features.
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-2">
                    <Label htmlFor="signup-name">Full Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="signup-name"
                        type="text"
                        placeholder="Enter your full name"
                        value={signupForm.name}
                        onChange={(e) => setSignupForm({ ...signupForm, name: e.target.value })}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-email">Email</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="signup-email"
                        type="email"
                        placeholder="Enter your email"
                        value={signupForm.email}
                        onChange={(e) => setSignupForm({ ...signupForm, email: e.target.value })}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-role">Account Type</Label>
                    <div className="relative">
                      <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <select
                        id="signup-role"
                        value={signupForm.role}
                        onChange={(e) => setSignupForm({ ...signupForm, role: e.target.value })}
                        className="w-full pl-10 pr-3 py-2 bg-background border border-input rounded-md text-sm font-montserrat"
                      >
                        <option value="student">Student</option>
                        <option value="teacher">Teacher</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="signup-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Create a password"
                        value={signupForm.password}
                        onChange={(e) => setSignupForm({ ...signupForm, password: e.target.value })}
                        className="pl-10 pr-10"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="signup-confirm-password">Confirm Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="signup-confirm-password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Confirm your password"
                        value={signupForm.confirmPassword}
                        onChange={(e) => setSignupForm({ ...signupForm, confirmPassword: e.target.value })}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                </CardContent>

                <CardFooter>
                  <Button 
                    type="submit" 
                    className="w-full bg-gold hover:bg-gold-600 text-black font-medium"
                    disabled={loading}
                  >
                    {loading ? 'Creating account...' : 'Create Account'}
                  </Button>
                </CardFooter>
              </form>
            </TabsContent>
          </Tabs>
        </Card>

        {/* Back to home link */}
        <motion.div 
          className="text-center mt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
        >
          <Link to="/" className="text-muted-foreground hover:text-foreground text-sm font-montserrat transition-colors">
            ← Back to Homepage
          </Link>
        </motion.div>
      </motion.div>
    </div>
  );
}