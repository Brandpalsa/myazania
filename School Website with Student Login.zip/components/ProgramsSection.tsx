import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  Code, 
  Scissors, 
  Calculator, 
  Headphones, 
  TrendingUp, 
  Users, 
  Heart, 
  Shield,
  Clock,
  User,
  Calendar
} from 'lucide-react';

const programs = [
  {
    id: 1,
    title: "Basic Coding",
    description: "Learn fundamental programming concepts and start your journey in software development.",
    icon: Code,
    duration: "6 months",
    level: "Beginner",
    category: "Technology",
    features: ["HTML/CSS", "JavaScript Basics", "Problem Solving", "Portfolio Projects"],
    color: "bg-blue-500"
  },
  {
    id: 2,
    title: "Beauty Therapy & More",
    description: "Comprehensive beauty and wellness training covering modern techniques and business skills.",
    icon: Scissors,
    duration: "8 months",
    level: "All Levels",
    category: "Beauty & Wellness",
    features: ["Facial Treatments", "Nail Art", "Hair Styling", "Business Management"],
    color: "bg-pink-500"
  },
  {
    id: 3,
    title: "Bookkeeping & Payroll",
    description: "Master financial record keeping and payroll management for small to medium businesses.",
    icon: Calculator,
    duration: "4 months",
    level: "Intermediate",
    category: "Finance",
    features: ["QuickBooks", "Tax Preparation", "Payroll Systems", "Financial Reports"],
    color: "bg-green-500"
  },
  {
    id: 4,
    title: "Customer Service",
    description: "Develop excellent communication and problem-solving skills for customer-facing roles.",
    icon: Headphones,
    duration: "3 months",
    level: "Beginner",
    category: "Business",
    features: ["Communication Skills", "Conflict Resolution", "CRM Systems", "Professional Ethics"],
    color: "bg-purple-500"
  },
  {
    id: 5,
    title: "Digital Marketing",
    description: "Learn modern marketing strategies including social media, SEO, and content creation.",
    icon: TrendingUp,
    duration: "5 months",
    level: "Intermediate",
    category: "Marketing",
    features: ["Social Media Marketing", "Google Ads", "SEO Optimization", "Analytics"],
    color: "bg-orange-500"
  },
  {
    id: 6,
    title: "Entrepreneurship",
    description: "Build the skills and mindset needed to start and grow your own successful business.",
    icon: Users,
    duration: "6 months",
    level: "All Levels",
    category: "Business",
    features: ["Business Planning", "Financial Management", "Marketing Strategy", "Leadership"],
    color: "bg-indigo-500"
  },
  {
    id: 7,
    title: "Health & Safety",
    description: "Comprehensive workplace safety training and health management certification.",
    icon: Shield,
    duration: "2 months",
    level: "Beginner",
    category: "Safety",
    features: ["Risk Assessment", "Safety Protocols", "Emergency Procedures", "Compliance"],
    color: "bg-red-500"
  },
  {
    id: 8,
    title: "Life Skills Development",
    description: "Essential personal and professional development skills for career success.",
    icon: Heart,
    duration: "3 months",
    level: "All Levels",
    category: "Personal Development",
    features: ["Time Management", "Communication", "Goal Setting", "Emotional Intelligence"],
    color: "bg-teal-500"
  }
];

export function ProgramsSection() {
  return (
    <section id="programs" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Our Program Offerings
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Choose from our comprehensive range of skills-focused programs designed to prepare you 
            for success in today's competitive job market.
          </p>
        </div>

        {/* Programs Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {programs.map((program) => {
            const IconComponent = program.icon;
            return (
              <Card key={program.id} className="hover:shadow-lg transition-shadow duration-300">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-12 h-12 ${program.color} rounded-lg flex items-center justify-center`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <Badge variant="secondary">{program.category}</Badge>
                  </div>
                  <CardTitle className="text-lg">{program.title}</CardTitle>
                  <CardDescription className="text-sm line-clamp-2">
                    {program.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Program Details */}
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{program.duration}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{program.level}</span>
                    </div>
                  </div>

                  {/* Key Features */}
                  <div>
                    <h4 className="font-medium text-sm text-gray-900 mb-2">Key Areas:</h4>
                    <div className="flex flex-wrap gap-1">
                      {program.features.slice(0, 3).map((feature, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                      {program.features.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{program.features.length - 3} more
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* CTA Button */}
                  <Button className="w-full" variant="outline">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <div className="bg-blue-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Start Your Journey?</h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Join thousands of students who have transformed their careers through our hands-on training programs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary">
                <Calendar className="w-4 h-4 mr-2" />
                Schedule a Consultation
              </Button>
              <Button size="lg" variant="outline" className="text-blue-600 bg-white hover:bg-gray-50">
                Download Brochure
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}