import { useAuth } from '../../utils/auth';
import { router } from '../../utils/router';
import { Header } from '../common/Header';
import { Footer } from '../common/Footer';
import { BottomNavigation } from '../common/BottomNavigation';

interface PageLayoutProps {
  children: React.ReactNode;
  currentPath?: string;
}

export function PageLayout({ children, currentPath }: PageLayoutProps) {
  const { user } = useAuth();
  
  // Determine if this is a dashboard page
  const isDashboardPage = currentPath?.includes('dashboard') || currentPath?.includes('/dashboard');
  
  // Determine if this is the login page
  const isLoginPage = currentPath === '/login';
  
  // Show header/footer for public pages and login page, but not for dashboards
  const showHeaderFooter = !isDashboardPage;

  return (
    <div className="min-h-screen bg-background">
      {showHeaderFooter && <Header />}
      
      <main className={`main-content ${showHeaderFooter ? '' : 'pt-0'}`}>
        {children}
      </main>
      
      {showHeaderFooter && <Footer />}
      {showHeaderFooter && <BottomNavigation />}
    </div>
  );
}